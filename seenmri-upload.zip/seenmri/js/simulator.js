/* ============================================================
   SEENmri — simulator.js  v4  "TRUE CONSOLE"
   Organic anatomy + slice-dependent structure + patient monitor
   (ECG gating display) + localizer + system ticker + adjustment
   phases + grid overlay + wheel scrolling.
   ============================================================ */
(function () {
    'use strict';

    function $(id) { return document.getElementById(id); }
    var canvas = $('mriCanvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    var off = document.createElement('canvas');
    var offCtx = off.getContext('2d');
    var down = document.createElement('canvas');
    var downCtx = down.getContext('2d');

    /* ---------- seeded noise ---------- */
    function mulberry32(a) {
        return function () {
            a |= 0; a = a + 0x6D2B79F5 | 0;
            var t = Math.imul(a ^ a >>> 15, 1 | a);
            t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
            return ((t ^ t >>> 14) >>> 0) / 4294967296;
        };
    }
    function organicPts(cx, cy, rx, ry, waves, amp, seed, n) {
        var r = mulberry32(seed);
        var pts = [];
        n = n || 56;
        for (var i = 0; i < n; i++) {
            var th = (i / n) * Math.PI * 2;
            var w = Math.sin(th * waves + seed) * amp + (r() - 0.5) * amp * 1.4;
            pts.push([cx + Math.cos(th) * (rx + w), cy + Math.sin(th) * (ry + w)]);
        }
        return pts;
    }
    var TEXN = 48, texGrid = new Float32Array(TEXN * TEXN);
    (function () { var r = mulberry32(1337); for (var i = 0; i < texGrid.length; i++) texGrid[i] = r(); })();
    function texAt(x, y) {
        var fx = (x / 4.7) % TEXN, fy = (y / 4.7) % TEXN;
        if (fx < 0) fx += TEXN; if (fy < 0) fy += TEXN;
        var x0 = Math.floor(fx), y0 = Math.floor(fy);
        var x1 = (x0 + 1) % TEXN, y1 = (y0 + 1) % TEXN;
        var tx = fx - x0, ty = fy - y0;
        var a = texGrid[y0 * TEXN + x0], b = texGrid[y0 * TEXN + x1];
        var c = texGrid[y1 * TEXN + x0], d2 = texGrid[y1 * TEXN + x1];
        var sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
        return (a + (b - a) * sx) * (1 - sy) + (c + (d2 - c) * sx) * sy;
    }
    function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

    /* ---------- tissues ---------- */
    var TISSUES = {
        air:       { T1: 1,    T2: 1,    PD: 0.02, ADC: 0,    susc: 1 },
        lung:      { T1: 1100, T2: 35,   PD: 0.30, ADC: 0,    susc: 1.6 },
        fat:       { T1: 250,  T2: 100,  PD: 0.95, ADC: 0.05, susc: 1, fat: true },
        muscle:    { T1: 950,  T2: 50,   PD: 0.70, ADC: 0.9,  susc: 1 },
        myo:       { T1: 1050, T2: 60,   PD: 0.72, ADC: 0.9,  susc: 1 },
        blood:     { T1: 1400, T2: 180,  PD: 0.90, ADC: 0.7,  susc: 1, enh: true, flow: true },
        gm:        { T1: 1250, T2: 100,  PD: 0.86, ADC: 0.8,  susc: 1 },
        wm:        { T1: 850,  T2: 80,   PD: 0.76, ADC: 0.8,  susc: 1 },
        csf:       { T1: 4200, T2: 2100, PD: 1.00, ADC: 3.0,  susc: 1 },
        marrow:    { T1: 300,  T2: 60,   PD: 0.92, ADC: 0.1,  susc: 1, fat: true },
        cortical:  { T1: 2000, T2: 25,   PD: 0.30, ADC: 0.05, susc: 1.8 },
        disc:      { T1: 1200, T2: 130,  PD: 0.82, ADC: 1.5,  susc: 1 },
        nucleus:   { T1: 1600, T2: 320,  PD: 0.92, ADC: 2.0,  susc: 1 },
        cord:      { T1: 950,  T2: 75,   PD: 0.78, ADC: 0.9,  susc: 1 },
        cartilage: { T1: 1150, T2: 45,   PD: 0.78, ADC: 1.2,  susc: 1 },
        meniscus:  { T1: 800,  T2: 30,   PD: 0.60, ADC: 0.6,  susc: 1 },
        tendon:    { T1: 1100, T2: 25,   PD: 0.55, ADC: 0.5,  susc: 1 },
        pit:       { T1: 350,  T2: 85,   PD: 0.95, ADC: 1.0,  susc: 1, enh: true },
        liver:     { T1: 810,  T2: 42,   PD: 0.75, ADC: 1.1,  susc: 1 },
        spleen:    { T1: 1100, T2: 60,   PD: 0.82, ADC: 1.0,  susc: 1 },
        vitreous:  { T1: 3600, T2: 1900, PD: 0.98, ADC: 2.6,  susc: 1 },
        lens:      { T1: 1400, T2: 30,   PD: 0.75, ADC: 0.2,  susc: 1 },
        lesion:    { T1: 1100, T2: 260,  PD: 0.95, ADC: 1.4,  susc: 1 },
        infarct:   { T1: 1150, T2: 80,   PD: 0.9,  ADC: 0.22, susc: 1 },
        edema:     { T1: 1000, T2: 280,  PD: 0.95, ADC: 1.7,  susc: 1 },
        tumor:     { T1: 1050, T2: 140,  PD: 0.9,  ADC: 1.0,  susc: 1, enh: true },
        plaque:    { T1: 1100, T2: 170,  PD: 0.9,  ADC: 0.9,  susc: 1 },
        heme:      { T1: 600,  T2: 35,   PD: 0.8,  ADC: 0.3,  susc: 5.0 },
        scar:      { T1: 900,  T2: 70,   PD: 0.85, ADC: 1.0,  susc: 1, enh: true },
        thrombus:  { T1: 800,  T2: 20,   PD: 0.6,  ADC: 0.4,  susc: 2.2 },
        bruise:    { T1: 950,  T2: 320,  PD: 0.95, ADC: 1.6,  susc: 1 },
        tear:      { T1: 3000, T2: 900,  PD: 0.95, ADC: 1.8,  susc: 1 },
        met:       { T1: 1000, T2: 220,  PD: 0.92, ADC: 1.2,  susc: 1, enh: true }
    };

    /* per-tissue texture profiles: s=strength · ax=anisotropy · k=scale */
    var TEXPROF = {
        muscle: { s: 0.22, ax: 5.0, k: 1.0 },
        myo:    { s: 0.12, ax: 3.0, k: 1.2 },
        gm:     { s: 0.16, ax: 1.0, k: 0.75 },
        wm:     { s: 0.07, ax: 1.0, k: 0.9 },
        fat:    { s: 0.15, ax: 1.6, k: 1.6 },
        marrow: { s: 0.13, ax: 1.0, k: 1.3 },
        liver:  { s: 0.10, ax: 1.0, k: 1.1 },
        spleen: { s: 0.11, ax: 1.0, k: 1.1 },
        lung:   { s: 0.26, ax: 1.0, k: 2.0 },
        tendon: { s: 0.10, ax: 8.0, k: 1.4 },
        DEFAULT:{ s: 0.09, ax: 1.0, k: 1.0 }
    };
    var TISSUE_ID = {}, TISSUE_LIST = [];
    Object.keys(TISSUES).forEach(function (k, i) {
        TISSUE_ID[k] = i;
        TISSUE_LIST.push(k);
    });

    /* ============================================================
       ANATOMY — slice-dependent (s.slice = 0..1)
       ============================================================ */
    var ANATOMY = {
        cardiac_sax: {
            phys: [360, 360], orient: ['A', 'P', 'R', 'L'], coil: '32-Ch Cardiac/Body Matrix',
            study: 'CARDIAC PROTOCOL', bg: 'air',
            prims: function (s) {
                var f = s.cineFactor, syst = 1 - f;
                var sl = s.slice;                       /* 0 apex → 1 base */
                var cav = 0.40 + 0.60 * sl;             /* cavity grows toward base */
                var outer = (0.26 * (1 - syst * 0.10)) * (0.72 + 0.28 * sl);
                var innerLV = (0.160 * f) * cav;
                var innerRV = (0.088 * (0.62 + 0.38 * f)) * cav;
                var p = [
                    { shape: 'poly', tissue: 'lung', pts: organicPts(0.27, 0.52, 0.17, 0.31, 5, 0.012, 7) },
                    { shape: 'poly', tissue: 'lung', pts: organicPts(0.73, 0.52, 0.17, 0.31, 5, 0.012, 8) },
                    { shape: 'poly', tissue: 'fat',  pts: organicPts(0.5, 0.52, 0.42, 0.45, 4, 0.014, 11) },
                    { shape: 'poly', tissue: 'muscle', pts: organicPts(0.27, 0.52, 0.10, 0.17, 4, 0.008, 12) },
                    { shape: 'ellipse', tissue: 'blood', cx: 0.655, cy: 0.615, rx: innerRV, ry: innerRV * 1.22 },
                    { shape: 'ring', tissue: 'myo', cx: 0.655, cy: 0.615, rx: innerRV + 0.035, ry: (innerRV + 0.030) * 1.25, rxIn: innerRV + 0.008, ryIn: innerRV * 1.22 + 0.006 },
                    { shape: 'ring', tissue: 'myo', cx: 0.5, cy: 0.52, rx: outer, ry: outer * 1.10, rxIn: innerLV, ryIn: innerLV * 1.13, seed: 21 },
                    /* rib cortical arcs in the chest wall */
                    { shape: 'arcband', tissue: 'cortical', cx: 0.5, cy: 0.52, rx: 0.385, ry: 0.41, a0: 0.3, a1: 0.9, th: 0.011 },
                    { shape: 'arcband', tissue: 'cortical', cx: 0.5, cy: 0.52, rx: 0.395, ry: 0.42, a0: 1.2, a1: 1.8, th: 0.011 },
                    { shape: 'arcband', tissue: 'cortical', cx: 0.5, cy: 0.52, rx: 0.388, ry: 0.415, a0: 2.2, a1: 2.8, th: 0.011 },
                    { shape: 'arcband', tissue: 'cortical', cx: 0.5, cy: 0.52, rx: 0.392, ry: 0.418, a0: 3.4, a1: 4.0, th: 0.011 },
                    { shape: 'arcband', tissue: 'cortical', cx: 0.5, cy: 0.52, rx: 0.39, ry: 0.416, a0: 4.5, a1: 5.1, th: 0.011 },
                    { shape: 'arcband', tissue: 'cortical', cx: 0.5, cy: 0.52, rx: 0.386, ry: 0.412, a0: 5.7, a1: 6.3, th: 0.011 }
                ];
                if (sl > 0.25 && sl < 0.75) {
                    p.push({ shape: 'poly', tissue: 'myo', pts: organicPts(0.44, 0.40 - 0.02 * syst, 0.042, 0.046, 4, 0.006, 31) });
                    p.push({ shape: 'poly', tissue: 'myo', pts: organicPts(0.575, 0.435 - 0.02 * syst, 0.036, 0.040, 4, 0.005, 32) });
                }
                if (sl < 0.22) {  /* apex — solid muscle */
                    p.push({ shape: 'poly', tissue: 'myo', pts: organicPts(0.5, 0.58, 0.075, 0.085, 4, 0.008, 33) });
                }
                if (sl > 0.82) {  /* base — aortic outflow + atrium */
                    p.push({ shape: 'ellipse', tissue: 'blood', cx: 0.72, cy: 0.33, rx: 0.038, ry: 0.038 });
                    p.push({ shape: 'ellipse', tissue: 'blood', cx: 0.52, cy: 0.30, rx: 0.085 * (1 + syst * 0.15), ry: 0.065 * (1 + syst * 0.15) });
                }
                p.push({ shape: 'poly', tissue: 'blood', pts: organicPts(0.5, 0.52, innerLV, innerLV * 1.13, 5, 0.006, 22, 44) });
                return p;
            },
            pathologies: {
                none: null,
                scar: [{ shape: 'arcband', tissue: 'scar', cx: 0.5, cy: 0.52, rx: 0.225, ry: 0.245, a0: 1.9, a1: 2.8, th: 0.045 }],
                edema: [{ shape: 'arcband', tissue: 'bruise', cx: 0.5, cy: 0.52, rx: 0.22, ry: 0.24, a0: 5.6, a1: 0.6, th: 0.05 }],
                thrombus: [{ shape: 'poly', tissue: 'thrombus', pts: [[0.42, 0.63], [0.52, 0.63], [0.50, 0.68], [0.44, 0.67]] }]
            }
        },

        cardiac_4ch: {
            phys: [360, 400], orient: ['A', 'P', 'L', 'R'], coil: '32-Ch Cardiac/Body Matrix',
            study: 'CARDIAC PROTOCOL — 4 CHAMBER', bg: 'lung',
            prims: function (s) {
                var f = s.cineFactor, syst = 1 - f;
                var sl = s.slice;
                var vScale = (0.58 + 0.42 * f) * (0.94 + 0.08 * sl);
                var aScale = 1 + 0.24 * syst;
                var aShift = 0.022 * syst;
                var lvx = 0.44, lvy = 0.60, rvx = 0.62, rvy = 0.615;
                var lax = 0.475, lay = 0.30 - aShift, rax = 0.615, ray = 0.31 - aShift;
                return [
                    { shape: 'poly', tissue: 'lung', pts: organicPts(0.22, 0.45, 0.17, 0.30, 5, 0.014, 41) },
                    { shape: 'poly', tissue: 'lung', pts: organicPts(0.80, 0.45, 0.16, 0.28, 5, 0.014, 42) },
                    { shape: 'poly', tissue: 'fat', pts: organicPts(0.5, 0.5, 0.46, 0.48, 3, 0.012, 43) },
                    { shape: 'ellipse', tissue: 'liver', cx: 0.78, cy: 0.84, rx: 0.16, ry: 0.14 },
                    { shape: 'ellipse', tissue: 'spleen', cx: 0.20, cy: 0.82, rx: 0.10, ry: 0.10 },
                    /* spine cross-section + descending aorta (flow void) */
                    { shape: 'ellipse', tissue: 'cortical', cx: 0.245, cy: 0.665, rx: 0.043, ry: 0.048 },
                    { shape: 'ellipse', tissue: 'marrow', cx: 0.245, cy: 0.665, rx: 0.034, ry: 0.039 },
                    { shape: 'ellipse', tissue: 'csf', cx: 0.245, cy: 0.675, rx: 0.011, ry: 0.013 },
                    { shape: 'ellipse', tissue: 'blood', cx: 0.315, cy: 0.655, rx: 0.024, ry: 0.026 },
                    { shape: 'ring', tissue: 'myo', cx: rvx, cy: rvy, rx: 0.105 * vScale + 0.03, ry: 0.17 * vScale + 0.028, rxIn: 0.088 * vScale, ryIn: 0.155 * vScale, rot: -0.18 },
                    { shape: 'ellipse', tissue: 'blood', cx: rvx, cy: rvy, rx: 0.088 * vScale, ry: 0.155 * vScale, rot: -0.18 },
                    { shape: 'ring', tissue: 'myo', cx: lvx, cy: lvy, rx: 0.115 * vScale + 0.042, ry: 0.19 * vScale + 0.035, rxIn: 0.095 * vScale, ryIn: 0.168 * vScale, rot: 0.30 },
                    { shape: 'ellipse', tissue: 'blood', cx: lvx, cy: lvy, rx: 0.095 * vScale, ry: 0.168 * vScale, rot: 0.30 },
                    { shape: 'poly', tissue: 'myo', pts: [[0.40, 0.74], [0.52, 0.73], [0.46, 0.80 - 0.02 * syst]] },
                    { shape: 'ring', tissue: 'myo', cx: lax, cy: lay, rx: 0.085 * aScale + 0.016, ry: 0.088 * aScale + 0.014, rxIn: 0.078 * aScale, ryIn: 0.080 * aScale, rot: 0.18 },
                    { shape: 'ellipse', tissue: 'blood', cx: lax, cy: lay, rx: 0.078 * aScale, ry: 0.080 * aScale, rot: 0.18 },
                    { shape: 'ring', tissue: 'myo', cx: rax, cy: ray, rx: 0.080 * aScale + 0.014, ry: 0.082 * aScale + 0.012, rxIn: 0.072 * aScale, ryIn: 0.075 * aScale, rot: -0.12 },
                    { shape: 'ellipse', tissue: 'blood', cx: rax, cy: ray, rx: 0.072 * aScale, ry: 0.075 * aScale, rot: -0.12 },
                    { shape: 'poly', tissue: 'myo', pts: [[0.52, 0.36], [0.545, 0.36], [0.545, 0.72], [0.52, 0.72]] },
                    { shape: 'poly', tissue: 'myo', pts: [[0.40, 0.445], [0.52, 0.435], [0.515, 0.455], [0.405, 0.465]] }
                ];
            },
            pathologies: {
                none: null,
                scar: [{ shape: 'arcband', tissue: 'scar', cx: 0.44, cy: 0.60, rx: 0.118, ry: 0.192, a0: 1.2, a1: 1.9, th: 0.032, rot: 0.30 }],
                thrombus: [{ shape: 'poly', tissue: 'thrombus', pts: [[0.41, 0.72], [0.50, 0.72], [0.48, 0.765], [0.435, 0.755]] }]
            }
        },

        brain_ax: {
            phys: [220, 220], orient: ['A', 'P', 'R', 'L'], coil: '64-Ch Head Coil',
            study: 'BRAIN PROTOCOL', bg: 'air',
            prims: function (s) {
                var sl = s.slice;                                   /* 0 vertex → 1 skull base */
                var shrink = 1 - 0.22 * Math.pow(Math.abs(sl - 0.42) * 2, 1.7);
                var r1 = 0.376 * shrink, r2 = 0.392 * shrink;
                var ventV = clamp(1 - Math.abs(sl - 0.55) * 3.0, 0, 1);   /* ventricles mid slices */
                var vs = 0.30 + 0.70 * ventV;
                var p = [
                    { shape: 'poly', tissue: 'fat',     pts: organicPts(0.5, 0.5, 0.462, 0.478, 4, 0.010, 51) },
                    { shape: 'ring',  tissue: 'marrow', cx: 0.5, cy: 0.5, rx: 0.448, ry: 0.462, rxIn: 0.425, ryIn: 0.440, seed: 52 },
                    { shape: 'ring',  tissue: 'cortical', cx: 0.5, cy: 0.5, rx: 0.423, ry: 0.437, rxIn: 0.403, ryIn: 0.417 },
                    { shape: 'poly',  tissue: 'csf',    pts: organicPts(0.5, 0.5, 0.400, 0.415, 6, 0.006, 53) },
                    { shape: 'poly',  tissue: 'gm',     pts: organicPts(0.5, 0.5, r1, r2, 9, 0.011, 54, 84) },
                    { shape: 'band',  tissue: 'wm', cx: 0.5, cy: 0.5, rx: r1 * 0.93, ry: r2 * 0.93, freq: 11, amp: 0.017, phase: 0.7 },
                    { shape: 'band',  tissue: 'wm', cx: 0.5, cy: 0.5, rx: r1 * 0.79, ry: r2 * 0.79, freq: 8, amp: 0.015, phase: 2.1 },
                    { shape: 'poly',  tissue: 'wm',    pts: organicPts(0.5, 0.49, 0.235 * vs + 0.04, 0.255 * vs + 0.04, 5, 0.010, 55) }
                ];
                if (sl < 0.62) {   /* basal ganglia + capsules + ventricles: mid-high */
                    p.push({ shape: 'ellipse', tissue: 'gm', cx: 0.415, cy: 0.565, rx: 0.052, ry: 0.062, rot: 0.5 });
                    p.push({ shape: 'ellipse', tissue: 'gm', cx: 0.585, cy: 0.565, rx: 0.052, ry: 0.062, rot: -0.5 });
                    p.push({ shape: 'poly', tissue: 'wm', pts: [[0.47, 0.50], [0.492, 0.50], [0.478, 0.635], [0.458, 0.63]] });
                    p.push({ shape: 'poly', tissue: 'wm', pts: [[0.53, 0.50], [0.508, 0.50], [0.522, 0.635], [0.542, 0.63]] });
                }
                if (ventV > 0.12) {  /* lateral ventricles */
                    var sc = function (pts) { return pts.map(function (q) { return [0.5 + (q[0] - 0.5) * vs, 0.52 + (q[1] - 0.52) * vs]; }); };
                    p.push({ shape: 'poly', tissue: 'csf', pts: sc([[0.472, 0.40], [0.497, 0.405], [0.497, 0.52], [0.487, 0.52], [0.485, 0.43], [0.474, 0.435]]) });
                    p.push({ shape: 'poly', tissue: 'csf', pts: sc([[0.528, 0.40], [0.503, 0.405], [0.503, 0.52], [0.513, 0.52], [0.515, 0.43], [0.526, 0.435]]) });
                    p.push({ shape: 'ellipse', tissue: 'csf', cx: 0.5, cy: 0.585, rx: 0.016, ry: 0.115 * vs });
                }
                if (ventV > 0.3) {   /* caudate heads bulging into frontal horns */
                    p.push({ shape: 'ellipse', tissue: 'gm', cx: 0.462, cy: 0.455, rx: 0.030 * vs + 0.012, ry: 0.036 * vs + 0.012 });
                    p.push({ shape: 'ellipse', tissue: 'gm', cx: 0.538, cy: 0.455, rx: 0.030 * vs + 0.012, ry: 0.036 * vs + 0.012 });
                }
                if (sl < 0.72) {   /* sylvian fissure CSF + insula */
                    p.push({ shape: 'poly', tissue: 'csf', pts: [[0.335, 0.475], [0.295, 0.53], [0.272, 0.565], [0.284, 0.575], [0.315, 0.53], [0.35, 0.487]] });
                    p.push({ shape: 'poly', tissue: 'csf', pts: [[0.665, 0.475], [0.705, 0.53], [0.728, 0.565], [0.716, 0.575], [0.685, 0.53], [0.65, 0.487]] });
                    p.push({ shape: 'ellipse', tissue: 'gm', cx: 0.375, cy: 0.52, rx: 0.022, ry: 0.05, rot: 0.45 });
                    p.push({ shape: 'ellipse', tissue: 'gm', cx: 0.625, cy: 0.52, rx: 0.022, ry: 0.05, rot: -0.45 });
                }
                if (sl > 0.48 && sl < 0.64) {   /* pineal calcification — classic dark dot */
                    p.push({ shape: 'ellipse', tissue: 'cortical', cx: 0.5, cy: 0.665, rx: 0.014, ry: 0.014 });
                }
                if (sl < 0.55) {  /* SSS flow void midline */
                    p.push({ shape: 'poly', tissue: 'blood', pts: [[0.5, 0.14], [0.508, 0.14], [0.506, 0.34], [0.5, 0.34]] });
                }
                if (sl < 0.68) {  /* MCA flow voids */
                    p.push({ shape: 'poly', tissue: 'blood', pts: [[0.62, 0.545], [0.68, 0.53], [0.72, 0.515]] });
                    p.push({ shape: 'poly', tissue: 'blood', pts: [[0.38, 0.545], [0.32, 0.53], [0.28, 0.515]] });
                    p.push({ shape: 'ellipse', tissue: 'air', cx: 0.735, cy: 0.30, rx: 0.05, ry: 0.075 });
                }
                if (sl > 0.68) {  /* temporal lobes */
                    p.push({ shape: 'poly', tissue: 'gm', pts: organicPts(0.285, 0.665, 0.085, 0.13, 5, 0.010, 58) });
                    p.push({ shape: 'poly', tissue: 'gm', pts: organicPts(0.715, 0.665, 0.085, 0.13, 5, 0.010, 59) });
                    p.push({ shape: 'ellipse', tissue: 'csf', cx: 0.355, cy: 0.625, rx: 0.055, ry: 0.018, rot: 0.35 });
                    p.push({ shape: 'ellipse', tissue: 'csf', cx: 0.645, cy: 0.625, rx: 0.055, ry: 0.018, rot: -0.35 });
                }
                if (sl > 0.74) {  /* skull base: cerebellum + pons + orbits */
                    p.push({ shape: 'poly', tissue: 'gm', pts: organicPts(0.5, 0.80, 0.19, 0.10, 6, 0.010, 60) });
                    p.push({ shape: 'band', tissue: 'wm', cx: 0.5, cy: 0.80, rx: 0.13, ry: 0.065, freq: 13, amp: 0.008, phase: 0 });
                    p.push({ shape: 'poly', tissue: 'wm', pts: [[0.44, 0.62], [0.56, 0.62], [0.545, 0.70], [0.455, 0.70]] });
                    p.push({ shape: 'poly', tissue: 'fat', pts: organicPts(0.30, 0.795, 0.075, 0.055, 4, 0.008, 56) });
                    p.push({ shape: 'poly', tissue: 'fat', pts: organicPts(0.70, 0.795, 0.075, 0.055, 4, 0.008, 57) });
                    p.push({ shape: 'ellipse', tissue: 'vitreous', cx: 0.30, cy: 0.79, rx: 0.036, ry: 0.030 });
                    p.push({ shape: 'ellipse', tissue: 'lens', cx: 0.29, cy: 0.787, rx: 0.011, ry: 0.013 });
                    p.push({ shape: 'ellipse', tissue: 'vitreous', cx: 0.70, cy: 0.79, rx: 0.036, ry: 0.030 });
                    p.push({ shape: 'ellipse', tissue: 'lens', cx: 0.69, cy: 0.787, rx: 0.011, ry: 0.013 });
                }
                return p;
            },
            pathologies: {
                none: null,
                stroke: [{ shape: 'wedge', tissue: 'infarct', cx: 0.66, cy: 0.44, r: 0.16, a0: -0.6, a1: 1.0 },
                         { shape: 'wedge', tissue: 'gm', cx: 0.66, cy: 0.44, r: 0.07, a0: -0.4, a1: 0.8 }],
                tumor:  [{ shape: 'poly', tissue: 'edema', pts: organicPts(0.64, 0.40, 0.15, 0.13, 5, 0.012, 61) },
                         { shape: 'poly', tissue: 'tumor', pts: organicPts(0.64, 0.40, 0.075, 0.065, 4, 0.008, 62) }],
                ms:     [{ shape: 'ellipse', tissue: 'plaque', cx: 0.5, cy: 0.40, rx: 0.045, ry: 0.028 },
                         { shape: 'ellipse', tissue: 'plaque', cx: 0.60, cy: 0.33, rx: 0.03, ry: 0.02 },
                         { shape: 'ellipse', tissue: 'plaque', cx: 0.38, cy: 0.62, rx: 0.033, ry: 0.022 }],
                hemorrhage: [{ shape: 'poly', tissue: 'heme', pts: organicPts(0.58, 0.45, 0.09, 0.08, 4, 0.010, 63) }]
            }
        },

        brain_sag: {
            phys: [230, 250], orient: ['A', 'P', 'S', 'I'], coil: '64-Ch Head Coil',
            study: 'BRAIN PROTOCOL — SAGITTAL', bg: 'air',
            prims: function (s) {
                var sl = s.slice;                             /* 0.5 = midline */
                var lat = Math.abs(sl - 0.5) * 2;             /* 0 midline → 1 lateral */
                var vs = 1 - 0.5 * lat;
                var ccW = 1 - 0.55 * lat;
                var p = [
                    { shape: 'poly', tissue: 'fat',     pts: organicPts(0.5, 0.5, 0.465, 0.485, 4, 0.011, 71) },
                    { shape: 'ring',  tissue: 'marrow', cx: 0.5, cy: 0.5, rx: 0.452, ry: 0.470, rxIn: 0.430, ryIn: 0.448, seed: 72 },
                    { shape: 'ring',  tissue: 'cortical', cx: 0.5, cy: 0.5, rx: 0.428, ry: 0.445, rxIn: 0.408, ryIn: 0.425 },
                    { shape: 'poly',  tissue: 'csf',    pts: organicPts(0.5, 0.5, 0.403, 0.420, 5, 0.007, 73) },
                    { shape: 'poly',  tissue: 'gm',     pts: organicPts(0.5, 0.48, 0.378, 0.395, 8, 0.012, 74, 84) },
                    { shape: 'band',  tissue: 'gm', cx: 0.5, cy: 0.47, rx: 0.34, ry: 0.36, freq: 9, amp: 0.016, phase: 0.3 }
                ];
                if (lat < 0.55) {
                    p.push({ shape: 'cc', tissue: 'wm', scale: ccW });
                    p.push({ shape: 'poly', tissue: 'csf', pts: [[0.475, 0.415], [0.585, 0.435], [0.615, 0.50], [0.605, 0.53], [0.585, 0.475], [0.47, 0.45]].map(function (q) { return [0.5 + (q[0] - 0.5) * vs, 0.5 + (q[1] - 0.5) * vs]; }) });
                    p.push({ shape: 'ellipse', tissue: 'csf', cx: 0.5, cy: 0.565, rx: 0.013, ry: 0.045 * vs });
                    p.push({ shape: 'poly', tissue: 'csf', pts: [[0.5, 0.60], [0.512, 0.60], [0.508, 0.68], [0.502, 0.68]] });
                    p.push({ shape: 'poly', tissue: 'csf', pts: [[0.462, 0.72], [0.548, 0.72], [0.535, 0.775], [0.475, 0.775]] });
                    p.push({ shape: 'ellipse', tissue: 'gm', cx: 0.515, cy: 0.565, rx: 0.052 * vs, ry: 0.042 * vs });
                    if (lat < 0.2) {
                        p.push({ shape: 'ellipse', tissue: 'pit', cx: 0.545, cy: 0.665, rx: 0.018, ry: 0.014 });
                        p.push({ shape: 'poly', tissue: 'marrow', pts: [[0.60, 0.70], [0.63, 0.72], [0.60, 0.78], [0.575, 0.75]] });
                    }
                }
                p.push({ shape: 'poly', tissue: 'wm', pts: [[0.482, 0.56], [0.518, 0.56], [0.522, 0.63], [0.545, 0.665], [0.535, 0.75], [0.50, 0.795], [0.465, 0.75], [0.458, 0.665], [0.478, 0.63]] });
                p.push({ shape: 'poly', tissue: 'gm', pts: [[0.462, 0.655], [0.54, 0.655], [0.535, 0.70], [0.466, 0.70]] });
                p.push({ shape: 'poly', tissue: 'gm', pts: organicPts(0.5, 0.845, 0.165, 0.105, 5, 0.009, 75) });
                p.push({ shape: 'band', tissue: 'wm', cx: 0.5, cy: 0.845, rx: 0.11, ry: 0.075, freq: 14, amp: 0.008, phase: 0 });
                p.push({ shape: 'ellipse', tissue: 'csf', cx: 0.5, cy: 0.93, rx: 0.13, ry: 0.028 });
                p.push({ shape: 'ellipse', tissue: 'blood', cx: 0.5, cy: 0.115, rx: 0.013, ry: 0.010 });
                return p;
            },
            pathologies: {
                none: null,
                tumor: [{ shape: 'poly', tissue: 'edema', pts: organicPts(0.52, 0.85, 0.09, 0.06, 4, 0.010, 81) },
                        { shape: 'poly', tissue: 'tumor', pts: organicPts(0.52, 0.85, 0.045, 0.032, 4, 0.006, 82) }],
                hemorrhage: [{ shape: 'poly', tissue: 'heme', pts: organicPts(0.56, 0.40, 0.07, 0.06, 4, 0.009, 83) }]
            }
        },

        spine_sag: {
            phys: [300, 300], orient: ['A', 'P', 'S', 'I'], coil: 'Spine + Body Matrix',
            study: 'LUMBAR SPINE PROTOCOL', bg: 'fat',
            prims: function (s) {
                var sl = s.slice;
                var mid = 1 - Math.abs(sl - 0.5) * 2;      /* 1 midline → 0 far parasagittal */
                var p = [
                    { shape: 'poly', tissue: 'muscle', pts: organicPts(0.17, 0.62, 0.115, 0.335, 5, 0.012, 91) },
                    { shape: 'poly', tissue: 'muscle', pts: organicPts(0.845, 0.62, 0.105, 0.33, 5, 0.012, 92) }
                ];
                if (mid > 0.3) {  /* canal visible near midline */
                    var cw = 0.144 * clamp((mid - 0.25) / 0.75, 0, 1);
                    p.push({ shape: 'rrect', tissue: 'csf', x: 0.5 - cw / 2, y: 0.125, w: cw, h: 0.775, r: cw * 0.35 });
                    if (mid > 0.45) {
                        p.push({ shape: 'rrect', tissue: 'cord', x: 0.477, y: 0.135, w: 0.046, h: 0.30, r: 0.02 });
                        p.push({ shape: 'poly', tissue: 'cord', pts: [[0.478, 0.42], [0.522, 0.42], [0.505, 0.58], [0.495, 0.58]] });
                        p.push({ shape: 'poly', tissue: 'cord', pts: [[0.465, 0.56], [0.50, 0.62], [0.535, 0.56], [0.540, 0.57], [0.50, 0.645], [0.460, 0.57]] });
                        p.push({ shape: 'poly', tissue: 'cord', pts: [[0.455, 0.62], [0.50, 0.72], [0.545, 0.62], [0.548, 0.635], [0.50, 0.75], [0.452, 0.635]] });
                    }
                }
                for (var i = 0; i < 5; i++) {
                    var y = 0.155 + i * 0.168;
                    p.push({ shape: 'rrect', tissue: 'cortical', x: 0.295, y: y, w: 0.41, h: 0.082, r: 0.018 });
                    p.push({ shape: 'rrect', tissue: 'marrow', x: 0.302, y: y + 0.007, w: 0.396, h: 0.068, r: 0.014 });
                    if (mid > 0.45) p.push({ shape: 'poly', tissue: 'blood', pts: [[0.49, y + 0.041], [0.51, y + 0.041], [0.505, y + 0.02], [0.495, y + 0.02]] });
                    if (mid > 0.55) {  /* disc only near midline */
                        p.push({ shape: 'rrect', tissue: 'disc', x: 0.325, y: y - 0.079, w: 0.35, h: 0.072, r: 0.018 });
                        p.push({ shape: 'ellipse', tissue: 'nucleus', cx: 0.5, cy: y - 0.043, rx: 0.10, ry: 0.022 });
                    }
                    /* pedicles — the parasagittal landmarks */
                    if (mid < 0.6) {
                        p.push({ shape: 'rrect', tissue: 'cortical', x: 0.635, y: y + 0.005, w: 0.07, h: 0.05, r: 0.012 });
                        p.push({ shape: 'rrect', tissue: 'marrow', x: 0.642, y: y + 0.012, w: 0.056, h: 0.036, r: 0.010 });
                    }
                    if (mid > 0.35) {
                        p.push({ shape: 'poly', tissue: 'cortical', pts: [[0.70, y + 0.02], [0.79, y + 0.045], [0.78, y + 0.075], [0.695, y + 0.06]] });
                        p.push({ shape: 'poly', tissue: 'marrow', pts: [[0.715, y + 0.032], [0.775, y + 0.052], [0.768, y + 0.070], [0.71, y + 0.052]] });
                    }
                }
                return p;
            },
            pathologies: {
                none: null,
                extrusion: [{ shape: 'poly', tissue: 'nucleus', pts: [[0.50, 0.645], [0.575, 0.665], [0.60, 0.695], [0.555, 0.70], [0.50, 0.675]] }],
                mets: [{ shape: 'rrect', tissue: 'met', x: 0.36, y: 0.492, w: 0.19, h: 0.075, r: 0.016 },
                       { shape: 'rrect', tissue: 'met', x: 0.40, y: 0.828, w: 0.14, h: 0.070, r: 0.016 }]
            }
        },

        knee_sag: {
            phys: [160, 160], orient: ['A', 'P', 'S', 'I'], coil: '15-Ch Knee Coil',
            study: 'KNEE MRI PROTOCOL', bg: 'air',
            prims: function (s) {
                var sl = s.slice;                     /* 0 medial → 1 lateral */
                var mid = 1 - Math.abs(sl - 0.5) * 2;
                var p = [
                    { shape: 'poly', tissue: 'fat', pts: organicPts(0.5, 0.55, 0.44, 0.44, 4, 0.012, 95) },
                    { shape: 'poly', tissue: 'cortical', pts: organicPts(0.47, 0.24, 0.165, 0.215, 4, 0.008, 96, 48) },
                    { shape: 'poly', tissue: 'marrow',  pts: organicPts(0.472, 0.245, 0.145, 0.195, 4, 0.008, 97, 48) },
                    { shape: 'poly', tissue: 'cortical', pts: organicPts(0.565, 0.80, 0.150, 0.185, 4, 0.008, 98, 48) },
                    { shape: 'poly', tissue: 'marrow',  pts: organicPts(0.567, 0.805, 0.130, 0.165, 4, 0.008, 99, 48) },
                    { shape: 'band', tissue: 'cartilage', cx: 0.475, cy: 0.44, rx: 0.135, ry: 0.055, freq: 3, amp: 0.006, phase: 3.3 },
                    { shape: 'band', tissue: 'cartilage', cx: 0.56, cy: 0.665, rx: 0.125, ry: 0.05, freq: 3, amp: 0.006, phase: 0.2 }
                ];
                if (mid > 0.35) {  /* meniscal body: wedge near center */
                    var th = 0.5 + 0.5 * mid;
                    p.push({ shape: 'poly', tissue: 'meniscus', pts: [[0.44, 0.53], [0.505, 0.535], [0.47, 0.53 + 0.045 * th], [0.435, 0.565]] });
                    p.push({ shape: 'poly', tissue: 'meniscus', pts: [[0.55, 0.53], [0.61, 0.525], [0.60, 0.565], [0.555, 0.53 + 0.045 * th]] });
                } else {  /* horn cross-sections at edges */
                    p.push({ shape: 'ellipse', tissue: 'meniscus', cx: 0.455, cy: 0.545, rx: 0.028, ry: 0.022 });
                    p.push({ shape: 'ellipse', tissue: 'meniscus', cx: 0.585, cy: 0.545, rx: 0.026, ry: 0.020 });
                }
                if (mid > 0.3) {
                    p.push({ shape: 'poly', tissue: 'tendon', pts: [[0.475, 0.415], [0.545, 0.43], [0.575, 0.655], [0.545, 0.66], [0.49, 0.45]] });
                    p.push({ shape: 'poly', tissue: 'tendon', pts: [[0.60, 0.43], [0.615, 0.44], [0.52, 0.63], [0.49, 0.62], [0.575, 0.45]] });
                }
                p.push({ shape: 'poly', tissue: 'tendon', pts: [[0.335, 0.36], [0.352, 0.36], [0.37, 0.66], [0.352, 0.665]] });
                p.push({ shape: 'poly', tissue: 'tendon', pts: [[0.325, 0.14], [0.345, 0.135], [0.338, 0.30], [0.32, 0.30]] });
                if (mid > 0.4) {
                    p.push({ shape: 'ellipse', tissue: 'cartilage', cx: 0.345, cy: 0.33, rx: 0.052, ry: 0.045, rot: 0.3 });
                    p.push({ shape: 'poly', tissue: 'cortical', pts: organicPts(0.345, 0.325, 0.045, 0.038, 4, 0.004, 100, 32) });
                }
                p.push({ shape: 'poly', tissue: 'muscle', pts: organicPts(0.155, 0.44, 0.09, 0.30, 4, 0.010, 101) });
                p.push({ shape: 'poly', tissue: 'muscle', pts: organicPts(0.855, 0.46, 0.085, 0.30, 4, 0.010, 102) });
                p.push({ shape: 'ellipse', tissue: 'blood', cx: 0.72, cy: 0.70, rx: 0.018, ry: 0.030, rot: 0.4 });
                p.push({ shape: 'ellipse', tissue: 'blood', cx: 0.755, cy: 0.715, rx: 0.014, ry: 0.026, rot: 0.4 });
                return p;
            },
            pathologies: {
                none: null,
                bruise: [{ shape: 'poly', tissue: 'bruise', pts: organicPts(0.52, 0.245, 0.075, 0.05, 4, 0.008, 103) },
                         { shape: 'poly', tissue: 'bruise', pts: organicPts(0.50, 0.79, 0.06, 0.045, 4, 0.007, 104) }],
                tear: [{ shape: 'poly', tissue: 'tear', pts: [[0.49, 0.528], [0.535, 0.538], [0.515, 0.565], [0.487, 0.56]] }]
            }
        }
    };

    /* localizer silhouettes for the mini navigator */
    function drawLocalizer() {
        var lc = $('localizer');
        if (!lc) return;
        var c = lc.getContext('2d');
        var W = lc.width, H = lc.height;
        c.clearRect(0, 0, W, H);
        c.fillStyle = '#03060c';
        c.fillRect(0, 0, W, H);
        c.strokeStyle = 'rgba(160, 190, 240, 0.75)';
        c.fillStyle = 'rgba(160, 190, 240, 0.14)';
        c.lineWidth = 1.5;
        c.beginPath();
        var a = state.anatomy;
        if (a === 'brain_ax' || a === 'brain_sag') {
            c.ellipse(W / 2, H / 2, W * 0.34, H * 0.42, 0, 0, Math.PI * 2);
        } else if (a.indexOf('cardiac') === 0) {
            c.moveTo(W * 0.28, H * 0.78);
            c.quadraticCurveTo(W * 0.30, H * 0.40, W * 0.52, H * 0.34);
            c.quadraticCurveTo(W * 0.74, H * 0.40, W * 0.72, H * 0.78);
            c.closePath();
        } else if (a === 'spine_sag') {
            c.rect(W * 0.40, H * 0.12, W * 0.20, H * 0.76);
        } else {
            c.rect(W * 0.30, H * 0.15, W * 0.40, H * 0.70);
        }
        c.fill(); c.stroke();
        /* slice position line */
        var slPos = state.slice * (H - 10) + 5;
        c.strokeStyle = '#00d4aa';
        c.lineWidth = 2;
        c.beginPath();
        c.moveTo(4, slPos); c.lineTo(W - 4, slPos);
        c.stroke();
        c.fillStyle = '#00d4aa';
        c.beginPath(); c.arc(W - 4, slPos, 2.6, 0, Math.PI * 2); c.fill();
    }

    /* ============================================================
       STATE
       ============================================================ */
    var state = {
        B0: 3.0, seq: 'bSSFP', TR: 3.2, TE: 1.6, TI: 2500, FA: 60, bValue: 1000,
        fatSat: 'none', anatomy: 'cardiac_sax', pathology: 'none', gd: false,
        FOV: 340, matrix: 256, thick: 8, phaseFOV: 100, NEX: 1, ETL: 1, PI: 2, BW: 62.5,
        motion: false, metal: false, pulsation: false,
        W: 1.0, L: 0.5,
        slice: 0.5,                      /* 0..1 within stack */
        adcMap: false,
        cinePhase: 0, cinePlaying: false, cineFactor: 1
    };
    var SLICES = 24;

    /* ============================================================
       PHYSICS
       ============================================================ */
    function tissueSignal(t, s) {
        var B = s.B0 >= 3 ? { t1: 1.25, t2: 0.9 } : { t1: 1, t2: 1 };
        var T1 = t.T1 * B.t1, T2 = t.T2 * B.t2;
        if (s.gd && t.enh) T1 = 260 * (s.B0 >= 3 ? 1.15 : 1);
        var E1 = Math.exp(-s.TR / T1);
        var sig = 0;
        switch (s.seq) {
            case 'SE': sig = t.PD * (1 - E1) * Math.exp(-s.TE / T2); break;
            case 'FSE': sig = t.PD * (1 - E1) * Math.exp(-s.TE / (T2 * 1.55)); break;
            case 'IR': {
                var inv = Math.abs(1 - 2 * Math.exp(-s.TI / T1) + Math.exp(-(s.TI + s.TR) / T1));
                sig = t.PD * inv * (1 - E1 * 0.4) * Math.exp(-s.TE / (T2 * 1.3));
                break;
            }
            case 'GRE': {
                var a = s.FA * Math.PI / 180;
                sig = t.PD * Math.sin(a) * (1 - E1) / (1 - E1 * Math.cos(a)) * Math.exp(-s.TE / (T2 * 0.42 / (t.susc || 1)));
                break;
            }
            case 'bSSFP': {
                var a2 = s.FA * Math.PI / 180;
                var E2s = Math.exp(-s.TR / (T2 * (t.susc || 1) * 1.4));
                sig = Math.abs(t.PD * Math.sin(a2 / 2) * (1 - E1) / ((1 - E1 * Math.cos(a2) - E2s * Math.cos(a2) + E1 * E2s) + 0.08));
                break;
            }
            case 'DWI': {
                sig = t.PD * (1 - Math.exp(-s.TR / T1)) * Math.exp(-s.TE / T2) * Math.exp(-s.bValue * t.ADC / 1000);
                break;
            }
        }
        if (t.flow) {
            if (s.seq === 'SE' || s.seq === 'FSE' || s.seq === 'IR') sig *= 0.30;
            else if (s.seq === 'DWI') sig *= 0.62;
            else sig *= 1.35;
        }
        if (s.fatSat === 'chemsat' || s.fatSat === 'water_exc') { if (t.fat) sig *= 0.07; }
        else if (s.fatSat === 'stir') { if (t.fat) sig *= 0.05; }
        return sig;
    }
    function computeIntensityMap(s) {
        var map = {}, max = 0.0001;
        if (s.seq === 'DWI' && s.adcMap) {
            /* ADC map: restricted diffusion = DARK (inverse of DWI) */
            Object.keys(TISSUES).forEach(function (k) {
                map[k] = Math.pow(Math.min(TISSUES[k].ADC / 3.0, 1), 0.75);
            });
            map.air = 0.02;
            return map;
        }
        Object.keys(TISSUES).forEach(function (k) {
            var v = tissueSignal(TISSUES[k], s);
            map[k] = v;
            if (k !== 'air' && v > max) max = v;
        });
        Object.keys(map).forEach(function (k) { map[k] = Math.min(1, Math.pow(map[k] / (max * 1.12), 0.92)); });
        map.air = 0.02;
        return map;
    }
    function computeMetrics(s) {
        var pixel = s.FOV / s.matrix;
        var pixelPhase = (s.FOV * s.phaseFOV / 100) / s.matrix;
        var voxel = pixel * pixelPhase * s.thick;
        var phaseSteps = s.matrix * s.phaseFOV / 100;
        var effETL = (s.seq === 'FSE' || s.seq === 'IR') ? Math.max(1, s.ETL) : 1;
        var secs = (s.TR / 1000) * phaseSteps * s.NEX / (effETL * s.PI);
        if (s.seq === 'DWI') secs *= 1.35;
        if (s.seq === 'bSSFP' && s.anatomy.indexOf('cardiac') === 0) secs *= 25;
        var refVoxel = (240 / 256) * (240 / 256) * 6;
        var snr = (voxel / refVoxel) * Math.sqrt(s.NEX) * Math.sqrt(31.25 / s.BW) / s.PI * 100;
        if (s.seq === 'DWI') snr *= 0.3;
        if (s.matrix >= 384) snr *= 0.94;
        var duty = Math.min(3.2, 350 / Math.max(s.TR, 1) * Math.max(1, effETL * 0.35));
        var sar = Math.pow(s.FA / 90, 2) * Math.pow(s.B0 / 1.5, 2) * duty *
                  (s.seq === 'SE' || s.seq === 'FSE' ? 1.5 : 1) * 1.1 * 0.45;
        var dHz = 3.5e-6 * 42.58e6 * s.B0;
        var csPx = Math.round(dHz / ((s.BW * 1000) / s.matrix));
        var wrap = ANATOMY[s.anatomy].phys[1] > (s.FOV * s.phaseFOV / 100) * 1.02;
        return { pixel: pixel, pixelPhase: pixelPhase, voxel: voxel, secs: secs, snr: snr, sar: sar, csPx: csPx, wrap: wrap };
    }

    /* ============================================================
       RENDER
       ============================================================ */
    function drawPrim(c, p, W, H, color) {
        c.fillStyle = color;
        c.strokeStyle = color;
        c.beginPath();
        if (p.shape === 'ellipse') {
            c.ellipse(p.cx * W, p.cy * H, p.rx * W, p.ry * H, p.rot || 0, 0, Math.PI * 2);
            c.fill();
        } else if (p.shape === 'ring') {
            var out = organicPts(p.cx, p.cy, p.rx, p.ry, 5, 0.008, p.seed || 5, 64);
            var inn = organicPts(p.cx, p.cy, p.rxIn, p.ryIn, 5, 0.006, (p.seed || 5) + 1, 64);
            if (p.rot) { c.save(); c.translate(p.cx * W, p.cy * H); c.rotate(p.rot); c.translate(-p.cx * W, -p.cy * H); }
            poly(c, out, W, H); poly(c, inn, W, H);
            c.fill('evenodd');
            if (p.rot) c.restore();
        } else if (p.shape === 'rrect') {
            var r = (p.r || 0) * W, x = p.x * W, y = p.y * H, w = p.w * W, h = p.h * H;
            c.moveTo(x + r, y);
            c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r);
            c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r);
            c.closePath(); c.fill();
        } else if (p.shape === 'poly') {
            poly(c, p.pts, W, H); c.fill();
        } else if (p.shape === 'wedge') {
            c.moveTo(p.cx * W, p.cy * H);
            c.arc(p.cx * W, p.cy * H, p.r * W, p.a0, p.a1);
            c.closePath(); c.fill();
        } else if (p.shape === 'arcband') {
            for (var i = 0; i <= 26; i++) {
                var a = p.a0 + (p.a1 - p.a0) * (i / 26);
                c.moveTo((p.cx + Math.cos(a) * (p.rx - p.th)) * W, (p.cy + Math.sin(a) * (p.ry - p.th)) * H);
                c.arc(p.cx * W, p.cy * H, (p.rx - p.th) * W, a, a + 0.06);
                c.moveTo((p.cx + Math.cos(a) * (p.rx + p.th)) * W, (p.cy + Math.sin(a) * (p.ry + p.th)) * H);
                c.arc(p.cx * W, p.cy * H, (p.rx + p.th) * W, a, a + 0.06);
            }
            c.fill();
        } else if (p.shape === 'band') {
            c.lineWidth = Math.max(1.2, 0.026 * W);
            for (var ring = 0; ring < 2; ring++) {
                c.beginPath();
                for (var t2 = 0; t2 <= 72; t2++) {
                    var th = (t2 / 72) * Math.PI * 2;
                    var wob = Math.sin(th * p.freq + p.phase) * p.amp * (ring ? 1 : 0.55);
                    var X = (p.cx + Math.cos(th) * (p.rx + wob)) * W, Y = (p.cy + Math.sin(th) * (p.ry + wob)) * H;
                    t2 ? c.lineTo(X, Y) : c.moveTo(X, Y);
                }
                c.stroke();
            }
        } else if (p.shape === 'cc') {
            var sc = p.scale || 1;
            c.lineWidth = 0.052 * W * sc; c.lineCap = 'round';
            c.beginPath();
            c.moveTo((0.5 + (0.40 - 0.5) * sc) * W, 0.50 * H);
            c.bezierCurveTo(0.42 * W, (0.50 - 0.105 * sc) * H, 0.60 * W, (0.50 - 0.105 * sc) * H, (0.5 + (0.635 - 0.5) * sc) * W, (0.50 - 0.02 * sc) * H);
            c.bezierCurveTo(0.64 * W, (0.50 + 0.025 * sc) * H, 0.575 * W, (0.50 + 0.045 * sc) * H, (0.5 + (0.505 - 0.5) * sc) * W, (0.50 + 0.035 * sc) * H);
            c.bezierCurveTo(0.44 * W, (0.50 + 0.025 * sc) * H, (0.5 + (0.395 - 0.5) * sc) * W, (0.50 + 0.03 * sc) * H, (0.5 + (0.40 - 0.5) * sc) * W, 0.50 * H);
            c.stroke();
        }
    }
    function poly(c, pts, W, H) {
        c.moveTo(pts[0][0] * W, pts[0][1] * H);
        for (var i = 1; i < pts.length; i++) c.lineTo(pts[i][0] * W, pts[i][1] * H);
        c.closePath();
    }

    function drawPhantom(c, W, H, grayMap, sliceVal, colorMode) {
        var s2 = { slice: sliceVal };
        var anat = ANATOMY[state.anatomy];
        var g = colorMode === 'id'
            ? function (t) { return 'rgb(' + TISSUE_ID[t] + ',0,0)'; }
            : function (t) { return 'rgb(' + Math.round(grayMap[t] * 255) + ',' + Math.round(grayMap[t] * 255) + ',' + Math.round(grayMap[t] * 255) + ')'; };
        anat.prims(Object.assign({}, state, s2)).forEach(function (p) { drawPrim(c, p, W, H, g(p.tissue)); });
        var pathSet = anat.pathologies[state.pathology];
        if (pathSet) pathSet.forEach(function (p) { drawPrim(c, p, W, H, g(p.tissue)); });
    }

    function render() {
        var s = state;
        var anat = ANATOMY[s.anatomy];
        var size = Math.min(s.matrix, 512);
        var ratio = anat.phys[1] / anat.phys[0];
        off.width = size * 2; off.height = Math.round(size * 2 * ratio);
        down.width = size; down.height = Math.round(size * ratio);

        var gray = computeIntensityMap(s);
        var bg = gray[anat.bg];
        var fill = 'rgb(' + Math.round(bg * 255) + ',' + Math.round(bg * 255) + ',' + Math.round(bg * 255) + ')';

        /* --- partial volume: thick slices average neighbouring anatomy --- */
        var stackMm = { cardiac_sax: 90, cardiac_4ch: 90, brain_ax: 140, brain_sag: 160, spine_sag: 100, knee_sag: 90 }[s.anatomy] || 120;
        var dz = (s.thick / 2) / stackMm;                    /* half-thickness in slice units */
        var usePV = dz > 0.008;
        var layerA = null, layerB = null;
        var wMain = 1, wA = 0, wB = 0;

        offCtx.fillStyle = fill;
        offCtx.fillRect(0, 0, off.width, off.height);
        drawPhantom(offCtx, off.width, off.height, gray, s.slice);
        downCtx.imageSmoothingEnabled = true;
        downCtx.clearRect(0, 0, down.width, down.height);
        downCtx.drawImage(off, 0, 0, down.width, down.height);

        if (usePV) {
            /* Gaussian slice profile weights */
            wMain = 0.62; wA = 0.19; wB = 0.19;
            layerA = document.createElement('canvas');
            layerB = document.createElement('canvas');
            layerA.width = layerB.width = down.width;
            layerA.height = layerB.height = down.height;
            var cA = layerA.getContext('2d'), cB = layerB.getContext('2d');
            cA.fillStyle = cB.fillStyle = fill;
            cA.fillRect(0, 0, down.width, down.height);
            cB.fillRect(0, 0, down.width, down.height);
            drawPhantom(cA, down.width, down.height, gray, s.slice - dz);
            drawPhantom(cB, down.width, down.height, gray, s.slice + dz);
        }

        /* --- tissue-ID buffer for per-tissue texture --- */
        var idC = document.createElement('canvas');
        idC.width = down.width; idC.height = down.height;
        var idCtx2 = idC.getContext('2d');
        idCtx2.fillStyle = 'rgb(255,0,0)';  /* default/unknown */
        idCtx2.fillRect(0, 0, down.width, down.height);
        drawPhantom(idCtx2, down.width, down.height, gray, s.slice, 'id');
        var idData = idCtx2.getImageData(0, 0, down.width, down.height).data;

        var m = computeMetrics(s);
        var img = downCtx.getImageData(0, 0, down.width, down.height);
        var d = img.data, W = down.width, H = down.height;
        var dA = layerA ? layerA.getContext('2d').getImageData(0, 0, W, H).data : null;
        var dB = layerB ? layerB.getContext('2d').getImageData(0, 0, W, H).data : null;

        /* chemical shift — fat displaced along frequency axis */
        if (m.csPx > 0) {
            var copy = d.slice();
            for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
                var i0 = (y * W + x) * 4;
                var srcX = x - m.csPx;
                if (srcX < 0) { d[i0] = d[i0 + 1] = d[i0 + 2] = 4; continue; }
                var sI = (y * W + srcX) * 4;
                d[i0] = copy[sI]; d[i0 + 1] = copy[sI + 1]; d[i0 + 2] = copy[sI + 2];
            }
        }
        if (s.metal) {
            var cx = W * 0.33, cy = H * 0.62, R = W * 0.15;
            var copy2 = d.slice();
            for (var y2 = 0; y2 < H; y2++) for (var x2 = 0; x2 < W; x2++) {
                var dx = x2 - cx, dy = y2 - cy, dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < R * 2.6) {
                    var warp = Math.max(0, 1 - dist / (R * 2.6));
                    var push = warp * warp * R * 2.0, ang = Math.atan2(dy, dx);
                    var sx = Math.max(0, Math.min(W - 1, Math.round(cx + Math.cos(ang) * (dist + push))));
                    var sy = Math.max(0, Math.min(H - 1, Math.round(cy + Math.sin(ang) * (dist + push * 0.5))));
                    var vi = (sy * W + sx) * 4, ti = (y2 * W + x2) * 4;
                    if (dist < R * 0.5) { d[ti] = d[ti + 1] = d[ti + 2] = Math.random() < 0.5 ? 255 : 0; }
                    else { d[ti] = copy2[vi]; d[ti + 1] = copy2[vi + 1]; d[ti + 2] = copy2[vi + 2]; }
                }
            }
        }

        /* per-tissue texture + Rician magnitude noise + shading (single pass) */
        var shading = s.B0 >= 3 ? 0.18 : 0.07;
        var sigma = Math.min(46, 255 * 0.55 / Math.sqrt(Math.max(m.snr, 4)));
        for (var y3 = 0; y3 < H; y3++) {
            var fRow = 1 - shading * (y3 / H);
            for (var x3 = 0; x3 < W; x3++) {
                var i3 = (y3 * W + x3) * 4;
                /* partial-volume average */
                var base = d[i3] * wMain;
                if (dA) base += dA[i3] * wA + dB[i3] * wB;

                /* tissue texture from ID buffer */
                var tKey = TISSUE_LIST[idData[i3]] || 'DEFAULT';
                var prof = TEXPROF[tKey] || TEXPROF.DEFAULT;
                if (base > 6 && prof.s > 0.01) {
                    var tk = prof.k, tax = prof.ax;
                    var tex = texAt(x3 * tk, y3 * tk / tax) * 0.6 + texAt(x3 * tk * 0.33 + 7, y3 * tk * 0.33 / tax + 3) * 0.4 - 0.5;
                    base *= 1 + tex * prof.s;
                }
                base *= fRow * (1 - 0.10 * Math.abs(x3 / W - 0.5) * 2);

                /* Rician magnitude noise: mag = sqrt((S+n1)² + n2²) — air keeps a mottled noise floor */
                var n1 = (Math.random() + Math.random() + Math.random() - 1.5) * sigma * 0.85;
                var n2 = (Math.random() + Math.random() + Math.random() - 1.5) * sigma * 0.85;
                var v = Math.sqrt((base + n1) * (base + n1) + n2 * n2);
                if (v > 255) v = 255;
                d[i3] = d[i3 + 1] = d[i3 + 2] = v;
            }
        }
        downCtx.putImageData(img, 0, 0);

        ctx.fillStyle = '#000';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        if (s.motion || s.pulsation) {
            ctx.globalAlpha = s.motion ? 0.32 : 0.18;
            var off1 = s.motion ? canvas.height * 0.08 : canvas.height * 0.035;
            var off2 = s.pulsation ? canvas.height * 0.13 : off1;
            ctx.drawImage(down, 0, -off1, canvas.width, canvas.height);
            ctx.drawImage(down, 0, off2, canvas.width, canvas.height);
            ctx.globalAlpha = 1;
        }
        ctx.imageSmoothingEnabled = true;
        var dispH = m.wrap ? canvas.height * 0.86 : canvas.height;
        var dispY = m.wrap ? canvas.height * 0.14 : 0;
        if (m.wrap) {
            ctx.save();
            ctx.beginPath(); ctx.rect(0, canvas.height - dispY, canvas.width, dispY); ctx.clip();
            ctx.drawImage(down, 0, 0, down.width, down.height * 0.16, 0, canvas.height - dispY, canvas.width, dispY);
            ctx.restore();
            ctx.save();
            ctx.beginPath(); ctx.rect(0, dispY, canvas.width, dispH - dispY); ctx.clip();
        }
        ctx.filter = 'brightness(' + (1 + (state.L - 0.5) * 1.2) + ') contrast(' + (1 / Math.max(state.W, 0.15) * 0.9) + ')';
        ctx.drawImage(down, 0, dispY, canvas.width, dispH);
        ctx.filter = 'none';
        if (m.wrap) ctx.restore();
        if (s.matrix <= 160) {
            ctx.globalAlpha = 0.16;
            ctx.drawImage(canvas, 1, 0, canvas.width - 2, canvas.height, 0, 0, canvas.width, canvas.height);
            ctx.globalAlpha = 1;
        }
        updateMetricsHUD(m);
        updateOrientation(anat.orient);
        drawLocalizer();
    }

    /* ============================================================
       PATIENT MONITOR — ECG + respiration + gating marks
       ============================================================ */
    var ecgBuf = [];
    var ecgPhase = 0, respPhase = 0;
    function ecgWave(p) {
        /* P-QRS-T composite, p in 0..1 */
        var g = 0;
        g += 0.16 * Math.exp(-Math.pow((p - 0.82) * 14, 2));      /* P */
        g += -0.08 * Math.exp(-Math.pow((p - 0.10) * 30, 2));     /* Q */
        g += -1.00 * Math.exp(-Math.pow((p - 0.13) * 16, 2));     /* R */
        g += 0.22 * Math.exp(-Math.pow((p - 0.16) * 20, 2));      /* S */
        g += 0.26 * Math.exp(-Math.pow((p - 0.40) * 8, 2));       /* T */
        return g;
    }
    function startMonitor() {
        var ec = $('ecgCanvas');
        if (!ec) return;
        var c = ec.getContext('2d');
        var W = ec.width, H = ec.height;
        var lastT = null;
        var HR = 68, hrvT = 0;
        (function frame(ts) {
            if (lastT === null) lastT = ts;
            var dt = (ts - lastT) / 1000; lastT = ts;
            ecgPhase = (ecgPhase + dt * (HR / 60)) % 1;
            respPhase = (respPhase + dt * 0.28) % 1;

            /* buffer: [x progress, value, isGate] */
            var gateNow = ecgPhase > 0.10 && ecgPhase < 0.16;
            ecgBuf.push([ecgWave(ecgPhase), Math.sin(respPhase * Math.PI * 2) * 0.5, gateNow]);
            if (ecgBuf.length > W) ecgBuf.shift();

            c.fillStyle = '#02060d';
            c.fillRect(0, 0, W, H);
            /* resp trace (blue, top half) */
            c.strokeStyle = 'rgba(96, 165, 250, 0.85)';
            c.lineWidth = 1.4;
            c.beginPath();
            for (var i = 0; i < ecgBuf.length; i++) {
                var yR = 14 - ecgBuf[i][1] * 10;
                i ? c.lineTo(i, yR) : c.moveTo(i, yR);
            }
            c.stroke();
            /* ECG (green, bottom) */
            c.strokeStyle = '#34d399';
            c.lineWidth = 1.6;
            c.beginPath();
            for (var j = 0; j < ecgBuf.length; j++) {
                var yE = H * 0.68 - ecgBuf[j][0] * (H * 0.44);
                j ? c.lineTo(j, yE) : c.moveTo(j, yE);
            }
            c.stroke();
            /* gating marks (red ticks) */
            c.fillStyle = '#f87171';
            for (var k = 0; k < ecgBuf.length; k++) {
                if (ecgBuf[k][2]) c.fillRect(k, H - 6, 1.5, 5);
            }
            /* sweep cursor */
            c.fillStyle = 'rgba(255,255,255,0.5)';
            c.fillRect(ecgBuf.length - 1, 0, 1, H);

            /* heart-rate variability (slow wander ±4 bpm) */
            hrvT += dt;
            HR = 68 + Math.sin(hrvT * 0.31) * 3.2 + Math.sin(hrvT * 1.13) * 1.1;
            if ($('hrVal')) $('hrVal').textContent = Math.round(HR);
            if ($('rrVal')) $('rrVal').textContent = Math.round(15 + Math.sin(hrvT * 0.21) * 1.5);

            /* ECG-gated cine: image frames lock to the cardiac cycle (retrospective gating) */
            if (state.cinePlaying && state.anatomy.indexOf('cardiac') === 0) {
                var targetFrame = Math.floor(ecgPhase * 25) % 25;
                if (targetFrame !== state.cinePhase) {
                    state.cinePhase = targetFrame;
                    applyCinePhase();
                    render();
                }
            }
            requestAnimationFrame(frame);
        })(performance.now());
    }

    /* ============================================================
       SYSTEM TICKER
       ============================================================ */
    var tickerMsgs = [
        'SYSTEM READY — ' + 'select a protocol from the queue',
        'Magnet field stable · He level 68%',
        'Coil: see COIL selector',
        'RF amplifier OK · gradients OK',
        'Tip: drag the image to adjust W/L · wheel = scroll slices'
    ];
    var tickerIdx = 0;
    function setTicker(msg) { var el = $('consoleTicker'); if (el) el.textContent = msg; }
    function startTicker() {
        setTicker(tickerMsgs[0]);
        setInterval(function () {
            if (acquiring) return;
            tickerIdx = (tickerIdx + 1) % tickerMsgs.length;
            setTicker(tickerMsgs[tickerIdx]);
        }, 6000);
    }

    /* ============================================================
       OSD / HUD / PSD
       ============================================================ */
    function fmtTime(secs) {
        if (secs < 10) return secs.toFixed(1) + ' sec';
        if (secs < 90) return Math.round(secs) + ' sec';
        var min = Math.floor(secs / 60), r = Math.round(secs % 60);
        if (min < 60) return min + ' min ' + (r < 10 ? '0' : '') + r + ' sec';
        return (secs / 3600).toFixed(1) + ' hr';
    }
    function updateMetricsHUD(m) {
        $('hudTime').textContent = fmtTime(m.secs);
        $('hudSNR').textContent = Math.round(m.snr) + '%';
        $('hudPixel').textContent = m.pixel.toFixed(2) + ' x ' + m.pixelPhase.toFixed(2) + ' mm';
        $('hudVoxel').textContent = m.voxel.toFixed(2) + ' mm³';
        var sarEl = $('hudSAR');
        sarEl.textContent = m.sar.toFixed(1) + ' W/kg' + (m.sar > 4 ? ' ⚠' : '');
        sarEl.style.color = m.sar > 4 ? 'var(--red)' : m.sar > 2.5 ? 'var(--yellow)' : 'var(--green)';
        $('hudSNR').style.color = m.snr < 25 ? 'var(--red)' : m.snr < 60 ? 'var(--yellow)' : 'var(--teal)';
        sarEl.classList.toggle('sar-over', m.sar > 4);
    }
    function updateOrientation(o) {
        var el = $('osdOrient');
        if (!el) return;
        el.innerHTML = '<span class="oi-t">' + o[0] + '</span><span class="oi-b">' + o[1] +
                       '</span><span class="oi-l">' + o[2] + '</span><span class="oi-r">' + o[3] + '</span>';
    }
    function updateOSD() {
        var s = state;
        $('osdField').textContent = s.B0.toFixed(1) + 'T MAGNETOM';
        $('osdCoil').textContent = ANATOMY[s.anatomy].coil;
        $('osdTR').textContent = (s.TR < 10 ? s.TR.toFixed(1) : Math.round(s.TR));
        $('osdTE').textContent = (s.TE < 10 ? s.TE.toFixed(1) : Math.round(s.TE));
        $('osdFA').textContent = s.FA;
        var fsMap = { none: 'None', chemsat: 'FatSat', stir: 'STIR', water_exc: 'Water Exc' };
        $('osdFS').textContent = (s.seq === 'DWI' && s.adcMap) ? 'ADC MAP' : fsMap[s.fatSat];
        $('osdFOV').textContent = s.FOV;
        $('osdThick').textContent = s.thick.toFixed(1);
        $('osdMatrix').textContent = s.matrix + ' x ' + Math.round(s.matrix * s.phaseFOV / 100);
        $('osdW').textContent = Math.round(state.W * 255);
        $('osdL').textContent = Math.round(state.L * 255);
        var serEl = $('osdSerIm');
        if (serEl) serEl.textContent = 'Ser 5:8  Im ' + Math.round(state.slice * (SLICES - 1) + 1) + '/' + SLICES;
        var slEl = $('osdSlice');
        if (slEl) slEl.textContent = 'SL ' + Math.round(state.slice * (SLICES - 1) + 1) + '/' + SLICES;
        $('wsCoil').textContent = ANATOMY[s.anatomy].coil;
        var gdBadge = $('osdGd');
        if (gdBadge) gdBadge.style.display = state.gd ? '' : 'none';
        var slD = $('sliceDisplay');
        if (slD) slD.textContent = 'SL ' + Math.round(state.slice * (SLICES - 1) + 1) + '/' + SLICES;
    }

    function drawPSD() {
        var cv = $('psdCanvas');
        if (!cv) return;
        var c = cv.getContext('2d');
        var W = cv.width, H = cv.height, s = state;
        c.clearRect(0, 0, W, H);
        c.fillStyle = 'rgba(4, 8, 16, 0.9)';
        c.fillRect(0, 0, W, H);
        var padL = 46, padR = 10, padT = 8, rowH = (H - padT - 8) / 4;
        var rows = ['RF', 'Gz (slice)', 'Gy (phase)', 'Gx (read)'];
        var cols = ['#7dd3fc', '#c4b5fd', '#f9a8d4', '#6ee7b7'];
        var tMax = Math.min(s.TR, 2200);
        var xOf = function (t) { return padL + (t / tMax) * (W - padL - padR); };
        c.font = '10px Inter, sans-serif';
        for (var r = 0; r < 4; r++) {
            var yC = padT + rowH * r + rowH / 2;
            c.fillStyle = '#7d92bd'; c.textAlign = 'right';
            c.fillText(rows[r], padL - 6, yC + 3);
            c.strokeStyle = 'rgba(120,160,255,0.12)';
            c.beginPath(); c.moveTo(padL, padT + rowH * r); c.lineTo(W - padR, padT + rowH * r); c.stroke();
        }
        function pulse(row, t, w, h) {
            var yC = padT + rowH * row + rowH / 2, x = xOf(t);
            c.fillStyle = cols[row];
            c.beginPath(); c.moveTo(x - w, yC); c.lineTo(x, yC - h); c.lineTo(x + w, yC); c.closePath(); c.fill();
        }
        function trap(row, t0, t1, h) {
            var yC = padT + rowH * row + rowH / 2, x0 = xOf(t0), x1 = xOf(t1), rise = 3;
            c.strokeStyle = cols[row]; c.lineWidth = 1.6;
            c.beginPath(); c.moveTo(x0, yC); c.lineTo(x0 + rise, yC - h); c.lineTo(x1 - rise, yC - h); c.lineTo(x1, yC); c.stroke();
        }
        function stair(row, t0, t1, steps, h) {
            var yC = padT + rowH * row + rowH / 2, x0 = xOf(t0), x1 = xOf(t1);
            c.strokeStyle = cols[row]; c.lineWidth = 1.6;
            c.beginPath(); c.moveTo(x0, yC);
            for (var i = 0; i <= steps; i++) {
                var xi = x0 + (x1 - x0) * (i / steps), yi = yC - h * (i / steps);
                c.lineTo(xi, yi); c.lineTo(xi + (x1 - x0) / steps * 0.8, yi);
            }
            c.stroke();
        }
        var TE = Math.min(s.TE, tMax * 0.9);
        if (s.seq === 'SE' || s.seq === 'FSE') {
            pulse(0, 6, 6, rowH * 0.38);
            trap(1, 2, 12, rowH * 0.3);
            if (s.seq === 'FSE') {
                var etl = Math.min(s.ETL, 12);
                for (var e = 0; e < etl; e++) {
                    var te = TE + (tMax - TE - 30) * (e / etl);
                    pulse(0, te, 5, rowH * 0.3); pulse(1, te - 6, 4, rowH * 0.28);
                    trap(3, te - 14, te - 4, rowH * 0.34);
                }
            } else {
                pulse(0, TE, 5, rowH * 0.3); pulse(1, TE - 6, 4, rowH * 0.28);
                trap(3, TE - 14, TE - 4, rowH * 0.34);
            }
            stair(2, 14, TE - 16, 5, rowH * 0.3);
        } else if (s.seq === 'GRE' || s.seq === 'bSSFP') {
            pulse(0, 6, 6, rowH * 0.32);
            trap(1, 2, 12, rowH * 0.3);
            stair(2, 14, TE - 8, 4, rowH * 0.28);
            trap(3, TE - 10, TE + 6, rowH * 0.34);
            if (s.seq === 'bSSFP') { trap(3, TE + 10, TE + 26, rowH * 0.34); trap(2, TE + 14, TE + 30, rowH * 0.24); }
        } else if (s.seq === 'IR') {
            pulse(0, 6, 6, rowH * 0.38);
            var TIx = Math.min(s.TI, tMax * 0.6);
            pulse(0, TIx, 5, rowH * 0.3);
            var TE2 = Math.max(TIx + 20, TE * 0.9);
            if (TE2 < tMax) { pulse(0, TE2, 4, rowH * 0.24); trap(3, TE2 - 12, TE2 - 2, rowH * 0.3); }
            stair(2, TIx + 10, TE2 - 10, 5, rowH * 0.28);
            trap(1, 2, 12, rowH * 0.3);
        } else if (s.seq === 'DWI') {
            pulse(0, 6, 6, rowH * 0.38); pulse(0, 60, 5, rowH * 0.3);
            trap(2, 12, 55, rowH * 0.4); trap(2, 63, 106, rowH * 0.4);
            trap(3, TE - 12, TE - 2, rowH * 0.34);
        }
        c.strokeStyle = 'rgba(255,255,255,0.5)'; c.setLineDash([4, 4]);
        c.beginPath(); c.moveTo(xOf(TE), padT); c.lineTo(xOf(TE), H - 20); c.stroke();
        c.setLineDash([]);
        c.fillStyle = '#fbbf24'; c.textAlign = 'left';
        c.fillText('TE ' + (s.TE < 10 ? s.TE.toFixed(1) : Math.round(s.TE)) + ' ms', Math.min(xOf(TE) + 4, W - 60), padT + 10);
        c.fillStyle = '#7d92bd';
        c.fillText('window: ' + Math.round(tMax) + ' of TR ' + Math.round(s.TR) + ' ms', padL, H - 6);
    }

    /* ============================================================
       CONTROL WIRING
       ============================================================ */
    window.updateSimulation = function () {
        state.B0 = parseFloat($('wsFieldStrength').value);
        state.seq = $('paramSeqType').value;
        state.TR = parseFloat($('sliderTR').value);
        state.TE = parseFloat($('sliderTE').value);
        state.TI = parseFloat($('sliderTI').value);
        state.FA = parseFloat($('sliderFA').value);
        var bRaw = parseFloat($('sliderB').value);
        state.bValue = isNaN(bRaw) ? 1000 : bRaw;
        state.fatSat = $('paramFatSat').value;
        state.anatomy = $('paramAnatomy').value;
        state.pathology = $('paramPathology').value;
        state.gd = $('btnGd') ? $('btnGd').classList.contains('gd-on') : false;
        state.FOV = parseFloat($('sliderFOV').value);
        state.matrix = parseInt($('paramMatrix').value, 10);
        state.thick = parseFloat($('sliderThick').value);
        state.phaseFOV = parseFloat($('sliderPhaseFOV').value);
        state.NEX = parseInt($('sliderNEX').value, 10);
        state.ETL = parseInt($('sliderETL').value, 10);
        state.PI = parseFloat($('paramPI').value);
        state.BW = parseFloat($('paramBW').value);
        state.motion = $('art_motion').checked;
        state.metal = $('art_metal').checked;
        state.pulsation = $('art_pulsation') ? $('art_pulsation').checked : false;
        state.adcMap = $('chkADC') ? $('chkADC').checked : false;

        $('valTR').textContent = (state.TR < 10 ? state.TR.toFixed(1) : Math.round(state.TR)) + ' ms';
        $('valTE').textContent = (state.TE < 10 ? state.TE.toFixed(1) : Math.round(state.TE)) + ' ms';
        $('valTI').textContent = Math.round(state.TI) + ' ms';
        $('valFA').textContent = state.FA + '°';
        $('valB').textContent = state.bValue;
        $('valFOV').textContent = state.FOV + ' mm';
        $('valThick').textContent = state.thick.toFixed(1) + ' mm';
        $('valPhaseFOV').textContent = state.phaseFOV + '%';
        $('valNEX').textContent = state.NEX;
        $('valETL').textContent = state.ETL;

        $('groupB').style.display = (state.seq === 'DWI') ? '' : 'none';
        $('groupTI').style.display = (state.seq === 'IR') ? '' : 'none';
        $('groupETL').style.display = (state.seq === 'FSE' || state.seq === 'IR') ? '' : 'none';
        $('groupPath').style.display = (Object.keys(ANATOMY[state.anatomy].pathologies).length > 1) ? '' : 'none';

        updateOSD();
        drawPSD();
        render();
    };

    window.onSliceSlider = function (v) {
        state.slice = (parseInt(v, 10) - 1) / (SLICES - 1);
        updateOSD();
        render();
        setTicker('Slice position: ' + Math.round(state.slice * (SLICES - 1) + 1) + '/' + SLICES + ' · table reference saved');
    };

    window.toggleGrid = function () {
        var wrapEl = $('canvasWrapper');
        if (wrapEl) wrapEl.classList.toggle('show-grid');
    };

    window.switchTab = function (tab) {
        ['contrast', 'geometry', 'accel', 'artifacts', 'timing'].forEach(function (t) {
            var pane = $('tab-' + t);
            if (pane) pane.classList.toggle('active', t === tab);
        });
        document.querySelectorAll('.tab-btn').forEach(function (b) { b.classList.remove('active'); });
        var btn = document.querySelector('.tab-btn[onclick*="' + tab + '"]');
        if (btn) btn.classList.add('active');
    };

    window.onSeqTypeChange = function () {
        var seq = $('paramSeqType').value;
        var presets = {
            SE: { TR: 500, TE: 12, FA: 90 },
            FSE: { TR: 4000, TE: 100, FA: 90, ETL: 16 },
            IR: { TR: 9000, TE: 90, TI: 2500, FA: 90, ETL: 20 },
            GRE: { TR: 200, TE: 5, FA: 30 },
            bSSFP: { TR: 3.2, TE: 1.6, FA: 60 },
            DWI: { TR: 5000, TE: 70, FA: 90, B: 1000 }
        }[seq] || {};
        if (presets.TR !== undefined) $('sliderTR').value = presets.TR;
        if (presets.TE !== undefined) $('sliderTE').value = presets.TE;
        if (presets.FA !== undefined) $('sliderFA').value = presets.FA;
        if (presets.TI !== undefined) $('sliderTI').value = presets.TI;
        if (presets.ETL !== undefined) $('sliderETL').value = presets.ETL;
        if (presets.B !== undefined) $('sliderB').value = presets.B;
        updateSimulation();
    };

    window.onAnatomyChange = function () {
        state.anatomy = $('paramAnatomy').value;
        $('wsStudyName').textContent = ANATOMY[state.anatomy].study;
        var sel = $('paramPathology');
        sel.innerHTML = '';
        Object.keys(ANATOMY[state.anatomy].pathologies).forEach(function (pk) {
            var opt = document.createElement('option');
            opt.value = pk;
            var plist = ANATOMY[state.anatomy].pathologies[pk];
            opt.textContent = pk === 'none' ? 'None — normal study' : (TISSUES[plist[0].tissue].path || pk);
            sel.appendChild(opt);
        });
        var names = { cardiac_sax: 'Cardiac SAX', cardiac_4ch: 'Cardiac 4-Ch', brain_ax: 'Brain', brain_sag: 'Brain', spine_sag: 'Lumbar Spine', knee_sag: 'Knee' };
        $('displaySeqName').textContent = names[state.anatomy] + ' — ' + $('paramSeqType').options[$('paramSeqType').selectedIndex].text;
        if (state.cinePlaying && state.anatomy.indexOf('cardiac') === -1) toggleCinePlay();
        if (!state.cinePlaying && state.anatomy.indexOf('cardiac') !== -1 && state.seq === 'bSSFP') toggleCinePlay();
        updateSimulation();
    };

    /* ---------- presets ---------- */
    var PRESETS = {
        cardiac_cine: { seq: 'bSSFP', TR: 3.2, TE: 1.6, FA: 60, fatSat: 'none', anatomy: 'cardiac_sax', pathology: 'none', slice: 0.5,
                        FOV: 340, matrix: 256, thick: 8, phaseFOV: 100, NEX: 1, ETL: 1, PI: 2, BW: 62.5, cine: true,
                        name: 'Cardiac Cine bSSFP (SAX)', patient: 'DOE^JOHN' },
        cardiac_4ch:  { seq: 'bSSFP', TR: 3.4, TE: 1.5, FA: 60, fatSat: 'none', anatomy: 'cardiac_4ch', pathology: 'none', slice: 0.5,
                        FOV: 360, matrix: 256, thick: 6, phaseFOV: 100, NEX: 1, ETL: 1, PI: 2, BW: 62.5, cine: true,
                        name: 'Cardiac 4-Chamber Cine — long axis', patient: 'DOE^JOHN' },
        cardiac_lge:  { seq: 'IR', TR: 6.9, TE: 3.1, TI: 300, FA: 20, fatSat: 'none', anatomy: 'cardiac_sax', pathology: 'scar', slice: 0.6,
                        FOV: 340, matrix: 256, thick: 8, phaseFOV: 100, NEX: 1, ETL: 1, PI: 2, BW: 31.25, gd: true,
                        name: 'Cardiac LGE (PSIR) — Scar', patient: 'DOE^JOHN' },
        brain_t1:     { seq: 'SE', TR: 500, TE: 12, FA: 90, fatSat: 'none', anatomy: 'brain_ax', pathology: 'none', slice: 0.5,
                        FOV: 220, matrix: 256, thick: 5, phaseFOV: 100, NEX: 1, ETL: 1, PI: 1, BW: 31.25,
                        name: 'Brain T1 Spin Echo (Axial)', patient: 'SMITH^MARY' },
        brain_t1_sag: { seq: 'SE', TR: 480, TE: 12, FA: 90, fatSat: 'none', anatomy: 'brain_sag', pathology: 'none', slice: 0.5,
                        FOV: 230, matrix: 256, thick: 4, phaseFOV: 100, NEX: 1, ETL: 1, PI: 1, BW: 31.25,
                        name: 'Brain T1 SAGITTAL — Midline', patient: 'SMITH^MARY' },
        brain_t2:     { seq: 'FSE', TR: 4500, TE: 100, FA: 90, fatSat: 'none', anatomy: 'brain_ax', pathology: 'none', slice: 0.5,
                        FOV: 220, matrix: 256, thick: 5, phaseFOV: 100, NEX: 1, ETL: 16, PI: 2, BW: 31.25,
                        name: 'Brain T2 FSE (Axial)', patient: 'SMITH^MARY' },
        brain_flair:  { seq: 'IR', TR: 9000, TE: 90, TI: 2500, FA: 90, fatSat: 'none', anatomy: 'brain_ax', pathology: 'ms', slice: 0.5,
                        FOV: 220, matrix: 256, thick: 5, phaseFOV: 100, NEX: 1, ETL: 20, PI: 2, BW: 31.25,
                        name: 'Brain FLAIR — MS plaques', patient: 'SMITH^MARY' },
        brain_dwi:    { seq: 'DWI', TR: 5000, TE: 70, FA: 90, fatSat: 'none', anatomy: 'brain_ax', pathology: 'stroke', slice: 0.5, B: 1000,
                        FOV: 240, matrix: 128, thick: 5, phaseFOV: 100, NEX: 4, ETL: 1, PI: 2, BW: 62.5,
                        name: 'Stroke DWI b=1000 — acute infarct', patient: 'SMITH^MARY' },
        brain_gre_swi:{ seq: 'GRE', TR: 600, TE: 24, FA: 20, fatSat: 'none', anatomy: 'brain_ax', pathology: 'hemorrhage', slice: 0.5,
                        FOV: 220, matrix: 256, thick: 4, phaseFOV: 100, NEX: 1, ETL: 1, PI: 2, BW: 31.25,
                        name: 'SWI/T2* GRE — microhemorrhage', patient: 'SMITH^MARY' },
        brain_t1_gd:  { seq: 'SE', TR: 520, TE: 12, FA: 90, fatSat: 'none', anatomy: 'brain_ax', pathology: 'tumor', slice: 0.5, gd: true,
                        FOV: 220, matrix: 256, thick: 5, phaseFOV: 100, NEX: 1, ETL: 1, PI: 1, BW: 31.25,
                        name: 'Brain T1 POST-GADOLINIUM — tumor', patient: 'SMITH^MARY' },
        spine_t2:     { seq: 'FSE', TR: 4000, TE: 110, FA: 90, fatSat: 'none', anatomy: 'spine_sag', pathology: 'none', slice: 0.5,
                        FOV: 280, matrix: 256, thick: 4, phaseFOV: 90, NEX: 2, ETL: 20, PI: 2, BW: 31.25,
                        name: 'Lumbar Spine T2 (Sagittal)', patient: 'JONES^ROBERT' },
        spine_stir:   { seq: 'IR', TR: 3500, TE: 30, TI: 160, FA: 90, fatSat: 'stir', anatomy: 'spine_sag', pathology: 'mets', slice: 0.5,
                        FOV: 280, matrix: 256, thick: 4, phaseFOV: 100, NEX: 1, ETL: 14, PI: 2, BW: 31.25,
                        name: 'Spine STIR — metastases', patient: 'JONES^ROBERT' },
        knee_pd:      { seq: 'FSE', TR: 3000, TE: 25, FA: 90, fatSat: 'chemsat', anatomy: 'knee_sag', pathology: 'none', slice: 0.5,
                        FOV: 160, matrix: 256, thick: 3.5, phaseFOV: 100, NEX: 2, ETL: 12, PI: 2, BW: 31.25,
                        name: 'Knee PD FatSat (Sagittal)', patient: 'JONES^ROBERT' },
        knee_stir:    { seq: 'IR', TR: 3800, TE: 28, TI: 160, FA: 90, fatSat: 'stir', anatomy: 'knee_sag', pathology: 'bruise', slice: 0.5,
                        FOV: 160, matrix: 256, thick: 3.5, phaseFOV: 100, NEX: 1, ETL: 10, PI: 2, BW: 31.25,
                        name: 'Knee STIR — bone bruise', patient: 'JONES^ROBERT' }
    };

    window.loadPreset = function (key) {
        var p = PRESETS[key];
        if (!p) return;
        document.querySelectorAll('.proto-btn').forEach(function (b) { b.classList.remove('active'); });
        var btn = document.querySelector('.proto-btn[onclick*="' + key + '"]');
        if (btn) btn.classList.add('active');
        $('paramSeqType').value = p.seq;
        $('sliderTR').value = p.TR; $('sliderTE').value = p.TE; $('sliderFA').value = p.FA;
        if (p.TI) $('sliderTI').value = p.TI;
        if (p.ETL) $('sliderETL').value = p.ETL;
        $('sliderB').value = p.B || 1000;
        $('paramFatSat').value = p.fatSat;
        $('paramAnatomy').value = p.anatomy;
        $('sliderFOV').value = p.FOV;
        $('paramMatrix').value = String(p.matrix);
        $('sliderThick').value = p.thick;
        $('sliderPhaseFOV').value = p.phaseFOV;
        $('sliderNEX').value = p.NEX;
        $('paramPI').value = String(p.PI);
        $('paramBW').value = String(p.BW);
        $('art_motion').checked = false;
        $('art_metal').checked = false;
        if ($('art_pulsation')) $('art_pulsation').checked = false;
        state.anatomy = p.anatomy;
        onAnatomyChange();
        $('paramPathology').value = p.pathology;
        var gdBtn = $('btnGd');
        if (gdBtn) gdBtn.classList.toggle('gd-on', !!p.gd);
        state.slice = p.slice !== undefined ? p.slice : 0.5;
        var slEl = $('sliceSlider');
        if (slEl) slEl.value = String(Math.round(state.slice * (SLICES - 1)) + 1);
        $('wsPatName').textContent = p.patient;
        $('wsStudyName').textContent = ANATOMY[p.anatomy].study;
        $('displaySeqName').textContent = p.name;
        if (p.cine && !state.cinePlaying) toggleCinePlay();
        if (!p.cine && state.cinePlaying) toggleCinePlay();
        setTicker('Protocol loaded: ' + p.name);
        updateSimulation();
    };

    function advanceWorklist() {
        var active = document.querySelector('.proto-btn.active');
        if (!active) return;
        var next = active.nextElementSibling;
        while (next && !next.classList.contains('proto-btn')) next = next.nextElementSibling;
        if (!next) return;
        var key = next.getAttribute('onclick').match(/'([^']+)'/);
        if (!key) return;
        setTimeout(function () {
            loadPreset(key[1]);
            var osd = $('displaySeqName');
            osd.style.color = 'var(--teal)';
            setTimeout(function () { osd.style.color = ''; }, 1600);
        }, 1400);
    }

    /* ---------- cine ---------- */
    var cineRAF = null;
    function applyCinePhase() {
        var ph = state.cinePhase;
        var t = Math.cos((ph / 24) * Math.PI * 2);
        state.cineFactor = 0.60 + 0.40 * (0.5 + 0.5 * t);
        var label = (ph > 5 && ph < 14) ? 'Systole' : 'Diastole';
        $('cinePhaseDisplay').textContent = 'Phase ' + (ph + 1) + ' / 25 (' + label + ')';
        $('osdPhase').textContent = (ph + 1) + ' / 25';
        $('cineSlider').value = ph;
    }
    window.onCineSlider = function (v) {
        state.cinePhase = parseInt(v, 10) % 25;
        applyCinePhase(); render();
    };
    window.toggleCinePlay = function () {
        state.cinePlaying = !state.cinePlaying;
        $('btnCinePlay').innerHTML = state.cinePlaying
            ? '<i class="fas fa-pause"></i> Pause' : '<i class="fas fa-play"></i> Cine Loop';
        if (state.cinePlaying && state.anatomy.indexOf('cardiac') !== 0) {
            /* non-cardiac cine: fixed-rate playback (e.g. CSF studies) */
            var last = 0, fps = 12;
            (function loop(ts) {
                if (!state.cinePlaying) return;
                if (ts - last > 1000 / fps) {
                    last = ts;
                    state.cinePhase = (state.cinePhase + 1) % 25;
                    applyCinePhase(); render();
                }
                cineRAF = requestAnimationFrame(loop);
            })(performance.now());
        } else if (cineRAF) cancelAnimationFrame(cineRAF);
    };

    /* ---------- audio ---------- */
    var audioEnabled = true, audioCtx = null;
    function ensureAudio() {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (audioCtx.state === 'suspended') audioCtx.resume();
        return audioCtx;
    }
    function playGradientNoise(duration) {
        if (!audioEnabled) return;
        try {
            var ctxA = ensureAudio();
            var bufSize = Math.floor(ctxA.sampleRate * duration);
            var buffer = ctxA.createBuffer(1, bufSize, ctxA.sampleRate);
            var data = buffer.getChannelData(0);
            for (var i = 0; i < bufSize; i++) {
                var beat = (Math.sin(i / ctxA.sampleRate * 2 * Math.PI * 7) > 0.1) ? 1 : 0.15;
                data[i] = (Math.random() * 2 - 1) * 0.35 * beat;
            }
            var src = ctxA.createBufferSource(); src.buffer = buffer;
            var bp = ctxA.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1100; bp.Q.value = 0.8;
            var gain = ctxA.createGain();
            gain.gain.setValueAtTime(0.0001, ctxA.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.12, ctxA.currentTime + 0.08);
            gain.gain.setValueAtTime(0.12, ctxA.currentTime + duration - 0.25);
            gain.gain.exponentialRampToValueAtTime(0.0001, ctxA.currentTime + duration);
            src.connect(bp); bp.connect(gain); gain.connect(ctxA.destination);
            src.start();
        } catch (e) {}
    }
    function playEndBeep() {
        if (!audioEnabled) return;
        try {
            var ctxA = ensureAudio();
            [0, 0.28, 0.56].forEach(function (t0) {
                var o = ctxA.createOscillator(), g = ctxA.createGain();
                o.type = 'sine'; o.frequency.value = 1046;
                g.gain.setValueAtTime(0.0001, ctxA.currentTime + t0);
                g.gain.exponentialRampToValueAtTime(0.14, ctxA.currentTime + t0 + 0.02);
                g.gain.exponentialRampToValueAtTime(0.0001, ctxA.currentTime + t0 + 0.16);
                o.connect(g); g.connect(ctxA.destination);
                o.start(ctxA.currentTime + t0); o.stop(ctxA.currentTime + t0 + 0.2);
            });
        } catch (e) {}
    }
    window.toggleAudio = function () {
        audioEnabled = !audioEnabled;
        $('btnAudioToggle').innerHTML = audioEnabled
            ? '<i class="fas fa-volume-up"></i> Gradient Sound: <strong id="audioStatusText">ON</strong>'
            : '<i class="fas fa-volume-xmark"></i> Gradient Sound: <strong id="audioStatusText">OFF</strong>';
    };

    /* ---------- acquisition with adjustment phases ---------- */
    var acquiring = false;
    var acquireBtn = null;
    function btnFill(pct) {
        if (!acquireBtn) acquireBtn = document.getElementById('btnRunScan') || document.querySelector('.btn-scan-run');
        if (!acquireBtn) return;
        acquireBtn.classList.add('is-loading');
        acquireBtn.style.setProperty('--lb', pct + '%');
        var fill = acquireBtn.querySelector('.lb-fill');
        if (!fill) {
            fill = document.createElement('span');
            fill.className = 'lb-fill';
            acquireBtn.prepend(fill);
            var lbl = acquireBtn.querySelector('i:last-child') || acquireBtn.lastChild;
        }
        fill.style.transform = 'scaleX(' + (pct / 100) + ')';
    }
    function btnFillDone() {
        if (!acquireBtn) acquireBtn = document.getElementById('btnRunScan') || document.querySelector('.btn-scan-run');
        if (!acquireBtn) return;
        acquireBtn.classList.remove('is-loading');
        var fill = acquireBtn.querySelector('.lb-fill');
        if (fill) fill.style.transform = 'scaleX(0)';
    }
    window.triggerAcquisition = function () {
        if (acquiring) return;
        var m = computeMetrics(state);
        if (m.sar > 4.0) {
            var el = $('hudSAR');
            el.classList.add('sar-over');
            $('scanProgressOverlay').style.display = 'flex';
            $('scanProgressOverlay').innerHTML = '<div class="scan-spinner"></div>' +
                '<div class="scan-text" style="color:var(--red)">⚠ SAR LIMIT EXCEEDED (' + m.sar.toFixed(1) + ' W/kg &gt; 4.0)</div>' +
                '<div class="scan-text" style="font-size:0.75rem">Reduce flip angle or lengthen TR</div>';
            setTicker('⚠ PSD CHECK FAILED — SAR above first-level mode');
            setTimeout(function () {
                $('scanProgressOverlay').style.display = 'none';
                el.classList.remove('sar-over');
                btnFillDone();
            }, 2600);
            return;
        }
        acquiring = true;
        btnFill(2);   /* immediate loading state — don't wait for first rAF */
        var overlay = $('scanProgressOverlay');
        overlay.innerHTML = '<div class="scan-spinner"></div>' +
            '<div class="scan-text" id="acqPhaseText">PRE-SCAN ADJUSTMENT…</div>' +
            '<div class="scan-progress-bar"><div class="scan-fill" id="scanProgressBarFill"></div></div>' +
            '<div class="scan-sub" id="acqSubText"></div>' +
            '<canvas id="ksMini" width="96" height="96"></canvas>';
        overlay.style.display = 'flex';

        /* timeline: adjustments 1.8s, then acquisition 2.4s */
        var PHASES = [
            [0, 600, 'COIL TUNING…', 'Impedance match · ' + ANATOMY[state.anatomy].coil],
            [600, 1200, 'AUTO SHIM…', 'B0 homogeneity optimization'],
            [1200, 1800, 'TX/RX GAIN…', 'Reference voltage calibration'],
            [1800, 4200, 'ACQUIRING K-SPACE…', '']
        ];
        playGradientNoise(2.4);
        setTimeout(function () { render(); }, 100);
        var finalImg = null;
        var mini = $('ksMini'), miniCtx = mini ? mini.getContext('2d') : null;
        if (miniCtx) { miniCtx.fillStyle = '#02040a'; miniCtx.fillRect(0, 0, 96, 96); }
        var t0 = null;
        (function step(ts) {
            if (!t0) t0 = ts;
            var t = ts - t0;
            var ph = PHASES.find(function (P) { return t >= P[0] && t < P[1]; }) || PHASES[PHASES.length - 1];
            var phaseEl = $('acqPhaseText'), subEl = $('acqSubText');
            if (phaseEl) phaseEl.textContent = ph[2];
            if (subEl) {
                if (t < 1800) subEl.textContent = ph[3];
                else {
                    var p = Math.min((t - 1800) / 2400, 1);
                    var pe = Math.round(p * state.matrix * state.phaseFOV / 100);
                    var remS = Math.max(0, Math.round((1 - p) * m.secs));
                    subEl.textContent = 'SCAN ' + Math.round(p * 100) + '%  ·  PE ' + pe + '/' + Math.round(state.matrix * state.phaseFOV / 100) +
                                        '  ·  REMAINING 0:' + (remS < 10 ? '0' : '') + remS;
                }
            }
            var scanP = Math.max(0, Math.min((t - 1800) / 2400, 1));
            var overall = t < 1800 ? (t / 1800) * 18 : 18 + scanP * 82;
            $('scanProgressBarFill').style.width = overall + '%';
            btnFill(overall);

            if (t >= 1800) {
                if (!finalImg) { render(); finalImg = ctx.getImageData(0, 0, canvas.width, canvas.height); }
                var rows = Math.floor(scanP * canvas.height);
                ctx.putImageData(finalImg, 0, 0, 0, 0, canvas.width, Math.max(rows, 1));
                ctx.fillStyle = '#020409';
                ctx.fillRect(0, rows, canvas.width, canvas.height - rows);
                if (rows > 0 && rows < canvas.height) {
                    ctx.fillStyle = 'rgba(0,180,255,0.55)';
                    ctx.fillRect(0, rows - 2, canvas.width, 2);
                }
                if (miniCtx) {
                    var mr = Math.floor(scanP * 96);
                    for (var ln = 0; ln < mr; ln++) for (var lx = 0; lx < 96; lx += 2) {
                        var v = Math.random();
                        if (v > 0.82) {
                            var cent = 1 - Math.abs(lx - 48) / 48 - Math.abs(ln - 48) / 48;
                            var b = Math.round(40 + 215 * Math.max(cent, 0.08) * v);
                            miniCtx.fillStyle = 'rgb(' + b + ',' + Math.round(b * 0.85) + ',' + Math.round(b * 0.4) + ')';
                            miniCtx.fillRect(lx, ln, 2, 1);
                        }
                    }
                }
                setTicker('Scanning… ' + Math.round(scanP * 100) + '%');
            } else {
                setTicker(ph[2] + ' ' + ph[3]);
            }

            if (t < 4200) { requestAnimationFrame(step); }
            else {
                playEndBeep();
                if (finalImg) ctx.putImageData(finalImg, 0, 0);
                setTicker('✔ Measurement complete — ' + $('displaySeqName').textContent);
                setTimeout(function () {
                    overlay.style.display = 'none';
                    acquiring = false;
                    btnFillDone();
                    advanceWorklist();
                }, 350);
            }
        })(performance.now());
    };

    /* ---------- W/L + probe + wheel + export ---------- */
    var dragging = false, lastX = 0, lastY = 0;
    canvas.addEventListener('mousedown', function (e) { dragging = true; lastX = e.clientX; lastY = e.clientY; });
    window.addEventListener('mouseup', function () { dragging = false; });
    canvas.addEventListener('wheel', function (e) {
        e.preventDefault();
        var cur = Math.round(state.slice * (SLICES - 1)) + 1;
        cur += (e.deltaY > 0 ? 1 : -1);
        cur = Math.max(1, Math.min(SLICES, cur));
        var slEl = $('sliceSlider');
        if (slEl) slEl.value = String(cur);
        onSliceSlider(String(cur));
    }, { passive: false });
    canvas.addEventListener('mousemove', function (e) {
        if (dragging) {
            state.W = Math.min(2.5, Math.max(0.15, state.W + (e.clientX - lastX) / 300));
            state.L = Math.min(1.2, Math.max(-0.2, state.L + (e.clientY - lastY) / 300));
            lastX = e.clientX; lastY = e.clientY;
            updateOSD(); render();
        }
        var r = canvas.getBoundingClientRect();
        var px = Math.max(0, Math.min(canvas.width - 1, Math.floor((e.clientX - r.left) / r.width * canvas.width)));
        var py = Math.max(0, Math.min(canvas.height - 1, Math.floor((e.clientY - r.top) / r.height * canvas.height)));
        var v = ctx.getImageData(px, py, 1, 1).data[0];
        $('osdSignalProbe').textContent = 'Sig ' + v + ' [' + px + ',' + py + ']';
    });
    window.resetWindowLevel = function () { state.W = 1.0; state.L = 0.5; updateOSD(); render(); };

    window.exportSnapshot = function () {
        try {
            var outC = document.createElement('canvas');
            outC.width = canvas.width + 160; outC.height = canvas.height + 60;
            var oc = outC.getContext('2d');
            oc.fillStyle = '#000'; oc.fillRect(0, 0, outC.width, outC.height);
            oc.drawImage(canvas, 0, 0);
            oc.fillStyle = '#7dd3fc'; oc.font = '13px monospace';
            oc.fillText('SEENmri Clinical Sim', canvas.width + 10, 22);
            oc.fillStyle = '#fff';
            oc.fillText($('wsPatName').textContent, canvas.width + 10, 44);
            oc.fillText($('displaySeqName').textContent.slice(0, 18), canvas.width + 10, 64);
            oc.fillText('TR ' + $('osdTR').textContent + '  TE ' + $('osdTE').textContent + '  FA ' + $('osdFA').textContent + '\u00B0', canvas.width + 10, 86);
            oc.fillText('FOV ' + $('osdFOV').textContent + '  ' + $('osdMatrix').textContent, canvas.width + 10, 108);
            oc.fillText('W ' + $('osdW').textContent + '  L ' + $('osdL').textContent, canvas.width + 10, 130);
            oc.fillStyle = '#6ee7b7';
            oc.fillText('EDUCATIONAL SIMULATION', 10, outC.height - 10);
            var a = document.createElement('a');
            a.download = 'seenmri_' + state.anatomy + '_' + Date.now() + '.png';
            a.href = outC.toDataURL('image/png');
            a.click();
            if (window.toast) window.toast('Snapshot exported as PNG', 'success');
        } catch (e) {}
    };

    /* ---------- init ---------- */
    function init() {
        applyCinePhase();
        onSeqTypeChange();
        loadPreset('cardiac_cine');
        switchTab('contrast');
        startMonitor();
        startTicker();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
