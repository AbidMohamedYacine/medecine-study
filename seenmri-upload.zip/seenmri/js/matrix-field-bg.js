/* Exact ThreeUI Matrix Field source mounted as a full-page background. */
(function () {
  'use strict';
  var frame = document.createElement('iframe');
  frame.className = 'matrix-field-background';
  frame.title = 'Matrix Field background';
  frame.setAttribute('aria-hidden', 'true');
  frame.setAttribute('sandbox', 'allow-scripts');
  frame.src = 'backgrounds/matrix-field.html?theme=dark';
  frame.dataset.theme = 'dark';
  document.body.insertBefore(frame, document.body.firstChild);

  function syncTheme() {
    var theme = document.documentElement.getAttribute('data-theme') || 'dark';
    var filters = {
      dark: 'hue-rotate(0deg) saturate(1) brightness(.72)',
      light: 'hue-rotate(12deg) saturate(.82) brightness(1.18)',
      aurora: 'hue-rotate(42deg) saturate(1.25) brightness(.82)',
      ocean: 'hue-rotate(145deg) saturate(1.3) brightness(.82)',
      sunset: 'hue-rotate(-28deg) saturate(1.2) brightness(.78)'
    };
    /* Theme-matched grading keeps the authored Matrix Field renderer intact
       while shifting its light beams toward Seen MRI's active palette. */
    var grades = {
      dark: 'hue-rotate(112deg) saturate(1.65) brightness(1.08)',
      light: 'hue-rotate(112deg) saturate(1.75) brightness(1.28)',
      aurora: 'hue-rotate(270deg) saturate(1.8) brightness(1.08)',
      ocean: 'hue-rotate(185deg) saturate(1.7) brightness(1.08)',
      sunset: 'hue-rotate(112deg) saturate(1.75) brightness(1.16)'
    };
    var colors = {
      dark: [0.08, 1.0, 0.72],
      light: [1.0, 0.98, 0.92],
      aurora: [0.72, 0.22, 1.0],
      ocean: [0.05, 0.62, 1.0],
      sunset: [0.02, 0.58, 0.42]
    };
    frame.dataset.theme = theme;
    frame.contentWindow && frame.contentWindow.postMessage({ type: 'seenmri-theme-color', color: colors[theme] || colors.dark }, '*');
  }
  syncTheme();
  function relayPointer(e) {
    frame.contentWindow && frame.contentWindow.postMessage({ type: 'seenmri-pointer', x: e.clientX, y: e.clientY }, '*');
  }
  window.addEventListener('pointermove', relayPointer, { passive: true });
  window.addEventListener('pointerleave', function () {
    frame.contentWindow && frame.contentWindow.postMessage({ type: 'seenmri-pointer', x: innerWidth / 2, y: innerHeight / 2 }, '*');
  }, { passive: true });
  new MutationObserver(syncTheme).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
})();
