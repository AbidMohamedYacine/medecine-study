/* ============================================================
   SEENmri — atlas.js
   Scan Atlas page:
   1) Sequence Contrast Comparator (A/B slider, live physics)
   2) Artifact Atlas (10 artifacts rendered live)
   ============================================================ */
(function () {
    'use strict';

    function $(id) { return document.getElementById(id); }

    /* ============================================================
       SHARED LEAN ENGINE — tissue table + phantoms + renderer
       ============================================================ */
    var TISSUES = {
        air:       { T1: 1,    T2: 1,    PD: 0.02 },
        fat:       { T1: 250,  T2: 100,  PD: 0.95 },
        muscle:    { T1: 950,  T2: 50,   PD: 0.70 },
        gm:        { T1: 1250, T2: 100,  PD: 0.86 },
        wm:        { T1: 850,  T2: 80,   PD: 0.76 },
        csf:       { T1: 4200, T2: 2100, PD: 1.00 },
        marrow:    { T1: 300,  T2: 60,   PD: 0.92 },
        disc:      { T1: 1200, T2: 130,  PD: 0.82 },
        cord:      { T1: 950,  T2: 75,   PD: 0.78 },
        cartilage: { T1: 1150, T2: 45,   PD: 0.78 },
        meniscus:  { T1: 800,  T2: 30,   PD: 0.60 },
        lesion:    { T1: 1100, T2: 260,  PD: 0.95 }
    };

    var ANATOMY = {
        brain_ax: [
            { s: 'ellipse', t: 'fat',  cx: 0.5, cy: 0.5, rx: 0.44, ry: 0.46 },
            { s: 'ellipse', t: 'muscle', cx: 0.5, cy: 0.5, rx: 0.425, ry: 0.445 },
            { s: 'ellipse', t: 'csf',  cx: 0.5, cy: 0.5, rx: 0.40, ry: 0.47 },
            { s: 'ellipse', t: 'gm',   cx: 0.5, cy: 0.5, rx: 0.375, ry: 0.445 },
            { s: 'ellipse', t: 'wm',   cx: 0.5, cy: 0.5, rx: 0.235, ry: 0.26 },
            { s: 'ellipse', t: 'csf',  cx: 0.5, cy: 0.585, rx: 0.05, ry: 0.15 },
            { s: 'ellipse', t: 'csf',  cx: 0.385, cy: 0.60, rx: 0.06, ry: 0.07 },
            { s: 'ellipse', t: 'csf',  cx: 0.615, cy: 0.60, rx: 0.06, ry: 0.07 },
            { s: 'ellipse', t: 'lesion', cx: 0.65, cy: 0.37, rx: 0.05, ry: 0.045 }
        ],
        spine_sag: [
            { s: 'rect', t: 'muscle', x: 0.06, y: 0.30, w: 0.88, h: 0.64, r: 0.03 },
            { s: 'rect', t: 'csf',    x: 0.44, y: 0.13, w: 0.12, h: 0.76, r: 0.05 },
            { s: 'rect', t: 'cord',   x: 0.475, y: 0.14, w: 0.05, h: 0.74, r: 0.02 }
        ],
        knee_sag: [
            { s: 'ellipse', t: 'fat',     cx: 0.5, cy: 0.55, rx: 0.42, ry: 0.42 },
            { s: 'ellipse', t: 'marrow',  cx: 0.48, cy: 0.26, rx: 0.16, ry: 0.20, rot: 0.35 },
            { s: 'ellipse', t: 'marrow',  cx: 0.55, cy: 0.78, rx: 0.14, ry: 0.17, rot: -0.25 },
            { s: 'rect',    t: 'cartilage', x: 0.36, y: 0.475, w: 0.26, h: 0.045, r: 0.02 },
            { s: 'rect',    t: 'cartilage', x: 0.42, y: 0.60, w: 0.24, h: 0.045, r: 0.02 },
            { s: 'poly',    t: 'meniscus', pts: [[0.46, 0.52], [0.55, 0.52], [0.505, 0.585]] },
            { s: 'rect',    t: 'muscle', x: 0.12, y: 0.16, w: 0.20, h: 0.66, r: 0.06 },
            { s: 'rect',    t: 'muscle', x: 0.68, y: 0.16, w: 0.20, h: 0.66, r: 0.06 }
        ]
    };
    /* spine needs repeated vertebrae/discs — build once */
    (function () {
        var prims = ANATOMY.spine_sag;
        for (var i = 0; i < 5; i++) {
            prims.push({ s: 'rect', t: 'marrow', x: 0.30, y: 0.16 + i * 0.17, w: 0.40, h: 0.075, r: 0.02 });
            prims.push({ s: 'rect', t: 'disc',   x: 0.33, y: 0.16 + i * 0.17 - 0.072, w: 0.34, h: 0.06, r: 0.02 });
        }
        prims.push({ s: 'ellipse', t: 'lesion', cx: 0.50, cy: 0.61, rx: 0.09, ry: 0.04 });
    })();

    var SEQ_PRESETS = {
        T1:     { TR: 500,  TE: 12,  nullTIssue: null,        t2factor: 1 },
        T2:     { TR: 4500, TE: 100, nullTIssue: null,        t2factor: 1 },
        PD:     { TR: 3000, TE: 18,  nullTIssue: null,        t2factor: 1 },
        FLAIR:  { TR: 9000, TE: 90,  nullTIssue: 'csf',       t2factor: 1 },
        STIR:   { TR: 3200, TE: 28,  nullTIssue: 'fat',       t2factor: 1 },
        T2STAR: { TR: 600,  TE: 22,  nullTIssue: null,        t2factor: 0.22 }
    };

    function intensityMap(seqKey) {
        var p = SEQ_PRESETS[seqKey] || SEQ_PRESETS.T1;
        var map = {}, max = 0.0001;
        Object.keys(TISSUES).forEach(function (k) {
            var t = TISSUES[k];
            var s = t.PD * (1 - Math.exp(-p.TR / t.T1)) * Math.exp(-p.TE / (t.T2 * p.t2factor));
            if (k === p.nullTIssue) s *= 0.04;
            if (k === 'marrow' && p.nullTIssue === 'fat') s *= 0.04;
            map[k] = s;
            if (k !== 'air' && s > max) max = s;
        });
        Object.keys(map).forEach(function (k) { map[k] = Math.min(1, map[k] / (max * 1.1)); });
        map.air = 0.02;
        return map;
    }

    function drawPhantom(ctx, size, anatomyKey, gray) {
        ctx.clearRect(0, 0, size, size);
        var bg = gray.air;
        ctx.fillStyle = 'rgb(' + bg + ',' + bg + ',' + bg + ')';
        ctx.fillRect(0, 0, size, size);
        (ANATOMY[anatomyKey] || []).forEach(function (p) {
            var g = Math.round(gray[p.t] * 255);
            ctx.fillStyle = 'rgb(' + g + ',' + g + ',' + g + ')';
            ctx.beginPath();
            if (p.s === 'ellipse') {
                ctx.ellipse(p.cx * size, p.cy * size, p.rx * size, p.ry * size, p.rot || 0, 0, Math.PI * 2);
                ctx.fill();
            } else if (p.s === 'rect') {
                var r = (p.r || 0) * size, x = p.x * size, y = p.y * size, w = p.w * size, h = p.h * size;
                ctx.moveTo(x + r, y);
                ctx.arcTo(x + w, y, x + w, y + h, r);
                ctx.arcTo(x + w, y + h, x, y + h, r);
                ctx.arcTo(x, y + h, x, y, r);
                ctx.arcTo(x, y, x + w, y, r);
                ctx.closePath();
                ctx.fill();
            } else if (p.s === 'poly') {
                p.pts.forEach(function (pt, i) {
                    if (i === 0) ctx.moveTo(pt[0] * size, pt[1] * size);
                    else ctx.lineTo(pt[0] * size, pt[1] * size);
                });
                ctx.closePath();
                ctx.fill();
            }
        });
    }

    function addNoise(ctx, size, sigma) {
        try {
            var img = ctx.getImageData(0, 0, size, size);
            var d = img.data;
            for (var i = 0; i < d.length; i += 4) {
                var n = (Math.random() + Math.random() + Math.random() - 1.5) * sigma;
                var v = Math.max(0, Math.min(255, d[i] + n));
                d[i] = d[i + 1] = d[i + 2] = v;
            }
            ctx.putImageData(img, 0, 0);
        } catch (e) { /* tainted canvas — skip */ }
    }

    /* ============================================================
       PART 1 — A/B CONTRAST COMPARATOR
       ============================================================ */
    (function comparator() {
        var cL = $('abCanvasL'), cR = $('abCanvasR');
        if (!cL || !cR) return;
        var ctxL = cL.getContext('2d'), ctxR = cR.getContext('2d');

        var anatomy = 'brain_ax';
        var left = 'T1', right = 'T2';

        var CAPTIONS = {
            'T1|T2':     'T1 shows fat bright / water dark — anatomy. T2 flips water to bright — pathology. This single flip is the heart of MRI contrast.',
            'T1|FLAIR':  'FLAIR keeps T2 pathology sensitivity but nulls CSF — periventricular lesions become obvious.',
            'T2|FLAIR':  'Both water-sensitive: T2 shows all fluid bright, FLAIR suppresses CSF to expose lesions beside ventricles.',
            'T1|STIR':   'STIR removes the bright fat/marrow signal — bone edema and soft-tissue fluid stand out.',
            'T2|STIR':   'Fat suppressed + fluid bright: the musculoskeletal edema combination.',
            'PD|T2':     'PD keeps both gray and white matter mid-gray; T2 sacrifices that balance to spotlight fluid.',
            'T1|T2STAR': 'T2* GRE is faster and more sensitive to blood products and calcification (darker susceptibility).',
            'T2|T2STAR': 'T2* decays faster than T2 — blood, iron and air-tissue interfaces bloom dark.'
        };

        function caption() {
            var k1 = left + '|' + right, k2 = right + '|' + left;
            var el = $('abCaption');
            el.innerHTML = '<i class="fas fa-lightbulb"></i> ' + (
                CAPTIONS[k1] || CAPTIONS[k2] ||
                (left + ' vs ' + right + ': drag the divider and compare tissue brightness — fat, water, marrow and lesion respond differently to every sequence.')
            );
        }

        function render() {
            drawPhantom(ctxL, cL.width, anatomy, intensityMap(left));
            addNoise(ctxL, cL.width, 5);
            drawPhantom(ctxR, cR.width, anatomy, intensityMap(right));
            addNoise(ctxR, cR.width, 5);
            $('abLabelL').textContent = left;
            $('abLabelR').textContent = right;
            caption();
        }

        /* divider drag */
        var divider = $('abDivider'), viewport = $('abViewport');
        var dragging = false;

        function setSplit(pct) {
            pct = Math.max(4, Math.min(96, pct));
            divider.style.left = pct + '%';
            cR.style.clipPath = 'inset(0 0 0 ' + pct + '%)';
            cL.style.clipPath = 'inset(0 ' + (100 - pct) + '% 0 0)';
        }

        function pointerPct(e) {
            var r = viewport.getBoundingClientRect();
            return ((e.clientX - r.left) / r.width) * 100;
        }

        divider.addEventListener('mousedown', function () { dragging = true; });
        viewport.addEventListener('mousedown', function (e) {
            dragging = true; setSplit(pointerPct(e));
        });
        window.addEventListener('mouseup', function () { dragging = false; });
        window.addEventListener('mousemove', function (e) {
            if (dragging) setSplit(pointerPct(e));
        });
        /* touch */
        divider.addEventListener('touchstart', function () { dragging = true; });
        viewport.addEventListener('touchmove', function (e) {
            if (dragging) setSplit(pointerPct(e.touches[0]));
        }, { passive: true });
        window.addEventListener('touchend', function () { dragging = false; });

        $('abAnatomy').addEventListener('change', function () { anatomy = this.value; render(); });
        $('abLeft').addEventListener('change', function () { left = this.value; render(); });
        $('abRight').addEventListener('change', function () { right = this.value; render(); });

        setSplit(50);
        render();
    })();

    /* ============================================================
       PART 2 — ARTIFACT ATLAS
       ============================================================ */
    (function artifacts() {
        var grid = $('artifactGrid');
        if (!grid) return;

        var ARTIFACTS = [
            { key: 'motion', icon: 'fa-person-running', name: 'Motion / Ghosting',
              cause: 'Patient movement during the acquisition (phase-encode direction).',
              fix: 'Coaching, immobilization, sedation, PROPELLER/BLADE sequences, shorter scan.' },
            { key: 'metal', icon: 'fa-magnet', name: 'Metal Susceptibility',
              cause: 'Ferromagnetic implants distort the local field — signal void + bright bloom.',
              fix: 'MARS protocols, wide bandwidth, SE (not GRE), STIR instead of FatSat.' },
            { key: 'chemshift', icon: 'fa-arrows-left-right', name: 'Chemical Shift',
              cause: 'Fat and water precess ~3.5 ppm apart — fat/water interfaces shift along frequency axis.',
              fix: 'Wider bandwidth, fat suppression, or in-phase TE choices.' },
            { key: 'wrap', icon: 'fa-rotate', name: 'Wrap-Around (Aliasing)',
              cause: 'Anatomy outside the FOV folds back into the image along the phase axis.',
              fix: 'Enlarge FOV, swap phase/frequency axis, oversampling, saturation bands.' },
            { key: 'gibbs', icon: 'fa-water', name: 'Gibbs (Truncation)',
              cause: 'Finite k-space sampling — ringing bands near sharp high-contrast edges.',
              fix: 'Larger matrix, smoother filtering, vendor edge-enhancement corrections.' },
            { key: 'zipper', icon: 'fa-bolt', name: 'RF Zipper',
              cause: 'Radiofrequency leak into the scan room — door left open, faulty equipment.',
              fix: 'Close the door properly, remove RF sources, call service.' },
            { key: 'spike', icon: 'fa-star', name: 'Spike / Herringbone',
              cause: 'A single bad data point in k-space spreads into a periodic stripe pattern.',
              fix: 'Re-scan; gradient/electronics fault — service engineers.' },
            { key: 'phasecancel', icon: 'fa-circle-notch', name: 'Phase Cancellation (India Ink)',
              cause: 'Opposed-phase imaging: voxels with 50/50 fat+water cancel — dark organ borders.',
              fix: 'Use in-phase TE (not a fault!) — or recognize it in out-of-phase sequences.' },
            { key: 'shading', icon: 'fa-adjust', name: 'RF Inhomogeneity / Shading',
              cause: 'Uneven coil sensitivity or poor tuning — gradual signal drift across the image.',
              fix: 'Coil repositioning, gain calibration, surface-coil intensity correction.' },
            { key: 'crosstalk', icon: 'fa-layer-group', name: 'Slice Cross-Talk',
              cause: 'Imperfect slice profiles excite neighboring slices — cross-contamination.',
              fix: 'Interleaved slice acquisition, gaps between slices, 3D volumes.' }
        ];

        var SIZE = 210;

        function renderArtifact(canvas, key) {
            var ctx = canvas.getContext('2d');
            var gray = intensityMap('T2');
            drawPhantom(ctx, SIZE, 'brain_ax', gray);
            addNoise(ctx, SIZE, 4);
            try { applyEffect(ctx, key); } catch (e) { /* skip on tainted */ }
        }

        function applyEffect(ctx, key) {
            var img = ctx.getImageData(0, 0, SIZE, SIZE);
            var d = img.data;
            var W = SIZE;

            function px(x, y) { var i = ((y + W) % W) * W + ((x + W) % W); return i * 4; }

            if (key === 'motion') {
                var copy = d.slice();
                for (var y = 0; y < W; y++) for (var x = 0; x < W; x++) {
                    var i = (y * W + x) * 4;
                    var a = copy[px(x, y + 26)], b = copy[px(x, y - 26)];
                    d[i] = 0.5 * copy[i] + 0.28 * a + 0.28 * b;
                    d[i + 1] = d[i + 2] = d[i];
                }
            } else if (key === 'metal') {
                var cx = W * 0.33, cy = W * 0.6, R = W * 0.14;
                var copy2 = d.slice();
                for (var y2 = 0; y2 < W; y2++) for (var x2 = 0; x2 < W; x2++) {
                    var dx = x2 - cx, dy = y2 - cy, dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < R * 2.6) {
                        var warp = Math.max(0, 1 - dist / (R * 2.6));
                        var push = warp * warp * R * 2.0, ang = Math.atan2(dy, dx);
                        var src = px(Math.round(cx + Math.cos(ang) * (dist + push)), Math.round(cy + Math.sin(ang) * (dist + push * 0.5)));
                        var dst = (y2 * W + x2) * 4;
                        if (dist < R * 0.6) {
                            var spike = Math.random() < 0.5 ? 255 : 0;
                            d[dst] = d[dst + 1] = d[dst + 2] = spike;
                        } else {
                            d[dst] = copy2[src]; d[dst + 1] = copy2[src + 1]; d[dst + 2] = copy2[src + 2];
                        }
                    }
                }
            } else if (key === 'chemshift') {
                var copy3 = d.slice();
                for (var y3 = 0; y3 < W; y3++) for (var x3 = 0; x3 < W; x3++) {
                    var i3 = (y3 * W + x3) * 4;
                    var isFat = copy3[i3] > 165;
                    var srcX = isFat ? Math.max(0, x3 - 7) : x3;
                    var s3 = (y3 * W + srcX) * 4;
                    d[i3] = copy3[s3]; d[i3 + 1] = copy3[s3 + 1]; d[i3 + 2] = copy3[s3 + 2];
                }
            } else if (key === 'wrap') {
                var copy4 = d.slice();
                for (var y4 = 0; y4 < W; y4++) for (var x4 = 0; x4 < W; x4++) {
                    var i4 = (y4 * W + x4) * 4;
                    if (x4 < W * 0.18) {   /* left band replaced by wrapped right side */
                        var s4 = (y4 * W + (x4 + Math.round(W * 0.82))) * 4;
                        d[i4] = copy4[s4]; d[i4 + 1] = copy4[s4 + 1]; d[i4 + 2] = copy4[s4 + 2];
                    }
                }
            } else if (key === 'gibbs') {
                for (var y5 = 0; y5 < W; y5++) for (var x5 = 0; x5 < W; x5++) {
                    var i5 = (y5 * W + x5) * 4;
                    var dx5 = x5 - W / 2, dy5 = y5 - W / 2, r5 = Math.sqrt(dx5 * dx5 + dy5 * dy5);
                    var ring = Math.sin(r5 * 1.15) * Math.exp(-Math.abs(r5 - W * 0.30) * 0.06) * 46;
                    var v5 = Math.max(0, Math.min(255, d[i5] + ring));
                    d[i5] = d[i5 + 1] = d[i5 + 2] = v5;
                }
            } else if (key === 'zipper') {
                for (var y6 = 0; y6 < W; y6++) for (var x6 = Math.round(W * 0.62); x6 < Math.round(W * 0.62) + 3; x6++) {
                    var i6 = (y6 * W + x6) * 4;
                    var z = Math.random() < 0.5 ? 235 : 20;
                    d[i6] = d[i6 + 1] = d[i6 + 2] = z;
                }
            } else if (key === 'spike') {
                for (var y7 = 0; y7 < W; y7++) for (var x7 = 0; x7 < W; x7++) {
                    var i7 = (y7 * W + x7) * 4;
                    var stripe = Math.sin((x7 + y7) * 0.55) * 30;
                    d[i7] = Math.max(0, Math.min(255, d[i7] + stripe));
                    d[i7 + 1] = d[i7 + 2] = d[i7];
                }
            } else if (key === 'phasecancel') {
                var copy8 = d.slice();
                for (var y8 = 1; y8 < W - 1; y8++) for (var x8 = 1; x8 < W - 1; x8++) {
                    var i8 = (y8 * W + x8) * 4;
                    var here = copy8[i8];
                    var right = copy8[i8 + 4], down = copy8[i8 + W * 4];
                    var edge = (here > 150 && (right < 110 || down < 110)) || (here < 110 && (right > 150 || down > 150));
                    if (edge) { d[i8] = d[i8 + 1] = d[i8 + 2] = 8; }
                }
            } else if (key === 'shading') {
                for (var y9 = 0; y9 < W; y9++) for (var x9 = 0; x9 < W; x9++) {
                    var i9 = (y9 * W + x9) * 4;
                    var f = 1 - (x9 / W) * 0.55;
                    d[i9] = d[i9] * f; d[i9 + 1] *= f; d[i9 + 2] *= f;
                }
            } else if (key === 'crosstalk') {
                var copy10 = d.slice();
                for (var y10 = 0; y10 < W; y10++) for (var x10 = 0; x10 < W; x10++) {
                    var i10 = (y10 * W + x10) * 4;
                    var s10 = px(x10 + 9, y10 + 5);
                    d[i10] = 0.62 * copy10[i10] + 0.38 * copy10[s10];
                    d[i10 + 1] = d[i10 + 2] = d[i10];
                }
            }
            ctx.putImageData(img, 0, 0);
        }

        /* build cards (render lazily when scrolled into view) */
        ARTIFACTS.forEach(function (a, idx) {
            var card = document.createElement('div');
            card.className = 'artifact-card';
            card.innerHTML =
                '<div class="artifact-canvas-wrap">' +
                    '<canvas width="' + SIZE + '" height="' + SIZE + '" id="art-' + a.key + '"></canvas>' +
                    '<span class="artifact-num">' + String(idx + 1).padStart(2, '0') + '</span>' +
                '</div>' +
                '<h4><i class="fas ' + a.icon + '"></i> ' + a.name + '</h4>' +
                '<p class="art-cause"><i class="fas fa-circle-question"></i> <strong>Cause:</strong> ' + a.cause + '</p>' +
                '<p class="art-fix"><i class="fas fa-screwdriver-wrench"></i> <strong>Fix:</strong> ' + a.fix + '</p>';
            grid.appendChild(card);
        });

        if ('IntersectionObserver' in window) {
            var io = new IntersectionObserver(function (entries) {
                entries.forEach(function (en) {
                    if (!en.isIntersecting) return;
                    var canvas = en.target;
                    renderArtifact(canvas, canvas.id.replace('art-', ''));
                    io.unobserve(canvas);
                });
            }, { threshold: 0.15 });
            grid.querySelectorAll('canvas').forEach(function (c) { io.observe(c); });
        } else {
            grid.querySelectorAll('canvas').forEach(function (c) {
                renderArtifact(c, c.id.replace('art-', ''));
            });
        }
    })();

    /* ============================================================
       CREDITS (from credits.json embedded server-side is complex —
       injected here as static list matched to downloaded files)
       ============================================================ */
    (function credits() {
        var box = $('creditsBox');
        if (!box) return;
        var CREDITS = [
            { key: 'brain-t1',   title: 'MRI Brain T1 Axial (1).jpg', lic: 'CC BY-SA 4.0', url: 'https://commons.wikimedia.org/wiki/File:MRI_Brain_T1_Axial_(1).jpg' },
            { key: 'brain-t2',   title: 'T2 weighted axial section of MRI brain showing cystic enceph', lic: 'CC BY-SA 4.0', url: 'https://commons.wikimedia.org/wiki/File:T2_weighted_axial_section_of_MRI_brain_showing_cystic_encephalomyelitic_changes_of_right_cerebellum.jpg' },
            { key: 'brain-flair',title: 'Mri Brain Flair Axial (21).jpg', lic: 'CC BY-SA 4.0', url: 'https://commons.wikimedia.org/wiki/File:Mri_Brain_Flair_Axial_(21).jpg' },
            { key: 'brain-dwi',  title: 'DWE MRI of cerebral infarction.png', lic: 'CC BY 4.0', url: 'https://commons.wikimedia.org/wiki/File:DWE_MRI_of_cerebral_infarction.png' },
            { key: 'brain-ms',   title: 'Journal.pone.0057573.g005.png', lic: 'CC BY 2.5', url: 'https://commons.wikimedia.org/wiki/File:Journal.pone.0057573.g005.png' },
            { key: 'spine-t2',   title: 'Lumbar MRI T2 TSE Sagittal', lic: 'CC0 1.0' },
            { key: 'knee-sag',   title: 'Knee MRI T1 TSE Sagittal.jpg', lic: 'CC BY-SA 4.0', url: 'https://commons.wikimedia.org/wiki/File:Knee_MRI_T1_TSE_Sagittal.jpg' },
            { key: 'cardiac',    title: 'Labelled Sinus of Valsalva aneurysm.jpg', lic: 'CC BY-SA 4.0', url: 'https://commons.wikimedia.org/wiki/File:Labelled_Sinus_of_Valsalva_aneurysm.jpg' }
        ];
        var rows = CREDITS.map(function (c) {
            var name = c.url ? '<a href="' + c.url + '" target="_blank" rel="noopener"><strong>' + c.title + '</strong></a>' : '<strong>' + c.title + '</strong>';
            return '<li><i class="fas fa-image"></i><span>' + name + ' — via Wikimedia Commons, ' + c.lic + '</span></li>';
        }).join('');
        box.innerHTML =
            '<p class="credits-note"><i class="fas fa-scale-balanced"></i> All gallery images are real clinical MRI scans ' +
            'sourced from Wikimedia Commons under Creative Commons / Public Domain licenses. Titles link back to source:</p>' +
            '<ul class="credits-list">' + rows + '</ul>';
    })();

})();
