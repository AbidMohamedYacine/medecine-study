/* ============================================================
   SEENmri — MACHINE AUTOPSY (components page)
   Scroll-driven + slider-driven exploded view of the scanner.
   Pure vanilla: SVG layers, transform/opacity only.
   ============================================================ */
(function () {
    'use strict';
    function $(id) { return document.getElementById(id); }

    var wrap = $('autopsyWrap');
    var svg = $('mriSvg');
    if (!wrap || !svg) return;

    var stage = $('autopsyStage');
    var infoPanel = $('autopsyInfo');
    var infoBody = $('autopsyInfoBody');
    var slider = $('autopsySlider');
    var progressLbl = $('autopsyProgressLbl');
    var sweep = $('xraySweep');
    var layers = {
        shell:    $('ly-shell'),
        magnet:   $('ly-magnet'),
        gradient: $('ly-grad'),
        rf:       $('ly-rf'),
        table:    $('ly-table')
    };
    var callouts = document.querySelectorAll('.mach-callout');

    /* ---------- content ---------- */
    var INFO = {
        shell: {
            t: 'Cryostat — Vacuum Vessel',
            d: 'The machine\u2019s stainless-steel \u201cthermos\u201d. Layered vacuum chambers stop room heat from reaching the liquid helium ( \u2212269\u00b0C ) \u2014 the coldest place in the hospital.',
            f: 'Vacuum insulation \u00b7 \u2212269\u00b0C helium \u00b7 outer skin',
            link: ['#', 'The shell']
        },
        magnet: {
            t: 'Superconducting Magnet (B0)',
            d: 'Niobium-titanium coils bathed in liquid helium carry current with zero resistance \u2014 generating a 1.5T or 3T field, 30\u201360,000\u00d7 stronger than Earth\u2019s. Once energised, it stays on for years.',
            f: '1.5T / 3T \u00b7 zero resistance \u00b7 4 K helium',
            link: ['#magnet', 'Magnet deep-dive']
        },
        gradient: {
            t: 'Gradient Coils — X \u00b7 Y \u00b7 Z',
            d: 'Three coil sets tilt the field linearly for spatial encoding: slice selection, phase and frequency. Switching them thousands of times a second is the famous knocking sound.',
            f: 'Spatial encoding \u00b7 dB/dt limits \u00b7 the knocking',
            link: ['#gradient', 'Gradients deep-dive']
        },
        rf: {
            t: 'RF Body Coil',
            d: 'The antenna of the scanner: transmits the excitation pulse tuned to the Larmor frequency, then listens for the faint signal returning from relaxing protons.',
            f: 'Transmit + receive \u00b7 Larmor frequency \u00b7 SAR',
            link: ['#rf', 'RF coils deep-dive']
        },
        table: {
            t: 'Patient Table & Shim System',
            d: 'Carbon-fibre table with laser alignment for precise positioning. Shim coils fine-tune B0 homogeneity \u2014 the secret behind clean fat-sat and artefact-free bSSFP.',
            f: 'Laser alignment \u00b7 shimming \u00b7 B0 homogeneity',
            link: ['#shim', 'Shim deep-dive']
        }
    };

    /* ---------- explode geometry (per-layer offsets) ---------- */
    var OFF = {
        shell:    { y: -150, s: 1.00 },
        magnet:   { y:  -62, s: 1.00 },
        gradient: { y:    0, s: 1.00 },
        rf:       { y:   62, s: 1.00 },
        table:    { y:  150, s: 1.00 }
    };
    var EX_START = 0.22, EX_END = 0.92;      /* explode window in progress */
    var XRAY_END = 0.20;                      /* sweep window */

    var progress = 0;                         /* 0..1 */
    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
    function ease(t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; }

    /* ---------- render from progress ---------- */
    function apply() {
        var p = progress;

        /* X-ray sweep: sweeps during 0 → XRAY_END */
        var xr = clamp01(p / XRAY_END);
        if (sweep) {
            if (xr > 0 && xr < 1) {
                sweep.style.opacity = '1';
                sweep.setAttribute('x', 150 + xr * 600);
            } else {
                sweep.style.opacity = '0';
            }
        }

        /* shell translucency: opaque → blueprint after sweep */
        var shellVis = 1 - clamp01((p - 0.06) / 0.18);           /* 1 → 0 */
        var shellFill = 0.10 + 0.72 * shellVis;                   /* 0.82 → 0.10 */
        if (layers.shell) layers.shell.style.setProperty('--shell-fill-o', shellFill.toFixed(3));

        /* explode */
        var ex = ease(clamp01((p - EX_START) / (EX_END - EX_START)));
        for (var k in layers) {
            if (!layers[k]) continue;
            var o = OFF[k];
            layers[k].style.transform =
                'translateY(' + (o.y * ex).toFixed(1) + 'px) scale(' + (1 + (o.s - 1) * ex).toFixed(3) + ')';
        }

        /* callouts + labels fade in late */
        var co = clamp01((p - 0.62) / 0.24);
        callouts.forEach(function (c) { c.style.opacity = co.toFixed(2); });

        /* progress label */
        if (progressLbl) {
            if (p < XRAY_END) progressLbl.textContent = 'X-RAY SWEEP \u2026 ' + Math.round(xr * 100) + '%';
            else if (ex < 1) progressLbl.textContent = 'DISASSEMBLY \u2026 ' + Math.round(ex * 100) + '%';
            else progressLbl.textContent = 'FULL EXPLODED VIEW \u2014 hover any layer';
        }

        /* slider sync */
        if (slider && document.activeElement !== slider) slider.value = String(Math.round(p * 100));
    }

    /* ---------- scroll driver ---------- */
    function onScroll() {
        var r = wrap.getBoundingClientRect();
        var total = r.height - window.innerHeight;
        if (total <= 0) return;
        var p = clamp01(-r.top / total);
        if (Math.abs(p - progress) > 0.001) {
            progress = p;
            apply();
        }
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);

    /* ---------- slider driver (two-way) ---------- */
    if (slider) {
        slider.addEventListener('input', function () {
            progress = parseInt(slider.value, 10) / 100;
            apply();
        });
    }

    /* ---------- layer selection (hover / tap / keyboard) ---------- */
    var selected = null;
    function select(key, el) {
        selected = key;
        document.querySelectorAll('.mach-layer').forEach(function (g) {
            g.classList.toggle('is-active', g === el);
            g.classList.toggle('is-dim', g !== el);
        });
        if (infoBody && INFO[key]) {
            var inf = INFO[key];
            infoBody.innerHTML =
                '<h3>' + inf.t + '</h3><p>' + inf.d + '</p>' +
                '<div class="ai-tags"><span>' + inf.f + '</span></div>' +
                '<a class="back-cta" style="margin-top:14px;" href="' + inf.link[0] + '">' + inf.link[1] + ' <i class="fas fa-arrow-right"></i></a>';
        }
        if (infoPanel) infoPanel.classList.add('show');
        /* reveal its callout, hide others? keep all */
    }
    function deselect() {
        selected = null;
        document.querySelectorAll('.mach-layer').forEach(function (g) {
            g.classList.remove('is-active', 'is-dim');
        });
        if (infoPanel) {
            infoPanel.classList.remove('show');
            infoBody.innerHTML =
                '<h3>The machine, opened</h3><p>Hover or tap any separated layer \u2014 shell, magnet, gradients, RF coil or the patient table \u2014 to see what it does.</p>';
        }
    }
    Object.keys(layers).forEach(function (key) {
        var el = layers[key];
        if (!el) return;
        el.setAttribute('tabindex', '0');
        el.setAttribute('role', 'button');
        el.setAttribute('aria-label', INFO[key].t);
        el.addEventListener('mouseenter', function () { select(key, el); });
        el.addEventListener('mouseleave', function () { deselect(); });
        el.addEventListener('click', function (e) {
            e.stopPropagation();
            if (selected === key) deselect(); else select(key, el);
        });
        el.addEventListener('focus', function () { select(key, el); });
        el.addEventListener('blur', function () { deselect(); });
        el.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); select(key, el); }
        });
    });
    if (stage) stage.addEventListener('click', function (e) {
        if (e.target === stage || e.target === svg) deselect();
    });
    if (infoBody) deselect();   /* initial hint */

    /* ---------- boot ---------- */
    if (reduced) {
        wrap.style.height = 'auto';
        if (stage) stage.style.position = 'relative';
        progress = 1;
    }
    apply();
    onScroll();

    window.__autopsy = {
        set: function (p) { progress = clamp01(p); apply(); },
        get progress() { return progress; },
        select: select
    };
})();
