/* ============================================================
   SEENmri — interactives.js
   1) K-Space Explorer  (real 2D FFT + partial reconstruction)
   2) T1/T2 Decay Curve Lab
   Loaded on pages that contain their DOM hooks.
   ============================================================ */
(function () {
    'use strict';

    function $(id) { return document.getElementById(id); }

    /* ============================================================
       PART 1 — K-SPACE EXPLORER
       ============================================================ */
    (function kSpaceExplorer() {
        var ksCanvas = $('ksCanvas');
        var ksImage = $('ksImage');
        if (!ksCanvas || !ksImage) return;

        var N = 64;                       /* k-space matrix size */
        var ksCtx = ksCanvas.getContext('2d');
        var imgCtx = ksImage.getContext('2d');
        var off = document.createElement('canvas');
        off.width = N; off.height = N;
        var offCtx = off.getContext('2d');

        var mode = 'sequential';
        var filled = 0;                   /* 0..N lines */
        var randomOrder = [];
        var animRAF = null;

        /* ---------- phantom object (what we are "scanning") ---------- */
        var phantom = new Float64Array(N * N);
        (function buildPhantom() {
            var c = N / 2;
            for (var y = 0; y < N; y++) {
                for (var x = 0; x < N; x++) {
                    var dx = (x - c) / (N * 0.44), dy = (y - c) / (N * 0.46);
                    var r = dx * dx + dy * dy;
                    var v = 0.02;                       /* air background */
                    if (r < 1)      v = 0.35;           /* scalp/fat rim */
                    if (r < 0.82)   v = 0.12;           /* skull */
                    if (r < 0.68)   v = 0.55;           /* gray matter */
                    if (r < 0.42)   v = 0.72;           /* white matter */
                    /* ventricles */
                    var vdx = (x - c) / (N * 0.075), vdy = (y - (c + N * 0.10)) / (N * 0.22);
                    if (vdx * vdx + vdy * vdy < 1 && Math.abs(x - c) < N * 0.09) v = 1.0;
                    /* lesion (bright dot) */
                    var ldx = (x - (c + N * 0.16)) / (N * 0.06), ldy = (y - (c - N * 0.14)) / (N * 0.06);
                    if (ldx * ldx + ldy * ldy < 1) v = 0.95;
                    /* subtle noise */
                    v += (Math.random() - 0.5) * 0.02;
                    phantom[y * N + x] = Math.max(0, v);
                }
            }
        })();

        /* ---------- FFT machinery (radix-2) ---------- */
        function fft1d(re, im, inverse) {
            var n = re.length;
            for (var i = 1, j = 0; i < n; i++) {
                var bit = n >> 1;
                for (; j & bit; bit >>= 1) j ^= bit;
                j ^= bit;
                if (i < j) {
                    var tr = re[i]; re[i] = re[j]; re[j] = tr;
                    var ti = im[i]; im[i] = im[j]; im[j] = ti;
                }
            }
            for (var len = 2; len <= n; len <<= 1) {
                var ang = (2 * Math.PI / len) * (inverse ? 1 : -1);
                for (var i2 = 0; i2 < n; i2 += len) {
                    for (var k = 0; k < (len >> 1); k++) {
                        var a = ang * k;
                        var wr = Math.cos(a), wi = Math.sin(a);
                        var i0 = i2 + k, i1 = i2 + k + (len >> 1);
                        var vr = re[i1] * wr - im[i1] * wi;
                        var vi = re[i1] * wi + im[i1] * wr;
                        var ur = re[i0], ui = im[i0];
                        re[i0] = ur + vr; im[i0] = ui + vi;
                        re[i1] = ur - vr; im[i1] = ui - vi;
                    }
                }
            }
            if (inverse) {
                for (var i3 = 0; i3 < n; i3++) { re[i3] /= n; im[i3] /= n; }
            }
        }

        function fft2d(re, im, inverse) {
            var rowRe = new Float64Array(N), rowIm = new Float64Array(N);
            var y, x;
            for (y = 0; y < N; y++) {
                for (x = 0; x < N; x++) { rowRe[x] = re[y * N + x]; rowIm[x] = im[y * N + x]; }
                fft1d(rowRe, rowIm, inverse);
                for (x = 0; x < N; x++) { re[y * N + x] = rowRe[x]; im[y * N + x] = rowIm[x]; }
            }
            for (x = 0; x < N; x++) {
                for (y = 0; y < N; y++) { rowRe[y] = re[y * N + x]; rowIm[y] = im[y * N + x]; }
                fft1d(rowRe, rowIm, inverse);
                for (y = 0; y < N; y++) { re[y * N + x] = rowRe[y]; im[y * N + x] = rowIm[y]; }
            }
        }

        function shift(i) { return (i + N / 2) % N; }   /* fftshift for centering */

        /* ---------- precompute full k-space ---------- */
        var kRe = new Float64Array(N * N), kIm = new Float64Array(N * N);
        (function computeK() {
            for (var i = 0; i < N * N; i++) { kRe[i] = phantom[i]; kIm[i] = 0; }
            fft2d(kRe, kIm, false);
        })();

        var kMag = new Float64Array(N * N);
        var kMax = 0.0001;
        (function magnitudes() {
            for (var y = 0; y < N; y++) {
                for (var x = 0; x < N; x++) {
                    var m = Math.sqrt(kRe[y * N + x] * kRe[y * N + x] + kIm[y * N + x] * kIm[y * N + x]);
                    var v = Math.log(1 + m);
                    var sy = shift(y), sx = shift(x);
                    kMag[sy * N + sx] = v;
                    if (v > kMax) kMax = v;
                }
            }
        })();

        /* ---------- which k-space row is the nth filled line? ---------- */
        function lineOrder() {
            var order = [];
            if (mode === 'sequential') {
                for (var i = 0; i < N; i++) order.push(i);
            } else if (mode === 'centric') {
                order.push(N / 2);
                for (var d = 1; d <= N / 2; d++) {
                    if (N / 2 + d < N) order.push(N / 2 + d);
                    if (N / 2 - d >= 0) order.push(N / 2 - d);
                }
            } else {
                order = randomOrder.slice();
            }
            return order;
        }

        function makeRandomOrder() {
            randomOrder = [];
            for (var i = 0; i < N; i++) randomOrder.push(i);
            for (var j = N - 1; j > 0; j--) {
                var k = Math.floor(Math.random() * (j + 1));
                var t = randomOrder[j]; randomOrder[j] = randomOrder[k]; randomOrder[k] = t;
            }
        }
        makeRandomOrder();

        /* ---------- rendering ---------- */
        function isFilled(shiftedRow) {
            var order = lineOrder();
            for (var i = 0; i < filled; i++) if (order[i] === shiftedRow) return true;
            return false;
        }

        function drawKSpace() {
            var px = ksCanvas.width / N;
            ksCtx.fillStyle = '#04070f';
            ksCtx.fillRect(0, 0, ksCanvas.width, ksCanvas.height);
            for (var y = 0; y < N; y++) {
                var f = isFilled(y);
                for (var x = 0; x < N; x++) {
                    var v = f ? kMag[y * N + x] / kMax : 0;
                    if (v > 0.004) {
                        var g = Math.round(255 * Math.pow(v, 0.75));
                        ksCtx.fillStyle = 'rgb(' + Math.min(255, g + 8) + ',' + Math.round(g * 0.82) + ',' + Math.round(g * 0.45 + 12) + ')';
                        ksCtx.fillRect(x * px, y * px, Math.ceil(px), Math.ceil(px));
                    }
                }
            }
            /* acquisition cursor line */
            if (filled > 0 && filled < N) {
                var order2 = lineOrder();
                var row = order2[filled - 1];
                ksCtx.fillStyle = 'rgba(0,212,170,0.85)';
                ksCtx.fillRect(0, row * px, ksCanvas.width, 1.5);
            }
        }

        function drawReconstruction() {
            /* start from zeroed k-space; copy only the filled (shifted) rows */
            var re = new Float64Array(N * N), im = new Float64Array(N * N);
            for (var sy = 0; sy < N; sy++) {
                if (!isFilled(sy)) continue;
                var uy = shift(sy);          /* shift() is its own inverse */
                for (var ux = 0; ux < N; ux++) {
                    re[uy * N + ux] = kRe[uy * N + ux];
                    im[uy * N + ux] = kIm[uy * N + ux];
                }
            }
            fft2d(re, im, true);

            var maxV = 0.0001;
            var mag = new Float64Array(N * N);
            for (var i = 0; i < N * N; i++) {
                var m = Math.abs(re[i]);
                mag[i] = m;
                if (m > maxV) maxV = m;
            }
            var id = offCtx.createImageData(N, N);
            for (var i2 = 0; i2 < N * N; i2++) {
                var v = Math.round(255 * Math.pow(mag[i2] / maxV, 0.85));
                id.data[i2 * 4] = v; id.data[i2 * 4 + 1] = v; id.data[i2 * 4 + 2] = v; id.data[i2 * 4 + 3] = 255;
            }
            offCtx.putImageData(id, 0, 0);
            imgCtx.imageSmoothingEnabled = true;
            imgCtx.drawImage(off, 0, 0, ksImage.width, ksImage.height);
        }

        function updateStatus() {
            $('ksCount').textContent = filled + ' / 64';
            var pct = Math.round(filled / N * 100);
            var el = $('ksStatus');
            if (filled === 0) {
                el.innerHTML = '<i class="fas fa-circle-info"></i> Press “Run Acquisition” to begin filling k-space.';
            } else if (filled < N / 4) {
                el.innerHTML = '<i class="fas fa-circle-info"></i> ' + pct + '% acquired — mostly <strong>contrast</strong> information so far.';
            } else if (filled < N) {
                el.innerHTML = '<i class="fas fa-circle-info"></i> ' + pct + '% acquired — <strong>detail</strong> (edges) is coming in.';
            } else {
                el.innerHTML = '<i class="fas fa-circle-check"></i> 100% — full resolution image complete!';
            }
        }

        function render() {
            drawKSpace();
            drawReconstruction();
            updateStatus();
            $('ksSlider').value = filled;
        }

        /* ---------- events ---------- */
        document.querySelectorAll('.ks-mode-btn').forEach(function (b) {
            b.addEventListener('click', function () {
                document.querySelectorAll('.ks-mode-btn').forEach(function (x) { x.classList.remove('active'); });
                b.classList.add('active');
                mode = b.getAttribute('data-mode');
                if (mode === 'random') makeRandomOrder();
                render();
            });
        });

        $('ksSlider').addEventListener('input', function () {
            stopAnim();
            filled = parseInt(this.value, 10);
            render();
        });

        function stopAnim() {
            if (animRAF) { cancelAnimationFrame(animRAF); animRAF = null; }
            $('ksRun').innerHTML = '<i class="fas fa-play"></i> Run Acquisition';
        }

        $('ksRun').addEventListener('click', function () {
            if (animRAF) { stopAnim(); return; }
            if (filled >= N) filled = 0;
            $('ksRun').innerHTML = '<i class="fas fa-pause"></i> Pause';
            var last = null, speed = 14;   /* lines per second */
            function step(ts) {
                if (last === null) last = ts;
                var dt = (ts - last) / 1000; last = ts;
                filled = Math.min(N, filled + dt * speed);
                render();
                if (filled >= N) { stopAnim(); return; }
                animRAF = requestAnimationFrame(step);
            }
            animRAF = requestAnimationFrame(step);
        });

        $('ksReset').addEventListener('click', function () {
            stopAnim();
            filled = 0;
            render();
        });

        render();
    })();

    /* ============================================================
       PART 2 — T1 / T2 DECAY CURVE LAB
       ============================================================ */
    (function decayLab() {
        var canvas = $('decayCanvas');
        if (!canvas) return;
        var ctx = canvas.getContext('2d');

        var TISSUES = [
            { name: 'Fat',        T1: 250,  T2: 100,  color: '#fbbf24' },
            { name: 'White Matter', T1: 800,  T2: 80,  color: '#34d399' },
            { name: 'Gray Matter',  T1: 1250, T2: 100, color: '#a78bfa' },
            { name: 'Muscle',     T1: 950,  T2: 50,   color: '#f87171' },
            { name: 'CSF / Water', T1: 4000, T2: 2000, color: '#60a5fa' }
        ];
        var visible = {};
        TISSUES.forEach(function (t) { visible[t.name] = true; });

        var view = 't1';
        var TR = 500, TE = 100;

        var W = canvas.width, H = canvas.height;
        var padL = 56, padR = 18, padT = 26, padB = 44;

        function tMax() { return view === 't1' ? 3200 : 600; }

        function xOf(t) { return padL + (t / tMax()) * (W - padL - padR); }
        function yOf(s) { return padT + (1 - s) * (H - padT - padB); }

        function draw() {
            ctx.clearRect(0, 0, W, H);

            /* frame */
            ctx.fillStyle = 'rgba(6,10,20,0.55)';
            ctx.fillRect(0, 0, W, H);

            /* grid */
            ctx.strokeStyle = 'rgba(120,160,255,0.10)';
            ctx.lineWidth = 1;
            for (var g = 0; g <= 10; g++) {
                var gx = padL + (g / 10) * (W - padL - padR);
                ctx.beginPath(); ctx.moveTo(gx, padT); ctx.lineTo(gx, H - padB); ctx.stroke();
            }
            for (var s = 0; s <= 4; s++) {
                var gy = padT + (s / 4) * (H - padT - padB);
                ctx.beginPath(); ctx.moveTo(padL, gy); ctx.lineTo(W - padR, gy); ctx.stroke();
            }

            /* axes labels */
            ctx.fillStyle = '#7d92bd';
            ctx.font = '12px Inter, sans-serif';
            ctx.textAlign = 'center';
            ctx.fillText(view === 't1' ? 'Time after RF pulse (ms) — longitudinal recovery' : 'Time after RF pulse (ms) — transverse decay',
                         (padL + W - padR) / 2, H - 12);
            ctx.save();
            ctx.translate(14, (padT + H - padB) / 2);
            ctx.rotate(-Math.PI / 2);
            ctx.fillText('Relative signal', 0, 0);
            ctx.restore();
            for (var lv = 0; lv <= 4; lv++) {
                var val = lv / 4;
                ctx.textAlign = 'right';
                ctx.fillText(val.toFixed(1), padL - 8, yOf(val) + 4);
            }
            for (var tk = 0; tk <= 5; tk++) {
                var tv = (tk / 5) * tMax();
                ctx.textAlign = 'center';
                ctx.fillText(Math.round(tv), xOf(tv), H - padB + 18);
            }

            /* curves */
            TISSUES.forEach(function (t) {
                if (!visible[t.name]) return;
                ctx.strokeStyle = t.color;
                ctx.lineWidth = 2.5;
                ctx.beginPath();
                for (var px = 0; px <= 240; px++) {
                    var time = (px / 240) * tMax();
                    var sig = view === 't1' ? (1 - Math.exp(-time / t.T1)) : Math.exp(-time / t.T2);
                    if (px === 0) ctx.moveTo(xOf(time), yOf(sig));
                    else ctx.lineTo(xOf(time), yOf(sig));
                }
                ctx.stroke();
            });

            /* TR / TE marker */
            var markerT = view === 't1' ? TR : TE;
            var mx = xOf(markerT);
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 1.5;
            ctx.setLineDash([6, 5]);
            ctx.beginPath(); ctx.moveTo(mx, padT); ctx.lineTo(mx, H - padB); ctx.stroke();
            ctx.setLineDash([]);

            /* signal dots on curves at marker */
            TISSUES.forEach(function (t) {
                if (!visible[t.name]) return;
                var sig = view === 't1' ? (1 - Math.exp(-markerT / t.T1)) : Math.exp(-markerT / t.T2);
                ctx.fillStyle = t.color;
                ctx.beginPath();
                ctx.arc(mx, yOf(sig), 5, 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = '#0b1120';
                ctx.lineWidth = 2;
                ctx.stroke();
            });

            /* label */
            ctx.fillStyle = '#e6edf8';
            ctx.font = '600 13px "Space Grotesk", sans-serif';
            ctx.textAlign = 'left';
            ctx.fillText((view === 't1' ? 'TR = ' : 'TE = ') + markerT + ' ms', Math.min(mx + 10, W - 110), padT + 4);
        }

        function renderLegend() {
            var el = $('decayLegend');
            el.innerHTML = '';
            TISSUES.forEach(function (t) {
                var chip = document.createElement('button');
                chip.className = 'decay-chip' + (visible[t.name] ? '' : ' off');
                chip.innerHTML = '<span class="chip-dot" style="background:' + t.color + '"></span>' + t.name +
                                 '<span class="chip-t">(T1 ' + t.T1 + ' · T2 ' + t.T2 + ')</span>';
                chip.addEventListener('click', function () {
                    visible[t.name] = !visible[t.name];
                    renderLegend();
                    draw();
                    renderReadout();
                });
                el.appendChild(chip);
            });
        }

        function renderReadout() {
            var box = $('decayReadout');
            box.innerHTML = '';
            var list = TISSUES.slice().sort(function (a, b) {
                var sa = view === 't1' ? (1 - Math.exp(-TR / a.T1)) : Math.exp(-TE / a.T2);
                var sb = view === 't1' ? (1 - Math.exp(-TR / b.T1)) : Math.exp(-TE / b.T2);
                return sb - sa;
            });

            list.forEach(function (t, i) {
                var t1rec = (1 - Math.exp(-TR / t.T1)) * 100;
                var t2rem = Math.exp(-TE / t.T2) * 100;
                var bar = view === 't1' ? t1rec : t2rem;
                var row = document.createElement('div');
                row.className = 'decay-row';
                row.innerHTML =
                    '<span class="decay-tname"><i class="fas fa-' + (i === 0 ? 'crown' : 'circle') + '" style="color:' + t.color + '"></i> ' + t.name + '</span>' +
                    '<div class="bar-track"><div class="bar-fill" style="width:' + bar + '%;background:' + t.color + '"></div></div>' +
                    '<span class="decay-val">' + Math.round(bar) + '%</span>';
                box.appendChild(row);
            });

            var bright = list[0], dark = list[list.length - 1];
            var insight = $('decayInsight');
            if (view === 't1') {
                insight.innerHTML = '<i class="fas fa-lightbulb"></i> At TR = ' + TR + ' ms, <strong>' + bright.name +
                    '</strong> recovers fastest (bright) while <strong>' + dark.name + '</strong> lags behind (dark) — this difference IS T1 contrast. Short TR + short TE = <strong>T1-weighted</strong> image.';
            } else {
                insight.innerHTML = '<i class="fas fa-lightbulb"></i> At TE = ' + TE + ' ms, <strong>' + bright.name +
                    '</strong> still holds signal (bright) while <strong>' + dark.name + '</strong> has decayed (dark) — this difference IS T2 contrast. Long TR + long TE = <strong>T2-weighted</strong> image.';
            }
        }

        function update() {
            $('decayTRVal').textContent = TR + ' ms';
            $('decayTEVal').textContent = TE + ' ms';
            draw();
            renderReadout();
        }

        document.querySelectorAll('.decay-tab').forEach(function (b) {
            b.addEventListener('click', function () {
                document.querySelectorAll('.decay-tab').forEach(function (x) { x.classList.remove('active'); });
                b.classList.add('active');
                view = b.getAttribute('data-view');
                update();
            });
        });

        $('decayTR').addEventListener('input', function () { TR = parseInt(this.value, 10); update(); });
        $('decayTE').addEventListener('input', function () { TE = parseInt(this.value, 10); update(); });

        renderLegend();
        update();
    })();

})();
