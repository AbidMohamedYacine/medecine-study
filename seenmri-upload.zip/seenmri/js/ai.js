/* ============================================================
   SEENmri — ai.js
   "SEEN AI" — built-in MRI study assistant.
   Self-contained knowledge engine: curated MRI knowledge base,
   intent matching, site deep-links, live suggestions & tools.
   No server, no API, works offline.
   ============================================================ */
(function () {
    'use strict';

    function $id(id) { return document.getElementById(id); }

    /* ============================================================
       KNOWLEDGE BASE
       ============================================================ */
    var KB = [
        /* ---------- GENERAL / META ---------- */
        { k: ['who are you', 'what are you', 'about you', 'your name'],
          a: 'I\u2019m <b>SEEN AI</b> — the built-in study assistant of SEENmri. I know the entire platform: MRI physics, every sequence, parameters and trade-offs, cardiac MR, safety, artifacts and patient preparation. Ask me anything MRI — or tap a suggestion below.',
          follow: ['What is MRI?', 'Explain k-space', 'What does TR do?'] },
        { k: ['hello', 'hi', 'hey', 'salam', 'bonjour', 'good morning', 'good evening'],
          a: 'Hello! 👋 Ready to master MRI? Ask me about any topic — physics, sequences, safety, parameters — or start with a suggestion.',
          follow: ['What is MRI?', 'What is FLAIR?', 'Explain the ACR zones'] },
        { k: ['thank', 'thanks', 'merci', 'shukran'],
          a: 'You\u2019re very welcome! 💙 Keep the questions coming — every one takes you closer to mastery.',
          follow: ['Quiz me: what does ADC show?', 'How does DWI detect stroke?'] },
        { k: ['joke', 'funny', 'laugh'],
          a: 'Here\u2019s one from the magnet room: <i>Why did the proton refuse to relax?</i> — It had too much <b>spin</b> under pressure! ⚛️ Now, back to business — what shall we study?',
          follow: ['Explain T1 and T2', 'What is T2*?'] },

        /* ---------- PHYSICS ---------- */
        { k: ['what is mri', 'mri basics', 'define mri', 'how does mri work', 'mri principle', 'explain mri'],
          a: '<b>MRI (Magnetic Resonance Imaging)</b> creates images from the signal of hydrogen protons in body water and fat — no ionizing radiation. The recipe:<ul><li><b>B0</b> — a powerful magnet (1.5–3 T) aligns the protons</li><li><b>RF pulse</b> — tips them out of alignment at the Larmor frequency</li><li><b>Relaxation</b> — protons release energy (T1 recovery, T2 decay)</li><li><b>Gradients + Fourier</b> — encode position and rebuild the image</li></ul>',
          links: [['Full physics walkthrough', 'about-mri.html#physics']],
          follow: ['What is the Larmor frequency?', 'Explain T1 vs T2', 'How does k-space work?'] },
        { k: ['larmor', 'resonance frequency', 'precession frequency', 'gyromagnetic'],
          a: 'The <b>Larmor frequency</b> is a proton\u2019s precession (wobble) rate inside B0: <b>f = 42.58 MHz/T \u00d7 B0</b>. At 1.5 T \u2248 <b>63.9 MHz</b>; at 3 T \u2248 <b>127.7 MHz</b>. The RF pulse must be tuned to exactly this frequency — that matching is what \u201cresonance\u201d means in MRI.',
          tool: 'larmor',
          follow: ['What happens at 3 Tesla?', 'What is the RF pulse?'] },
        { k: ['b0', 'main magnet', 'main field', 'magnet strength', 'tesla', '1.5t vs 3t', '3 tesla', '3t'],
          a: '<b>B0</b> is the main static field — 1.5 T (30,000\u00d7 Earth\u2019s field) or 3 T in clinical practice. <b>Going 1.5 T \u2192 3 T:</b> roughly doubles signal/SNR and T1 contrast, but also doubles chemical shift and SAR and amplifies susceptibility artifacts. Superconducting niobium-titanium windings cooled by liquid helium (4 K) keep it perfectly stable.',
          links: [['The main magnet', 'components.html#magnet']],
          follow: ['What is shimming?', 'What is SAR?'] },
        { k: ['precession', 'wobble', 'spin top'],
          a: '<b>Precession</b> is the wobbling spin of aligned protons around the B0 axis — like a spinning top. Its frequency is the Larmor frequency (\u03c9 = \u03b3B0). Precession is what makes protons able to absorb RF energy and to induce a detectable signal in the receiver coil.',
          follow: ['What is the Larmor frequency?', 'How is signal detected?'] },
        { k: ['rf pulse', 'excitation pulse', '90 degree', 'flip protons', 'radiofrequency'],
          a: 'The <b>RF excitation pulse</b> is a short burst of radio waves tuned to the Larmor frequency. It tips the net magnetization away from B0 (90\u00b0 in spin echo; smaller angles in GRE). Two things happen: protons gain transverse magnetization (signal!) and they spin in phase. Tip angle = <b>flip angle \u03b1</b>.',
          follow: ['What is a flip angle?', 'What is a gradient echo?'] },
        { k: ['t1 relaxation', 't1 recovery', 'spin lattice', 'longitudinal relaxation', 'explain t1'],
          a: '<b>T1 (spin-lattice) relaxation</b> is the recovery of longitudinal magnetization as protons hand their RF energy to the surrounding molecular lattice. Time constant T1 varies by tissue: <b>fat \u2248 250 ms recovers fast (bright on T1)</b>, water/CSF \u2248 4000 ms recovers slowly (dark on T1). Short TR exploits these differences \u2192 T1 weighting.',
          links: [['Interactive T1/T2 curves', 'about-mri.html']],
          follow: ['What is T2 relaxation?', 'How do I get T1 weighting?'] },
        { k: ['t2 relaxation', 't2 decay', 'spin spin', 'transverse decay', 'explain t2'],
          a: '<b>T2 (spin-spin) relaxation</b> is the loss of transverse magnetization as neighboring protons dephase each other. Water keeps phase long (T2 \u2248 2000 ms \u2192 bright on T2); muscle/fat decay fast (dark). Long TR + long TE exploits this \u2192 T2 weighting — the pathology sequence, because sick tissue holds water.',
          links: [['Interactive T1/T2 curves', 'about-mri.html']],
          follow: ['What is T2*?', 'What is T2 shine-through?'] },
        { k: ['t2star', 't2*', 'susceptibility decay'],
          a: '<b>T2*</b> is transverse decay including extra dephasing from field inhomogeneity and tissue susceptibility — so <b>T2* is always shorter than T2</b>. Gradient echo (no 180\u00b0 refocus) measures T2*: the basis of SWI, blood product detection and GRE — and the reason metal looks terrible on GRE but OK on spin echo.',
          follow: ['What is SWI?', 'Why does metal ruin GRE images?'] },
        { k: ['k-space', 'kspace', 'raw data'],
          a: '<b>K-space</b> is the raw-data matrix the scanner fills before an image exists. Key rule: <b>center = contrast and signal</b>, <b>edges = fine detail and sharp edges</b>. Fill only the center \u2192 blurry but correctly contrasted image; skip the periphery \u2192 lose resolution. The inverse FFT of k-space produces the image.',
          links: [['Try the K-Space Explorer', 'about-mri.html#kspace']],
          follow: ['What is the Fourier transform?', 'What is partial echo?'] },
        { k: ['fourier', 'fft', 'transform signal'],
          a: 'The <b>Fourier transform (FFT)</b> converts the time-domain signal (a sum of many frequencies from the coil) into a frequency spectrum. Because gradients made position \u2192 frequency (and phase), the FFT effectively converts measured signal \u2192 spatial positions. One FFT per readout line builds k-space; a 2D inverse FFT then yields the image.',
          follow: ['How does frequency encoding work?', 'What is k-space?'] },
        { k: ['gradient coil', 'gradients', 'spatial encoding', 'encoding'],
          a: '<b>Gradient coils</b> add small, linearly varying fields along X, Y and Z so that position changes resonance across the body. Their three jobs: <b>slice selection</b> (gradient during RF), <b>phase encoding</b> (brief gradient before readout), and <b>frequency encoding</b> (gradient during readout). Switching them is the famous knocking sound.',
          links: [['Gradient coils up close', 'components.html#gradient']],
          follow: ['What is phase encoding?', 'Why is MRI so loud?'] },
        { k: ['slice selection', 'slice select', 'select slice'],
          a: '<b>Slice selection:</b> a gradient is ON during the RF pulse, so only a thin slab of protons matches the pulse frequency. Slice thickness = RF bandwidth \u00f7 gradient strength. Wider transmitted band or weaker gradient \u2192 thicker slice.',
          follow: ['What is phase encoding?', 'What determines slice thickness?'] },
        { k: ['phase encoding', 'phase gradient'],
          a: '<b>Phase encoding:</b> a short gradient before readout gives each row of protons a different phase angle \u2014 a position label stored in the signal. It must be REPEATED once per phase step (e.g. 256 times) — this repetition is the main reason MRI scans take minutes.',
          follow: ['Why are scans slow?', 'What is frequency encoding?'] },
        { k: ['frequency encoding', 'readout gradient', 'readout'],
          a: '<b>Frequency encoding (readout):</b> during signal sampling, a gradient makes position along one axis correspond to frequency. Where phase encoding needs 256 repetitions, frequency encoding is free — captured inside each echo, all at once.',
          follow: ['What is phase encoding?', 'What is bandwidth?'] },
        { k: ['shimming', 'shim coil', 'homogeneity'],
          a: '<b>Shimming</b> fine-tunes B0 homogeneity (passive iron pieces + active shim coils). Good shimming \u2192 longer T2*, less distortion, uniform fat saturation and clean spectroscopy. Bad shimming \u2192 banding in bSSFP and fat-sat failures.',
          links: [['Shim coils', 'components.html#shim']],
          follow: ['Why does bSSFP band?', 'What causes fat-sat failure?'] },
        { k: ['signal detection', 'receive coil', 'faraday', 'antenna', 'how signal measured'],
          a: 'Receiver coils are antennas working by <b>Faraday induction</b>: the rotating transverse magnetization changes magnetic flux through the coil loop and induces a tiny voltage — the raw MRI signal. Coil choice matters hugely: a well-fitted surface coil near the anatomy dramatically boosts SNR vs the body coil.',
          links: [['RF coils', 'components.html#rf']],
          follow: ['What is SNR?', 'How do coils affect image quality?'] },
        { k: ['hydrogen', 'proton', 'why hydrogen', 'nucleus signal'],
          a: 'We image <b>hydrogen-1 (protons)</b> because the body is ~60% water and fat — full of hydrogen — and 1H has the highest gyromagnetic ratio of any stable nucleus: the strongest possible signal. Other nuclei (31P, 23Na) exist in research but need special hardware.',
          follow: ['What is MRI?', 'What is precession?'] },
        { k: ['fid', 'free induction decay', 'dephase'],
          a: 'The <b>free induction decay (FID)</b> is the signal immediately after excitation — it fades fast because spins dephase from field inhomogeneity (T2*). Spin echo\u2019s 180\u00b0 pulse rephases those spins to recover a true T2 echo; gradient echo just accepts the T2* loss for speed.',
          follow: ['What is T2*?', 'Why does spin echo use 180\u00b0?'] },
        { k: ['net magnetization', 'equilibrium', 'mz'],
          a: 'At equilibrium, slightly more protons sit parallel than anti-parallel to B0, leaving a small net <b>longitudinal magnetization (Mz)</b> along B0 — and zero transverse component. Everything MRI does (excite, relax, encode) is manipulation of this vector.',
          follow: ['What is the RF pulse?', 'Explain T1 recovery'] },

        /* ---------- SEQUENCES ---------- */
        { k: ['t1 weighted', 't1w', 't1 image', 'anatomy sequence'],
          a: '<b>T1-weighted images</b>: <b>short TR (~500 ms) + short TE (~15 ms)</b>. Fat bright, water dark, excellent anatomy. Uses: anatomical detail, post-gadolinium enhancement, marrow, MSK. Tip: T1 is the \u201canatomy\u201d sequence; T2 is the \u201cpathology\u201d sequence.',
          links: [['T1 section (real scan)', 'sequences.html#t1']],
          follow: ['What is T2 weighting?', 'When do I use gadolinium?'] },
        { k: ['t2 weighted', 't2w', 't2 image', 'pathology sequence'],
          a: '<b>T2-weighted images</b>: <b>long TR (>2000 ms) + long TE (>60 ms)</b>. Water and pathology glow bright — edema, tumors, inflammation, fluid collections. Add fat suppression (STIR/PDFS) in MSK to make pathology even more obvious.',
          links: [['T2 section (real scan)', 'sequences.html#t2']],
          follow: ['What is FLAIR?', 'What is STIR?'] },
        { k: ['pd', 'proton density', 'pd weighted'],
          a: '<b>Proton density (PD) weighting</b>: long TR + short TE — T1 and T2 effects minimized, leaving pure proton concentration differences. Classic for knee (menisci!) and brain PD-FLAIR. Usually with fat saturation in MSK.',
          follow: ['Best sequence for meniscus?', 'What is PDFS?'] },
        { k: ['flair', 'fluid attenuated', 'csf suppress'],
          a: '<b>FLAIR</b> = T2 with an inversion pulse that <b>nulls CSF</b> (TI \u2248 2500 ms at 3 T). Periventricular and juxtacortical lesions become unmistakable — the MS hunter, and great for subarachnoid disease and epilepsy work-ups.',
          links: [['FLAIR section (real case)', 'sequences.html#flair']],
          follow: ['What is STIR?', 'MS protocol sequences?'] },
        { k: ['stir', 'short tau inversion', 'fat suppression', 'fat sat', 'fatsat', 'fat suppress'],
          a: '<b>STIR</b> nulls fat with a short inversion time (\u2248150–180 ms) before a T2/PD readout. Marrow edema, soft-tissue fluid and tumors shine. Unlike CHESS fat-sat, STIR is robust near metal and in inhomogeneous fields — the MSK workhorse.',
          links: [['STIR deep dive', 'sequences.html#stir']],
          follow: ['Occult fracture sequence?', 'STIR vs FatSat?'] },
        { k: ['dwi', 'diffusion weighted', 'adc', 'restriction', 'b value', 'stroke sequence'],
          a: '<b>DWI</b> sensitizes signal to microscopic water motion (b-value, typically 1000 s/mm\u00b2). Cytotoxic edema (acute stroke, some tumors) <b>restricts</b> diffusion \u2192 bright DWI with <b>dark ADC</b>. Always read DWI with the ADC map to exclude T2 shine-through. Changes appear within minutes of stroke onset.',
          links: [['DWI section (real stroke case)', 'sequences.html#dwi']],
          follow: ['What is T2 shine-through?', 'How is DWI so fast?'] },
        { k: ['shine through', 't2 shine'],
          a: '<b>T2 shine-through</b>: a long-T2 lesion (e.g. chronic infarct or cyst) stays bright on DWI purely from its T2 signal — <b>not</b> true restriction. The discriminator is the <b>ADC map</b>: dark ADC = real restriction; bright ADC = shine-through.',
          follow: ['What is DWI?', 'What is an ADC map?'] },
        { k: ['swi', 'susceptibility weighted', 'blood products', 'hemosiderin', 'calcification', 'microhemorrhage'],
          a: '<b>SWI (T2* susceptibility-weighted)</b> exploits dephasing around iron and calcium: venous vessels, microhemorrhages, cavernomas, hemosiderin and calcification bloom <b>dark</b>. First choice for trauma microbleeds, cerebral amyloid angiopathy and cavernomas.',
          links: [['SWI section', 'sequences.html#swi']],
          follow: ['What is T2*?', 'Best sequence for hemorrhage?'] },
        { k: ['gradient echo', 'gre', 'flash', 'spgr', 'gradient echo sequences'],
          a: '<b>Gradient echo (GRE)</b>: no 180\u00b0 refocusing — fast, small flip angles, signal depends on T2*. Great for 3D volume imaging (MPRAGE), breath-hold T1, and detecting susceptibility (blood/calcification) — but vulnerable to metal and field inhomogeneity.',
          links: [['GRE section', 'sequences.html#gre']],
          follow: ['What is flip angle?', 'Why metal ruins GRE?'] },
        { k: ['spin echo', 'se sequence', '180 pulse', 'refocusing'],
          a: '<b>Spin echo</b>: 90\u00b0 excite \u2192 180\u00b0 refocus \u2192 echo at TE. The 180\u00b0 pulse reverses dephasing from field inhomogeneity, giving clean T2 (not T2*) contrast and artifact resistance. Cost: time — one phase line per TR.',
          follow: ['What is FSE/TSE?', 'What is T2*?'] },
        { k: ['fse', 'tse', 'fast spin echo', 'turbo spin echo', 'echo train', 'etl'],
          a: '<b>Fast/Turbo Spin Echo (FSE/TSE)</b> fires a train of 180\u00b0 pulses (echo train length / turbo factor 8–32) filling multiple k-space lines per TR — 8–32\u00d7 faster than spin echo with true T2 contrast. Trade-off: mild blur along phase direction.',
          follow: ['What is ETL?', 'What is HASTE?'] },
        { k: ['bssfp', 'balanced ssfp', 'truefisp', 'fiesta', 'cine sequence'],
          a: '<b>balanced SSFP (TrueFISP/FIESTA/b-FFE)</b>: steady-state GRE with bright blood, high SNR and motion robustness — the <b>cardiac cine workhorse</b>. Watch for dark banding off-resonance (fix with shimming / short TR).',
          follow: ['How does cardiac MRI work?', 'Why does bSSFP band?'] },
        { k: ['epi', 'echo planar', 'single shot'],
          a: '<b>Echo planar imaging (EPI)</b> fills ALL of k-space after one RF pulse (single shot \u2248 100 ms) — the fastest sequence in MRI, which is why DWI and perfusion use it. Price: distortion, susceptibility and N/2 ghosts, especially at bone-air interfaces.',
          follow: ['Why does DWI distort?', 'What is parallel imaging?'] },
        { k: ['tof', 'time of flight', 'mra', 'angiography', 'angiogram', 'vessels without contrast'],
          a: '<b>Time-of-flight MRA</b> makes flowing blood bright by flow-related enhancement: tissue saturates under repeated pulses, fresh spins don\u2019t. No contrast needed — great for circle of Willis. Weakness: slow/in-plane flow saturates \u2192 fix with MOTSA thin slabs.',
          links: [['MRA section', 'sequences.html#mra']],
          follow: ['What is phase-contrast MRA?', 'When is CE-MRA better?'] },
        { k: ['phase contrast mra', 'pc mra', 'venc', 'flow quantification'],
          a: '<b>Phase-contrast MRA</b> encodes velocity into phase (VENC setting). Unique power: it <b>quantifies</b> flow speed and direction — CSF flow studies, regurgitant fractions, Qp:Qs shunts. Slower than TOF and needs a good VENC guess.',
          follow: ['What is TOF MRA?', 'How is regurgitation measured?'] },
        { k: ['contrast enhanced mra', 'ce mra', 'gd mra', 'gadolinium angiography'],
          a: '<b>Contrast-enhanced MRA</b>: gadolinium shortens blood T1, so vessels stay bright regardless of flow physics — excellent in slow or turbulent flow (aorta, carotids, run-off). Requires bolus timing; first-pass technique.',
          follow: ['How does gadolinium work?', 'What is TOF MRA?'] },
        { k: ['mrcp', 'cholangiopancreatography', 'bile duct', 'biliary', 'gallbladder mri'],
          a: '<b>MRCP</b> uses heavily T2-weighted 3D/single-shot imaging: static fluid (bile, pancreatic duct) glows white against everything else — a non-invasive ERCP look-alike. Stones appear as dark filling defects. No contrast, no radiation, no sedation.',
          links: [['MRCP section', 'sequences.html#mrc']],
          follow: ['What is HASTE?', 'Liver lesion sequences?'] },
        { k: ['dce', 'dynamic contrast', 'permeability', 'washout', 'dynamic enhancement'],
          a: '<b>DCE (dynamic contrast-enhanced)</b> tracks gadolinium arrival passage-by-pass (arterial \u2192 portal \u2192 delayed for liver). Enhancement patterns diagnose lesions: HCC washes out, hemangioma fills in peripherally, metastases vary. Also used for prostate and breast.',
          links: [['DCE & gadolinium', 'sequences.html#dce']],
          follow: ['How does gadolinium work?', 'NSF risk factors?'] },
        { k: ['lge', 'late gadolinium', 'delayed enhancement', 'scar imaging', 'viability'],
          a: '<b>LGE (late gadolinium enhancement)</b>: 10–15 min post-Gd, contrast washes out of normal myocardium but pools in scar/fibrosis \u2192 bright scar on a dark (nulled) myocardium. Patterns: <b>subendocardial = infarct</b>, subepicardial/mid-wall = myocarditis/DCM. Scar transmurality predicts recovery after revascularization.',
          links: [['CMR protocols', 'body-parts.html#cardiac-section']],
          follow: ['What TI is used in LGE?', 'What is nulling in LGE?'] },
        { k: ['nulling', 'inversion time null', 'ti choice', 'myocardium dark'],
          a: '<b>Nulling</b> in LGE means choosing TI so normal myocardium crosses zero signal at readout — normal heart dark, scar bright. TI too short \u2192 myocardium too dark; too long \u2192 under-suppressed. Look–Locker (TI scout) sequences find the null point.',
          follow: ['What is LGE?', 'How does IR suppress anything?'] },
        { k: ['mprage', '3d t1', 'volumetry', 'isotropic'],
          a: '<b>MPRAGE</b>: 3D inversion-prepared T1 GRE giving thin, contiguous, isotropic brain volumes — reformats in any plane. The standard for hippocampal volumetry, cortical lesion search and surgical planning.',
          follow: ['What is GRE?', 'Epilepsy protocol?'] },
        { k: ['in opposed phase', 'dixon', 'chemical shift imaging', 'fat water'],
          a: '<b>In/opposed-phase imaging (Dixon)</b>: at 1.5 T fat and water are in-phase at TE \u2248 4.6 ms and opposed at \u2248 2.3 ms. Opposed-phase voxels containing both fat+water cancel (\u201cIndia ink\u201d borders) — fatty infiltration, adrenal adenoma diagnosis, and 4-point Dixon gives separate fat & water images.',
          follow: ['What is India ink artifact?', 'Fat saturation methods?'] },

        /* ---------- PARAMETERS ---------- */
        { k: ['what is tr', 'tr mean', 'repetition time', 'tr parameter'],
          a: '<b>TR (Repetition Time)</b> = time between successive RF pulses. <b>Short TR (<800 ms)</b> \u2192 T1 weighting (tissues differ in recovery). <b>Long TR (>2000 ms)</b> \u2192 T1 differences erased; PD/T2 territory. Longer TR also = longer scan time, but allows more slices per acquisition.',
          links: [['Parameter deep dive', 'parameters.html']],
          follow: ['What is TE?', 'How do I compute scan time?'] },
        { k: ['what is te', 'te mean', 'echo time', 'te parameter'],
          a: '<b>TE (Echo Time)</b> = time from excitation to signal readout. <b>Short TE (<35 ms)</b> \u2192 little T2 decay (T1/PD). <b>Long TE (>60 ms)</b> \u2192 T2 weighting, but less signal (it decayed). Very long TE \u2192 heavy T2 (MRCP, myelogram effect).',
          links: [['Parameter deep dive', 'parameters.html']],
          follow: ['What is TR?', 'What is TI?'] },
        { k: ['what is ti', 'ti mean', 'inversion time', 'ti parameter'],
          a: '<b>TI (Inversion Time)</b> = delay between the 180\u00b0 inversion pulse and readout in IR sequences. Choose TI to <b>null</b> a tissue: CSF \u2248 2500 ms (FLAIR), fat \u2248 160 ms (STIR), myocardium \u2248 300 ms in LGE. Wrong TI = incomplete suppression.',
          follow: ['What is FLAIR?', 'How does LGE nulling work?'] },
        { k: ['flip angle', 'alpha', 'ernst angle'],
          a: '<b>Flip angle (\u03b1)</b>: how far RF tips the magnetization. Spin echo uses 90\u00b0; GRE uses 5–45\u00b0. In GRE, <b>bigger \u03b1 \u2192 more T1 weighting</b>; small \u03b1 \u2192 PD/T2* weighting. The Ernst angle maximizes GRE signal for a given T1/TR. Higher \u03b1 also raises SAR.',
          follow: ['What is GRE?', 'What is SAR?'] },
        { k: ['fov', 'field of view', 'small fov'],
          a: '<b>FOV</b> = the physical size of the image. Pixel = FOV \u00f7 matrix — a smaller FOV means finer detail BUT lower SNR (less tissue per voxel) and possible wrap-around if anatomy exits the FOV along phase.',
          follow: ['What is wrap-around?', 'How do I raise SNR?'] },
        { k: ['matrix', 'phase matrix', 'frequency matrix', 'resolution numbers'],
          a: '<b>Matrix</b> = number of pixels (frequency \u00d7 phase). Bigger matrix \u2192 better resolution, lower SNR, and — critically — more <b>phase</b> steps cost TR repeats: doubling phase matrix doubles scan time; doubling frequency matrix doesn\u2019t.',
          follow: ['Why is phase encoding slow?', 'Scan time formula?'] },
        { k: ['nex', 'nsa', 'averages', 'signal averages', 'number of excitations'],
          a: '<b>NEX/NSA</b> = how many times each phase step is repeated and averaged. <b>SNR improves as \u221aNEX</b> (4 NEX = 2\u00d7 SNR) but scan time grows linearly (4 NEX = 4\u00d7 time). Classic noise-reduction tool at a time price.',
          follow: ['How do I raise SNR?', 'Trade-off triangle?'] },
        { k: ['etl', 'turbo factor', 'echo train length'],
          a: '<b>ETL / turbo factor</b> = echoes collected per TR in FSE. Higher ETL \u2192 proportionally faster scanning, but more blur along the phase axis (point-spread function broadens). Typical: brain T2 ETL 16–20; MRCP single-shot ETL = full matrix.',
          follow: ['What is FSE?', 'Why is my FSE blurry?'] },
        { k: ['bandwidth', 'receiver bandwidth', 'narrow bw', 'wide bandwidth'],
          a: '<b>Receiver bandwidth</b> = frequency range per pixel. <b>Narrow</b> \u2192 higher SNR but more chemical shift and higher minimum TE. <b>Wide</b> \u2192 less chemical shift and metal artifact, shorter TE, but noisier. Near hardware: go wide.',
          follow: ['What is chemical shift artifact?', 'Metal artifact protocol?'] },
        { k: ['pixel', 'voxel', 'resolution define', 'voxel volume'],
          a: '<b>Pixel = FOV \u00f7 matrix</b> (in-plane); <b>voxel = pixel \u00d7 slice thickness</b>. Resolution improves with smaller voxels, but SNR falls with voxel volume — the eternal trade. Try it live in the scan-time & voxel calculator.',
          links: [['Voxel calculator', 'parameters.html#calculator']],
          follow: ['How do I improve SNR?', 'What is partial volume?'] },
        { k: ['scan time', 'how long scan', 'acquisition time', 'time formula', 'compute time'],
          a: '<b>Scan time (2D SE)</b> = TR \u00d7 phase steps \u00d7 NEX (\u00f7 ETL for FSE). Make it faster: ETL \u2191, NEX \u2193, phase matrix \u2193, rectangular FOV, parallel imaging, shorter TR. Each costs SNR, resolution or artifacts.',
          links: [['Scan-time calculator', 'parameters.html#calculator']],
          follow: ['What is parallel imaging?', 'What is rectangular FOV?'] },
        { k: ['snr', 'signal to noise', 'improve snr', 'raise snr', 'noisy image'],
          a: '<b>SNR</b> grows with: voxel volume \u2191 (thicker slices/bigger FOV/smaller matrix), \u221aNEX, narrow bandwidth, better coil fit, lower field\u2026 no wait — higher field! It falls with parallel imaging (\u221aR + g-factor) and wide BW. Quick win at no time cost: <b>thicker slices</b>.',
          follow: ['What is the trade-off triangle?', 'What does NEX do?'] },
        { k: ['trade-off triangle', 'triangle snr', 'snr resolution time', 'balance mri'],
          a: 'The <b>MRI trade-off triangle</b>: <b>SNR \u00b7 Spatial resolution \u00b7 Scan time</b> — optimize any two, pay with the third. Fast AND sharp = noisy. Fast AND clean = coarse. Sharp AND clean = slow. Every protocol is a walk around this triangle.',
          links: [['Parameters page', 'parameters.html']],
          follow: ['How do I raise SNR?', 'How do I shorten a scan?'] },
        { k: ['parallel imaging', 'grappa', 'sense', 'acceleration factor'],
          a: '<b>Parallel imaging (GRAPPA/SENSE)</b> uses coil sensitivity to skip phase lines and undo the aliasing mathematically — R=2 halves time. Cost: SNR drops \u219aR-plus g-factor, calibration artifacts possible. Standard in cardiac and body MRI.',
          follow: ['Scan time formula?', 'What is g-factor?'] },
        { k: ['rectangular fov', 'rfov', 'phase fov', 'reduce phase'],
          a: '<b>Rectangular (reduced phase) FOV</b>: sample fewer phase steps over a shortened axis — faster scans for anatomy longer in one direction (spine sagittal, axial body). Watch wrap-around along phase.',
          follow: ['What is wrap-around?', 'Scan time formula?'] },

        /* ---------- CARDIAC ---------- */
        { k: ['cardiac mri', 'cmr', 'heart mri', 'cardiac magnetic resonance', 'heart scan'],
          a: '<b>Cardiac MR (CMR)</b> is the gold standard for ventricular volumes/EF, tissue characterization and congenital assessment. Core kit: <b>cine bSSFP</b> (function), <b>LGE</b> (scar), <b>T2/STIR</b> (edema), <b>perfusion</b> (ischemia), <b>mapping</b> (T1/ECV, T2*) — all ECG-gated.',
          links: [['CMR masterclass', 'body-parts.html#cardiac-section']],
          follow: ['What is LGE?', 'What is T2* for iron?'] },
        { k: ['cardiac tagging', 'strain', 'spam'],
          a: '<b>Myocardial tagging</b> saturation grids deform with contraction, revealing regional strain and twist that cine alone can miss — now largely complemented by feature-tracking strain analysis.',
          follow: ['How does cine bSSFP work?', 'What is feature tracking?'] },
        { k: ['dark rim', 'perfusion artifact'],
          a: 'The <b>dark-rim artifact</b> on first-pass perfusion is a thin subendocardial dark band from susceptibility/motion/Gibbs — it can mimic ischemia. A true defect persists across phases and matches a coronary territory; dark rim flickers at the bolus peak.',
          follow: ['How does stress perfusion work?', 'What is adenosine stress?'] },
        { k: ['t2star iron', 'iron overload', 'thalassemia heart', 'chelation', 't2* mapping'],
          a: '<b>Myocardial T2* &lt; 20 ms</b> = clinically significant cardiac iron overload (thalassemia major) — intensify chelation. Multi-echo T2* mapping quantifies it non-invasively, tracking therapy over years alongside liver iron.',
          follow: ['What is T2*?', 'What is T1 mapping?'] },
        { k: ['t1 mapping', 'ecv', 'extracellular volume', 'amyloid', 'native t1'],
          a: '<b>T1 mapping / ECV</b> quantify the interstitium: elevated native T1 & ECV = fibrosis, edema or infiltration (amyloid lights up with difficulty nulling + late diffuse Gd). Iron lowers T1/T2* — mapping completes the tissue story cine and LGE can\u2019t tell.',
          follow: ['What is LGE?', 'Cardiac amyloid on MRI?'] },

        /* ---------- SAFETY ---------- */
        { k: ['acr zones', 'safety zones', 'zone iii', 'zone iv', 'four zones'],
          a: '<b>ACR Zones:</b> I = public/unrestricted \u00b7 II = interface (screening starts) \u00b7 III = controlled access, physical lock, fringe field — ONLY screened persons \u00b7 IV = the magnet room itself, door closed, never unattended. Motion: screening deepens at every step from II \u2192 IV.',
          links: [['Safety zones', 'safety.html']],
          follow: ['What is MR Conditional?', 'What is the 5-gauss line?'] },
        { k: ['mr conditional', 'mr safe', 'mr unsafe', 'astm label', 'implant label', 'pacemaker', 'icd', 'defibrillator', 'device safety', 'implant safety'],
          a: '<b>ASTM F2503 labels:</b> \u25a1 <b>MR Safe</b> (green square) — non-conducting, non-metallic, no risk anywhere. \u25b3 <b>MR Conditional</b> (yellow triangle) — safe ONLY under listed conditions (field, SAR, gradients). \u26d4 <b>MR Unsafe</b> — never enters Zone IV. Always match device card conditions to your scanner.',
          links: [['ASTM labeling', 'safety.html#astm']],
          follow: ['What are ACR zones?', 'Pacemaker policy?'] },
        { k: ['quench', 'quench button', 'emergency stop magnet', 'helium vent', 'magnet shutdown'],
          a: 'A <b>quench</b> rapidly boils the liquid helium, collapsing B0 within minutes. <b>Only for life-threatening entrapment</b> (someone pinned to the bore). Risks: \u2013269\u00b0C gas, oxygen displacement if the vent fails, enormous cost. Evacuate, ventilate, never re-enter until cleared.',
          links: [['Quench protocols', 'safety.html#quench']],
          follow: ['What are ACR zones?', 'Why is helium used?'] },
        { k: ['helium', 'cryogen', 'liquid helium', 'superconducting cold'],
          a: '<b>Liquid helium at \u22484 K (\u2013269\u00b0C)</b> keeps the niobium-titanium windings superconducting (zero resistance). Modern zero-helium-boil-off magnets recycle vented gas; a quench dumps the entire cryogen through the roof pipe.',
          follow: ['What is a quench?', 'How strong is the magnet?'] },
        { k: ['5 gauss', 'five gauss', 'fringe field', 'pacemaker line'],
          a: 'The <b>5-gauss line (0.5 mT)</b> marks where the stray field falls to levels considered safe for the general public and pacemakers. It must sit entirely inside controlled Zones III/IV — this defines the room and the point beyond which no unscreened person or equipment passes.',
          follow: ['What are ACR zones?', 'How strong is the magnet?'] },
        { k: ['sar', 'specific absorption rate', 'rf heating', 'tissue heating', 'sar limit'],
          a: '<b>SAR</b> = RF energy deposited per kg of tissue (W/kg). Rises with flip angle\u00b2, field\u00b2 and RF duty cycle — bSSFP/FSE at 3 T are the usual suspects. Systems monitor limits (whole-body ~2–4 W/kg levels) and will throttle sequences; patients feel warmth at high SAR.',
          follow: ['Why does 3T heat more?', 'What is dB/dt?'] },
        { k: ['db dt', 'dbdt', 'nerve stimulation', 'peripheral nerve', 'gradient switching risk'],
          a: 'Rapidly switched gradients (<b>high dB/dt</b>) induce currents in the body — the biological endpoint is <b>peripheral nerve stimulation</b> (tingling, twitching), not heating. Systems cap dB/dt; report any tingling — it\u2019s a limit, not a curiosity.',
          follow: ['What is SAR?', 'Why is MRI loud?'] },
        { k: ['nsf', 'nephrogenic', 'gadolinium renal', 'egfr contrast', 'kidney contrast'],
          a: '<b>NSF (nephrogenic systemic fibrosis)</b>: rare, fibrosing disease linked to gadolinium in severe renal failure (eGFR &lt;30) — historically older linear agents. Policy: screen eGFR, prefer macrocyclic group II agents, adjust dose, document. With modern agents and screening, risk is extremely low.',
          follow: ['How does gadolinium work?', 'Pregnancy and contrast?'] },
        { k: ['pregnancy', 'pregnant', 'pregnant patient', 'mri pregnant'],
          a: '<b>Pregnancy:</b> non-contrast MRI at any stage is considered acceptable when the study is justified (no known harm). <b>Gadolinium only in life-critical situations.</b> Staff pregnancy: routine work is fine; stay out of Zone IV during scanning.',
          follow: ['NSF risk factors?', 'What is MR Conditional?'] },
        { k: ['projectile', 'ferromagnetic danger', 'flying object', 'oxygen tank', 'keys magnet'],
          a: 'The static field turns ferromagnetic items into <b>projectiles</b> — force grows near the bore. Classic killers: oxygen cylinders, scissors, keys, phones, floor buffers, wheelchairs, anaesthetic cylinders. Rule: NOTHING crosses Zone III without screening — that includes fire crews\u2019 SCBA tanks.',
          links: [['Safety page', 'safety.html']],
          follow: ['What are ACR zones?', 'What is a quench?'] },
        { k: ['screening', 'screening form', 'safety questionnaire', 'implant card'],
          a: '<b>Screening</b> = written form + verbal interview + metal detector for EVERY person entering Zone III/IV — patients, staff, relatives, repair technicians. Verify implants against the device card / mrisafety.com; unverified \u2260 conditional. One missed aneurysm clip can be fatal.',
          links: [['Screening simulator', 'preparation.html#screener-tool']],
          follow: ['What is MR Conditional?', 'What if implant unknown?'] },
        { k: ['patch', 'transdermal', 'nicotine patch', 'fentanyl patch'],
          a: '<b>Transdermal patches with metallic foil</b> (nicotine, fentanyl, scopolamine…) can heat and burn under RF. Remove before entry, note the time, replace after the scan per pharmacy policy.',
          follow: ['Tattoo safety?', 'What is SAR?'] },
        { k: ['tattoo', 'tattoos mri', 'pigment heating'],
          a: '<b>Tattoos:</b> iron-oxide pigments can heat under RF (burns are rare). Precautions: cold damp compress over large dark tattoos, and tell the patient to report warmth immediately via the buzzer.',
          follow: ['What about patches?', 'Claustrophobia tips?'] },
        { k: ['loud', 'noise', 'hearing', 'ear protection', 'earplugs', 'why mri loud'],
          a: 'Gradient switching makes MRI <b>up to 110–120+ dB</b> — hearing protection (earplugs \u2265 29 dB NRR or headphones) is mandatory for everyone in Zone IV. The knocking is literally the gradient coils flexing (Lorentz forces) thousands of times per second.',
          follow: ['What are gradient coils?', 'What is dB/dt?'] },
        { k: ['claustrophobia', 'claustrophobic', 'anxious', 'panic', 'scared patient', 'nervous patient'],
          a: '<b>Claustrophobia playbook:</b> explain the bore beforehand, prism glasses, music, breathing ball, feet-first when possible, buzzer in hand, clear stop-signals, short protocols, and pre-medication or sedation per policy when needed. Most patients complete with coaching alone.',
          links: [['Patient prep', 'preparation.html']],
          follow: ['What is a screening form?', 'How long do scans take?'] },
        { k: ['extravasation', 'contrast leak', 'iv leak'],
          a: '<b>Gadolinium extravasation:</b> stop the injection, aspirate what you can, elevate the limb, cold compresses, observe for compartment syndrome (severe pain, pallor, paresthesia) — that one gets urgent surgical review. Document everything.',
          follow: ['NSF risk factors?', 'IV cannula size?'] },
        { k: ['iv', 'cannula', 'iv access', 'needle contrast'],
          a: '<b>IV access for contrast MRI:</b> 20–22 G in the antecubital fossa for power injection (3–5 mL/s for perfusion/MRA), flushed and tested. Smaller hand veins may suffice for routine post-Gd imaging at slower rates.',
          follow: ['Extravasation management?', 'How does gadolinium work?'] },

        /* ---------- ARTIFACTS ---------- */
        { k: ['motion artifact', 'ghosting', 'patient moved', 'ghost image'],
          a: '<b>Motion ghosting</b>: movement during the long phase encoding repeats, smearing copies along the phase axis. Fixes: coaching + immobilization, faster sequences, PROPELLER/BLADE, sedation when justified.',
          links: [['Artifact Atlas (live demo)', 'scan-atlas.html']],
          follow: ['What is PROPELLER?', 'What is wrap-around?'] },
        { k: ['metal artifact', 'susceptibility artifact', 'implant artifact', 'hip mri artifact'],
          a: '<b>Metal susceptibility artifact</b>: metal distorts the local field \u2192 signal void + bright bloom, worst on GRE/EPI and long TE. MARS recipe: <b>FSE (not GRE), wide bandwidth, STIR (not CHESS), thin slices, avoid EPI</b>.',
          links: [['Artifact Atlas (live demo)', 'scan-atlas.html']],
          follow: ['Why does STIR beat FatSat near metal?', 'What is T2*?'] },
        { k: ['wrap around', 'aliasing', 'fold over', 'anatomy outside fov'],
          a: '<b>Wrap-around (aliasing)</b>: anatomy outside the FOV along PHASE folds back into the opposite side. Fixes: bigger FOV, oversampling, swap phase/frequency axes, saturation bands outside the anatomy.',
          links: [['Artifact Atlas (live demo)', 'scan-atlas.html']],
          follow: ['What is rectangular FOV?', 'What is Gibbs?'] },
        { k: ['gibbs', 'truncation', 'ringing artifact'],
          a: '<b>Gibbs (truncation) ringing</b>: finite k-space sampling causes parallel dark/bright bands beside sharp high-contrast edges (skull-brain, cord). Mitigate: larger matrix, smoothing filters.',
          links: [['Artifact Atlas (live demo)', 'scan-atlas.html']],
          follow: ['What is k-space?', 'What is chemical shift?'] },
        { k: ['zipper', 'rf artifact', 'line artifact', 'rf leak'],
          a: '<b>RF zipper</b>: a discrete line/strip of noise from radiofrequency leaking in — door not fully closed, monitoring cables, faulty lights. Remove the source; call service if internal.',
          links: [['Artifact Atlas (live demo)', 'scan-atlas.html']],
          follow: ['What is a spike artifact?', 'Why must the door close?'] },
        { k: ['spike artifact', 'herringbone', 'stripe'],
          a: '<b>Spike / herringbone</b>: one corrupt data point in k-space spreads into periodic stripes across the image after FFT. It\u2019s a hardware fault (gradient/electronics) — re-scan, then service.',
          links: [['Artifact Atlas (live demo)', 'scan-atlas.html']],
          follow: ['What is a zipper artifact?', 'What is k-space?'] },
        { k: ['india ink', 'phase cancellation', 'black border organ'],
          a: '<b>India-ink (phase cancellation)</b>: on opposed-phase images, voxels with 50/50 fat+water cancel — organs get crisp black outlines. It\u2019s diagnostic information (fatty liver, adrenal adenoma), not a fault!',
          links: [['Artifact Atlas (live demo)', 'scan-atlas.html']],
          follow: ['What is Dixon imaging?', 'What is chemical shift?'] },
        { k: ['shading artifact', 'inhomogeneity', 'coil artifact', 'signal drift'],
          a: '<b>Shading / RF inhomogeneity</b>: gradual signal fall-off across the image from uneven coil sensitivity or poor tuning. Fix: reposition coil, recalibrate gains, apply surface-coil intensity correction.',
          links: [['Artifact Atlas (live demo)', 'scan-atlas.html']],
          follow: ['What is shimming?', 'Why use small coils?'] },
        { k: ['crosstalk', 'slice cross', 'slice interaction'],
          a: '<b>Slice cross-talk</b>: imperfect slice profiles partially excite neighbouring slices, altering their contrast. Fixes: interleave slice order, add gaps, or acquire true 3D volumes.',
          links: [['Artifact Atlas (live demo)', 'scan-atlas.html']],
          follow: ['What is a 3D acquisition?', 'What is MPRAGE?'] },
        { k: ['chemical shift', 'dark band interface', 'fat water shift'],
          a: '<b>Chemical shift artifact</b>: fat and water resonate 3.5 ppm apart, so fat signal misregisters along the frequency axis — dark/bright bands at interfaces (kidneys, cord, orbits). Worse with narrow bandwidth and higher field; fix with wider BW or fat suppression.',
          links: [['Artifact Atlas (live demo)', 'scan-atlas.html']],
          follow: ['What is bandwidth?', 'What is Dixon?'] },

        /* ---------- PREP / CLINICAL ---------- */
        { k: ['patient preparation', 'prepare patient', 'before scan', 'prep steps'],
          a: '<b>Preparation pipeline:</b> identity + order check (2 identifiers) \u2192 full safety questionnaire \u2192 gowning & metal strip (100% cotton — streetwear contains metal threads!) \u2192 renal labs/IV if contrast \u2192 FMDS portal verification \u2192 positioning + coil + buzzer + hearing protection.',
          links: [['Preparation page', 'preparation.html']],
          follow: ['What is a screening form?', 'Claustrophobia tips?'] },
        { k: ['gown', 'clothes', 'change clothes', 'cotton gown'],
          a: 'Patients change into <b>100% cotton gowns</b>: modern athletic/antimicrobial fabrics weave in metallic silver fibers that heat under RF. Remove everything metal — jewelry, hairpins, hearing aids, wallets with cards, adhesive bras.',
          follow: ['What about patches?', 'Patient prep steps?'] },
        { k: ['gadolinium', 'how contrast works', 'contrast agent', 'gad dye', 'what is contrast'],
          a: '<b>Gadolinium contrast</b> is a chelated paramagnetic agent that <b>shortens T1 of nearby water</b> \u2192 bright on T1 images. It highlights breakdown of the blood–brain barrier, tumors, active inflammation, and vessels (CE-MRA). It does NOT glow by itself — it changes tissue relaxation.',
          links: [['DCE & gadolinium', 'sequences.html#dce']],
          follow: ['NSF risk factors?', 'What is LGE?'] },
        { k: ['hippocampus', 'mesial temporal', 'mts', 'temporal lobe epilepsy', 'hippocampal sclerosis'],
          a: 'The <b>hippocampus</b> (mesial temporal lobe, memory center) is the focus of epilepsy MRI: <b>mesial temporal sclerosis</b> = small, T2-bright hippocampus with enlarged horn + loss of internal structure. Protocol: thin coronal T2/FLAIR + 3D T1 MPRAGE volumetry.',
          links: [['Epilepsy protocol', 'body-parts.html#brain-section']],
          follow: ['Brain protocol sequences?', 'What is MPRAGE?'] },
        { k: ['prospective triggering', 'retrospective gating', 'ecg gating', 'cardiac gating', 'trigger delay', 'dead space gating'],
          a: '<b>Cardiac gating</b> synchronises the sequence to the R-wave. <b>Prospective triggering</b> stops acquisition before the next R-wave — a “dead space” where atrial systole is never imaged. <b>Retrospective gating</b> acquires continuously and bins data onto the average R-R — every phase captured, ideal for volumes/EF, but unreliable in arrhythmia.',
          links: [['Try the Gating Simulator', 'cardiac-mri.html#cmr-physics']],
          follow: ['What is cine bSSFP?', 'How does MOLLI work?'] },
        { k: ['molli', 'shmolli', 't1 mapping method', 'look-locker', 'look locker'],
          a: '<b>MOLLI</b> (Modified Look-Locker) samples T1 recovery across heartbeats: the classic <b>3(3)3(3)5</b> scheme = groups of readout beats after separate inversions with recovery waits. <b>ShMOLLI 5(1)1(1)1</b> is shorter and uses conditional fitting (uses fewer inversions for long T1s where recovery is incomplete).',
          links: [['MOLLI scheme strip', 'cardiac-mri.html#cmr-physics']],
          follow: ['How is ECV calculated?', 'What raises native T1?'] },
        { k: ['ecv formula', 'extracellular volume calculation', 'calculate ecv', 'lambda partition'],
          a: '<b>ECV</b> = (1 − haematocrit) × λ, where <b>λ = ΔR1 myocardium ÷ ΔR1 blood</b> (R1 = 1/T1, pre vs post gadolinium). Normal ≈ 22–26%; raised in fibrosis, oedema, amyloid (&gt;40% typical). SEENmri has a working ECV calculator on the Cardiac MRI page.',
          links: [['ECV Calculator', 'cardiac-mri.html#cmr-physics']],
          follow: ['T2* iron thresholds?', 'What is MOLLI?'] },
        { k: ['spamm', 'myocardial tagging', 'cspamm', 'tag lines', 'strain imaging tags'],
          a: '<b>Myocardial tagging (SPAMM)</b> prints a magnetisation grid into the myocardium that moves <b>with the tissue</b> — exposing contraction and twist invisible on standard cine. Tags <b>fade by T1 recovery</b>: they persist longer at higher field strength and vanish quickly after gadolinium. CSPAMM subtraction extends tag life.',
          links: [['Live tagging demo', 'cardiac-mri.html#cmr-physics']],
          follow: ['What is circumferential strain?', 'How does gating work?'] },
        { k: ['dark rim artifact perfusion', 'dark rim'],
          a: 'The <b>dark-rim artifact</b> is a thin subendocardial dark band at peak bolus in first-pass perfusion — caused by susceptibility, Gibbs ringing and motion, <b>not</b> ischaemia. A true defect persists across phases and matches a coronary territory; the dark rim flickers at the LV spike.',
          links: [['Perfusion animation', 'cardiac-mri.html#cmr-perfusion']],
          follow: ['Adenosine stress protocol?', 'What is MVO?'] },
        { k: ['mri vs ct', 'ct versus mri', 'difference ct mri', 'mri vs xray', 'radiation'],
          a: '<b>MRI vs CT:</b> MRI = magnetic protons, superb soft-tissue contrast (brain, MSK, cord, heart), multiplanar, no ionizing radiation, slower and louder. CT = X-rays, unbeatable for bone, acute bleeding, lungs and trauma speed, with radiation. They\u2019re complements, not rivals — the right tool depends on the question.',
          follow: ['What is MRI?', 'Why is MRI safe?'] },

        /* ---------- BODY PART PROTOCOLS ---------- */
        { k: ['brain protocol', 'brain mri sequences', 'head mri', 'neuro protocol'],
          a: '<b>Core brain protocol:</b> Sag T1 + Ax T1 \u00b7 Ax T2/FLAIR \u00b7 DWI+ADC \u00b7 GRE/SWI \u00b7 \u00b1 post-Gd T1. Additions: MS \u2192 sag 3D FLAIR + cervical cord; stroke \u2192 MRA + perfusion; epilepsy \u2192 thin coronal T2/FLAIR + 3D MPRAGE.',
          links: [['Brain protocols', 'body-parts.html#brain-section']],
          follow: ['What is FLAIR?', 'Stroke imaging sequence?'] },
        { k: ['spine protocol', 'lumbar protocol', 'spine sequences', 'cervical protocol'],
          a: '<b>Lumbar spine:</b> Sag T2 + Sag T1 + Ax T2 through levels + STIR (screening). <b>Cervical myelopathy:</b> Sag T2/T1 + Ax T2/GRE + STIR. Contrast only for infection/tumor/post-op scar questions.',
          links: [['Spine protocols', 'body-parts.html#spine-section']],
          follow: ['Discitis protocol?', 'Best disc herniation view?'] },
        { k: ['knee protocol', 'knee sequences', 'meniscus sequence', 'knee mri', 'meniscus', 'meniscal tear', 'best knee sequence'],
          a: '<b>Knee protocol:</b> Sag PD fat-sat (menisci!) + Sag T2 + Cor PD fat-sat (collaterals, roots) + Ax fat-sat (patellofemoral). Occult fracture? Add STIR + T1. The PD-FS sagittal is the money sequence for meniscal tears.',
          links: [['MSK protocols', 'body-parts.html#msk-section'], ['Protocol Advisor', 'body-parts.html#protocol-advisor']],
          follow: ['What is PD weighting?', 'Bone bruise sequence?'] },
        { k: ['shoulder protocol', 'shoulder sequences', 'labrum', 'rotator cuff'],
          a: '<b>Shoulder:</b> Cor PD fat-sat (cuff) + Sag T2 + Ax T1/PD (labrum, glenohumeral joint) \u00b1 ABER position for anteroinferior labrum. Direct MR arthrography remains gold standard for labral tears.',
          follow: ['Knee protocol?', 'What is ABER?'] },
        { k: ['liver protocol', 'liver sequences', 'liver lesion', 'hepatocyte'],
          a: '<b>Liver characterization:</b> T2 FSE + single-shot \u00b7 in/opposed-phase GRE (fat/adenoma) \u00b7 DWI \u00b7 dynamic T1 post-Gd (arterial/portal/delayed) \u00b7 \u00b1 hepatobiliary phase agent for FNH/adenoma questions.',
          links: [['Abdomen protocols', 'body-parts.html#abdomen-section']],
          follow: ['What is DCE?', 'What is MRCP?'] }
    ];

    var SYNONYMS = {
        heart: 'cardiac', cardiovascular: 'cardiac', myocardial: 'cardiac',
        kidney: 'renal', kidneys: 'renal', scare: 'claustrophobia', afraid: 'claustrophobia',
        dye: 'contrast gadolinium', loud: 'noise', sound: 'noise', banging: 'noise',
        move: 'motion', moving: 'motion', 'metal implant': 'metal artifact',
        'brain scan': 'brain protocol', 'knee scan': 'knee protocol', 'back pain': 'spine protocol',
        picture: 'image', pictures: 'image', photo: 'image'
    };

    var DOMAIN_WORDS = ['mri', 'mr ', 'tesla', 't1', 't2', 'tr', 'te', 'ti', 'flair', 'dwi', 'adc', 'swi',
        'gre', 'se ', 'fse', 'bssfp', 'epi', 'mra', 'mrcp', 'lge', 'sar', 'snr', 'fov', 'nex', 'etl',
        'k-space', 'kspace', 'larmor', 'proton', 'artifact', 'artifact', 'scan', 'magnet', 'coil', 'gradient',
        'voxel', 'matrix', 'contrast', 'gadolinium', 'quench', 'helium', 'screening', 'pregnan', 'cardiac',
        'brain', 'spine', 'knee', 'shoulder', 'liver', 'zone', 'claustro', 'patient', 'sequence', 'protocol',
        'relaxation', 'precession', 'fourier', 'shim', 'slice', 'phase', 'frequency', 'bandwidth', 'flip',
        'stroke', 'tumor', 'lesion', 'edema', 'myocar', 'iron', 'thick', 'meniscus', 'meniscal', 'hippocamp',
        'ligament', 'cartilage', 'disc', 'nerve', 'root compression', 'marrow', 'ventric', 'cyst',
        'hemorrhage', 'bleed', 'sclerosis', 'cord', 'ms ', 'aneurysm', 'pacemaker', 'implant'];

    var STOPWORDS = { 'the': 1, 'a': 1, 'an': 1, 'is': 1, 'are': 1, 'was': 1, 'what': 1, 'what\u2019s': 1,
        'how': 1, 'why': 1, 'does': 1, 'do': 1, 'of': 1, 'in': 1, 'on': 1, 'to': 1, 'and': 1, 'for': 1,
        'with': 1, 'me': 1, 'my': 1, 'can': 1, 'you': 1, 'tell': 1, 'about': 1, 'explain': 1, 'please': 1, 'it': 1 };

    /* ============================================================
       MATCHING ENGINE
       ============================================================ */
    function normalize(q) {
        q = ' ' + q.toLowerCase().replace(/(\d)\.(\d)/g, '$1DECPT$2').replace(/[?!.,;:'"()]/g, ' ').replace(/DECPT/g, '.').replace(/\s+/g, ' ').trim() + ' ';
        Object.keys(SYNONYMS).forEach(function (from) {
            q = q.replace(new RegExp('\\b' + from + '\\b', 'g'), SYNONYMS[from]);
        });
        return q;
    }

    function tokens(nq) {
        return nq.split(' ').filter(function (t) { return t && !STOPWORDS[t] && t.length > 1; });
    }

    function scoreEntry(e, nq, toks) {
        var s = 0;
        e.k.forEach(function (key) {
            var esc = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            var phrase = new RegExp('(^| )' + esc + '( |$)');
            if (phrase.test(nq)) {
                s += 6 + key.split(' ').length * 2;
            } else if (key.length > 4 && nq.indexOf(key) !== -1) {
                s += 2.5 + key.split(' ').length;
            }
        });
        var etoks = tokens(' ' + e.k.join(' ') + ' ' + (e.topic || ''));
        toks.forEach(function (t) {
            etoks.forEach(function (et) {
                if (t === et) s += 1.5;
                else if (et.indexOf(t) === 0 && t.length > 3) s += 0.75;
            });
        });
        return s;
    }

    function isDomain(nq) {
        return DOMAIN_WORDS.some(function (w) { return nq.indexOf(w) !== -1; });
    }

    function larmorHandler(nq) {
        var m, b = null;
        var re = /(\d+(?:\.\d+)?)\s*(?:t\b|tesla)/g;
        while ((m = re.exec(nq)) !== null) {
            var v = parseFloat(m[1]);
            if (v > 0.05 && v <= 12) { b = v; break; }
        }
        if (b !== null && (nq.indexOf('larmor') !== -1 || nq.indexOf('frequency') !== -1)) {
        var f = 42.58 * b;
            return { html: 'The Larmor frequency at <b>' + b + ' T</b> is <b>' + f.toFixed(1) + ' MHz</b> \u2014 that\u2019s the RF frequency the scanner transmits at that field. (f = 42.58 MHz/T \u00d7 B0)',
                     links: [['Physics section', 'about-mri.html#physics']], follow: ['What is the RF pulse?', '1.5T vs 3T?'] };
        }
        return null;
    }

    function bestAnswer(query) {
        var nq = normalize(query);
        var toks = tokens(nq);

        var special = larmorHandler(nq);
        if (special) return special;

        var best = null, bestScore = 0, second = null, secondScore = 0;
        KB.forEach(function (e) {
            var s = scoreEntry(e, nq, toks);
            if (s > bestScore) { second = best; secondScore = bestScore; best = e; bestScore = s; }
            else if (s > secondScore) { second = e; secondScore = s; }
        });

        if (best && bestScore >= 4.2) {
            var res = { html: best.a, links: best.links || null, follow: best.follow || null };
            /* add second-best as a follow-up chip if we lack ideas */
            if (!res.follow && second && secondScore > 3) {
                res.follow = [second.k[0].replace(/\b\w/g, function (c) { return c.toUpperCase(); }) + '?'];
            }
            return res;
        }

        /* fallback: search the site index */
        if (window.SEENMRI_INDEX && isDomain(nq)) {
            var q = nq.trim();
            var hit = null, hs = 0;
            function stemHit(tok, text) {
                if (text.indexOf(tok) !== -1) return true;
                return tok.length >= 6 && text.indexOf(tok.slice(0, 8)) !== -1;
            }
            window.SEENMRI_INDEX.forEach(function (e) {
                var t = e.t.toLowerCase();
                var sn = (e.s || '').toLowerCase();
                var s = 0;
                if (t.indexOf(q) !== -1) s += 5;
                toks.forEach(function (tok) {
                    if (stemHit(tok, t)) s += 1.5;
                    if (stemHit(tok, sn)) s += 0.5;
                });
                if (s > hs) { hs = s; hit = e; }
            });
            if (hit && hs >= 3) {
                return {
                    html: 'Here\u2019s what the platform has on that \u2014 <b>' + hit.t + '</b>' +
                          (hit.s ? ': ' + hit.s.split('. ').slice(0, 2).join('. ') + '.' : ''),
                    links: [['Open: ' + hit.t, hit.u]],
                    follow: ['Explain ' + hit.t.toLowerCase(), 'What is MRI?']
                };
            }
        }

        if (!isDomain(nq)) {
            return {
                html: 'I\u2019m a focused MRI tutor \u2696\ufe0f — my expertise is magnetic resonance: physics, sequences, parameters, cardiac MR, safety, artifacts and patient preparation. Ask me anything in the MRI domain and I\u2019ll give you my best answer!',
                follow: ['What is MRI?', 'Explain T1 vs T2', 'Safety zones?']
            };
        }

        return {
            html: 'Good question! I don\u2019t have a dedicated card for that yet — but the platform\u2019s search covers every page. Try the search (Ctrl + K), or rephrase with a key term like <b>FLAIR</b>, <b>TR</b>, <b>quench</b>, <b>SAR</b> or <b>k-space</b>.',
            links: [['Browse all topics', 'resources.html']],
            follow: ['What is FLAIR?', 'What does TR do?', 'ACR safety zones?']
        };
    }

    /* ============================================================
       CHAT UI
       ============================================================ */
    var fab = document.createElement('button');
    fab.id = 'aiFab';
    fab.setAttribute('aria-label', 'Open SEEN AI assistant');
    fab.innerHTML = '<i class="fas fa-robot"></i><span class="ai-fab-badge">AI</span>';
    document.body.appendChild(fab);

    var panel = document.createElement('div');
    panel.id = 'aiPanel';
    panel.innerHTML =
        '<div class="ai-head">' +
            '<div class="ai-avatar"><i class="fas fa-robot"></i></div>' +
            '<div class="ai-id"><strong>SEEN AI</strong><span><i class="fas fa-circle"></i> MRI Study Assistant — online</span></div>' +
            '<button class="ai-close" id="aiClose" aria-label="Close chat"><i class="fas fa-xmark"></i></button>' +
        '</div>' +
        '<div class="ai-messages" id="aiMessages"></div>' +
        '<div class="ai-chips" id="aiChips"></div>' +
        '<div class="ai-inputbar">' +
            '<input type="text" id="aiInput" placeholder="Ask anything MRI\u2026 e.g. what is FLAIR?" autocomplete="off">' +
            '<button id="aiSend" aria-label="Send"><i class="fas fa-paper-plane"></i></button>' +
        '</div>';
    document.body.appendChild(panel);

    var messages = $id('aiMessages');
    var chipsBox = $id('aiChips');
    var input = $id('aiInput');

    function scrollDown() { messages.scrollTop = messages.scrollHeight; }

    function addUser(text) {
        var el = document.createElement('div');
        el.className = 'ai-msg user';
        el.textContent = text;
        messages.appendChild(el);
        scrollDown();
    }

    function addAI(data) {
        var el = document.createElement('div');
        el.className = 'ai-msg bot';
        var body = document.createElement('div');
        body.className = 'ai-bubble';
        body.innerHTML = data.html;
        el.appendChild(body);

        if (data.links && data.links.length) {
            var linkRow = document.createElement('div');
            linkRow.className = 'ai-links';
            data.links.forEach(function (l) {
                var a = document.createElement('a');
                a.href = l[1];
                a.innerHTML = '<i class="fas fa-arrow-up-right-from-square"></i> ' + l[0];
                linkRow.appendChild(a);
            });
            el.appendChild(linkRow);
        }
        messages.appendChild(el);
        scrollDown();

        chipsBox.innerHTML = '';
        (data.follow || []).forEach(function (f) {
            var c = document.createElement('button');
            c.className = 'ai-chip';
            c.textContent = f;
            c.addEventListener('click', function () { send(f); });
            chipsBox.appendChild(c);
        });
    }

    function typing() {
        var el = document.createElement('div');
        el.className = 'ai-msg bot typing';
        el.innerHTML = '<div class="ai-bubble"><span class="dot"></span><span class="dot"></span><span class="dot"></span></div>';
        messages.appendChild(el);
        scrollDown();
        return el;
    }

    var busy = false;
    function send(text) {
        text = (text || input.value).trim();
        if (!text || busy) return;
        input.value = '';
        addUser(text);

        var tEl = typing();
        busy = true;
        var delay = 500 + Math.min(900, text.length * 12);
        setTimeout(function () {
            tEl.remove();
            addAI(bestAnswer(text));
            busy = false;
            input.focus();
        }, delay);
    }

    fab.addEventListener('click', function () {
        panel.classList.toggle('open');
        fab.classList.toggle('active', panel.classList.contains('open'));
        if (panel.classList.contains('open')) input.focus();
    });
    $id('aiClose').addEventListener('click', function () { panel.classList.remove('open'); fab.classList.remove('active'); });
    $id('aiSend').addEventListener('click', function () { send(); });
    input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); send(); }
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { panel.classList.remove('open'); fab.classList.remove('active'); }
    });

    /* welcome */
    addAI({
        html: 'Hello! I\u2019m <b>SEEN AI</b> \u2014 your MRI study assistant. \u269b\ufe0f<br>Ask me anything about MRI physics, sequences, parameters, cardiac MR, safety, artifacts or patient prep. I can even compute the <b>Larmor frequency</b> for you (try: \u201clarmor at 3T\u201d).',
        links: [['Explore the platform', 'index.html']],
        follow: ['What is MRI?', 'What is FLAIR?', 'What does TR do?', 'Larmor at 3T']
    });

})();
