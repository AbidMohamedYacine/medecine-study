/* ============================================================
   SEENmri — ThreeUI Fluid Field, themed + scroll-driven flow
   Geometry from MengTo/threeui Aura UI fluid (structure-flow).
   Colors follow each site theme:
     Dark   — blue #0077ff  +  teal #00d4aa
     Light  — platinum silver + ice-cyan core (near logo teal, not the same)
     Aurora — violet #8b5cf6 +  pink #ec4899
     Ocean  — sky #0ea5e9   +  aqua #2dd4bf

   Rest look: the original full-field Aura UI fluid.
   Scroll: the whole field travels down the page as one stack
   (no zoom-to-a-point). Each current recedes softly.
   Mouse: a local stir around the cursor — never a pinch.
   ============================================================ */
(function () {
    'use strict';

    var canvas = document.getElementById('fluidField');
    if (!canvas) return;

    var gl = canvas.getContext('webgl', { antialias: true, alpha: false, preserveDrawingBuffer: true });
    if (!gl) return;

    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var W, H, dpr;

    function resize() {
        dpr = Math.min(window.devicePixelRatio || 1, 2);
        W = window.innerWidth;
        H = window.innerHeight;
        canvas.width = W * dpr;
        canvas.height = H * dpr;
        canvas.style.width = W + 'px';
        canvas.style.height = H + 'px';
        gl.viewport(0, 0, canvas.width, canvas.height);
    }
    window.addEventListener('resize', resize);
    resize();

    var VS = [
        'attribute vec2 a_pos;',
        'void main(){ gl_Position = vec4(a_pos, 0.0, 1.0); }'
    ].join('\n');

    var FS = [
        'precision highp float;',
        'uniform vec2 u_res;',
        'uniform float u_time;',
        'uniform vec2 u_mouse;',
        'uniform vec3 u_primary;',
        'uniform vec3 u_secondary;',
        'uniform vec3 u_bg;',
        'uniform vec3 u_glow;',
        'uniform float u_light;',
        'uniform float u_scroll;',
        '',
        'vec2 mod289v2(vec2 x){ return x - floor(x * (1.0 / 289.0)) * 289.0; }',
        'vec3 mod289v3(vec3 x){ return x - floor(x * (1.0 / 289.0)) * 289.0; }',
        'vec3 permute(vec3 x){ return mod289v3(((x * 34.0) + 1.0) * x); }',
        '',
        'float snoise(vec2 v){',
        '    const vec4 C = vec4(0.211324865405187, 0.366025403784439, -0.577350269189626, 0.024390243902439);',
        '    vec2 i  = floor(v + dot(v, C.yy));',
        '    vec2 x0 = v - i + dot(i, C.xx);',
        '    vec2 i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);',
        '    vec4 x12 = x0.xyxy + C.xxzz;',
        '    x12.xy -= i1;',
        '    i = mod289v2(i);',
        '    vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0)) + i.x + vec3(0.0, i1.x, 1.0));',
        '    vec3 m = max(0.5 - vec3(dot(x0, x0), dot(x12.xy, x12.xy), dot(x12.zw, x12.zw)), 0.0);',
        '    m = m * m;',
        '    m = m * m;',
        '    vec3 x = 2.0 * fract(p * C.www) - 1.0;',
        '    vec3 h = abs(x) - 0.5;',
        '    vec3 ox = floor(x + 0.5);',
        '    vec3 a0 = x - ox;',
        '    m *= 1.79284291400159 - 0.85373472095314 * (a0 * a0 + h * h);',
        '    vec3 g;',
        '    g.x  = a0.x  * x0.x  + h.x  * x0.y;',
        '    g.yz = a0.yz * x12.xz + h.yz * x12.yw;',
        '    return 130.0 * dot(m, g);',
        '}',
        '',
        'float hash2(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }',
        '',
        'float smoother(float t){',
        '    t = clamp(t, 0.0, 1.0);',
        '    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);',
        '}',
        '',
        'float wave(float s, float a, float b){',
        '    return smoother((s - a) / max(b - a, 0.0001));',
        '}',
        '',
        'float flowBeam(vec2 st, float t, float speed, float tilt, float seed){',
        '    vec2 q = st;',
        '    q += vec2(',
        '        snoise(q + t * 0.038 + seed),',
        '        snoise(q - t * 0.038 + seed + 3.17)',
        '    ) * 0.30;',
        '    float n = snoise(vec2(q.x + q.y * tilt - t * speed, t * 0.015 + seed));',
        '    return smoothstep(-0.18, 0.52, n);',
        '}',
        '',
        'void main(){',
        '    vec2 uv = gl_FragCoord.xy / u_res;',
        '    float aspect = u_res.x / max(u_res.y, 1.0);',
        '    uv.x *= aspect;',
        '',
        '    float s = clamp(u_scroll, 0.0, 1.0);',
        '    float g = wave(s, 0.0, 1.0);',
        '',
        '    float l0 = wave(s, 0.40, 1.00);',
        '    float l1 = wave(s, 0.28, 0.88);',
        '    float l2 = wave(s, 0.16, 0.76);',
        '    float l3 = wave(s, 0.06, 0.64);',
        '    float l4 = wave(s, 0.00, 0.52);',
        '',
        '    vec2 mUv = vec2(u_mouse.x * aspect, u_mouse.y);',
        '    vec2 toM = uv - mUv;',
        '    float pocket = exp(-dot(toM, toM) * 8.5);',
        '    vec2 jitter = vec2(',
        '        snoise(uv * 2.6 + u_time * 0.16),',
        '        snoise(uv * 2.6 + 7.13 - u_time * 0.16)',
        '    ) * pocket * 0.05;',
        '',
        '    vec2 world = uv * 0.70;',
        '    world.y += g * 0.82;',
        '    world += jitter;',
        '',
        '    vec3 darkBase  = mix(u_bg, vec3(0.012, 0.012, 0.020), 0.55);',
        '    vec3 lightBase = mix(u_bg * 0.92, u_primary, 0.10);',
        '    vec3 col = mix(darkBase, lightBase, u_light);',
        '',
        '    vec3 glowA = mix(u_primary, u_glow, u_light * 0.55);',
        '    vec3 glowB = mix(u_secondary, u_glow, u_light * 0.72);',
        '    float hueN = snoise(uv * 1.5 + u_time * 0.082) * 0.5 + 0.5;',
        '    vec3 glow = mix(glowA, glowB, hueN);',
        '',
        '    float t = u_time;',
        '    float b4 = flowBeam(world + vec2(0.00, l4 * 0.22), t, 0.123, 1.50, 0.00);',
        '    float b3 = flowBeam(world * 0.86 + vec2(1.7, l3 * 0.28), t, 0.090, 1.15, 4.13);',
        '    float b2 = flowBeam(world * 1.12 + vec2(-1.4, l2 * 0.34), t, 0.156, 1.80, 8.27);',
        '    float b1 = flowBeam(world * 0.74 + vec2(2.6, l1 * 0.40), t, 0.074, 0.90, 12.4);',
        '    float b0 = flowBeam(world * 1.28 + vec2(-2.2, l0 * 0.46), t, 0.180, 2.10, 16.8);',
        '',
        '    float f4 = 1.0 - l4 * 0.42;',
        '    float f3 = 1.0 - l3 * 0.50;',
        '    float f2 = 1.0 - l2 * 0.55;',
        '    float f1 = 1.0 - l1 * 0.58;',
        '    float f0 = 1.0 - l0 * 0.62;',
        '',
        '    float restGain = mix(0.70, 0.58, u_light);',
        '    col += glow * b4 * restGain * f4;',
        '    col += mix(glow, glowB, 0.35) * b3 * 0.42 * mix(0.28, 1.0, max(l3, g * 0.35)) * f3;',
        '    col += mix(glow, glowA, 0.40) * b2 * 0.36 * mix(0.18, 1.0, max(l2, g * 0.28)) * f2;',
        '    col += mix(glowB, glowA, 0.50) * b1 * 0.30 * mix(0.12, 1.0, max(l1, g * 0.22)) * f1;',
        '    col += mix(glowA, glowB, 0.55) * b0 * 0.26 * mix(0.08, 1.0, max(l0, g * 0.16)) * f0;',
        '',
        '    float nx = uv.x / max(aspect, 0.001);',
        '    float coreY = 0.46 - g * 0.70;',
        '    float core = exp(-pow((nx - 0.5) * 1.05, 2.0)) * exp(-pow((uv.y - coreY) / 0.62, 2.0));',
        '    col += mix(u_secondary, u_glow, u_light) * core * mix(0.16, 0.22, u_light) * mix(1.0, 0.35, g);',
        '',
        '    float left = smoother(1.15 - (uv.y + g * 0.85));',
        '    col = mix(mix(darkBase, lightBase, u_light), col, mix(1.0, left, 0.85));',
        '',
        '    col += glow * pocket * mix(0.09, 0.06, u_light) * (0.35 + b4 * 0.65);',
        '',
        '    float grain = (hash2(gl_FragCoord.xy * 0.67 + t * 12.0) - 0.5) * mix(0.025, 0.018, u_light);',
        '    col += grain;',
        '',
        '    float vig = 1.0 - mix(0.28, 0.14, u_light) * pow(length((vec2(nx, uv.y) - 0.5) * vec2(1.1, 1.5)), 2.0);',
        '    col *= vig;',
        '',
        '    col = pow(max(col, vec3(0.0)), vec3(mix(0.96, 1.02, u_light)));',
        '    gl_FragColor = vec4(col, 1.0);',
        '}'
    ].join('\n');

    function createShader(src, type) {
        var sh = gl.createShader(type);
        gl.shaderSource(sh, src);
        gl.compileShader(sh);
        if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
            if (typeof console !== 'undefined' && console.warn) {
                console.warn('[fluid-field] shader', gl.getShaderInfoLog(sh));
            }
            return null;
        }
        return sh;
    }

    var vs = createShader(VS, gl.VERTEX_SHADER);
    var fs = createShader(FS, gl.FRAGMENT_SHADER);
    if (!vs || !fs) {
        canvas.style.opacity = '0';
        return;
    }

    var prog = gl.createProgram();
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
        if (typeof console !== 'undefined' && console.warn) {
            console.warn('[fluid-field] program', gl.getProgramInfoLog(prog));
        }
        canvas.style.opacity = '0';
        return;
    }
    gl.useProgram(prog);

    var quad = new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]);
    var buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, quad, gl.STATIC_DRAW);
    var aPos = gl.getAttribLocation(prog, 'a_pos');
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

    var uRes = gl.getUniformLocation(prog, 'u_res');
    var uTime = gl.getUniformLocation(prog, 'u_time');
    var uMouse = gl.getUniformLocation(prog, 'u_mouse');
    var uPrimary = gl.getUniformLocation(prog, 'u_primary');
    var uSecondary = gl.getUniformLocation(prog, 'u_secondary');
    var uBg = gl.getUniformLocation(prog, 'u_bg');
    var uGlow = gl.getUniformLocation(prog, 'u_glow');
    var uLight = gl.getUniformLocation(prog, 'u_light');
    var uScroll = gl.getUniformLocation(prog, 'u_scroll');

    function parseColor(css) {
        css = (css || '').trim();
        if (!css) return null;
        if (css.charAt(0) === '#') {
            var h = css.slice(1);
            if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
            if (h.length !== 6) return null;
            return [
                parseInt(h.slice(0, 2), 16) / 255,
                parseInt(h.slice(2, 4), 16) / 255,
                parseInt(h.slice(4, 6), 16) / 255
            ];
        }
        var m = css.match(/rgba?\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)/);
        if (m) return [Number(m[1]) / 255, Number(m[2]) / 255, Number(m[3]) / 255];
        return null;
    }

    var FALLBACK = {
        dark:   { p: [0.000, 0.467, 1.000], s: [0.000, 0.831, 0.667], b: [0.027, 0.043, 0.078], l: 0 },
        light:  { p: [0.863, 0.902, 0.941], s: [0.290, 0.333, 0.376], b: [0.604, 0.671, 0.753], l: 0.48, g: [0.271, 0.784, 0.863] },
        aurora: { p: [0.545, 0.361, 0.965], s: [0.925, 0.282, 0.600], b: [0.039, 0.027, 0.078], l: 0 },
        ocean:  { p: [0.055, 0.647, 0.914], s: [0.176, 0.831, 0.749], b: [0.012, 0.075, 0.125], l: 0 }
    };

    function themeId() {
        return document.documentElement.getAttribute('data-theme') || 'dark';
    }

    function readTarget() {
        var id = themeId();
        var fb = FALLBACK[id] || FALLBACK.dark;
        var p, s, b, l, g;
        if (id === 'light') {
            p = fb.p; s = fb.s; b = fb.b; l = fb.l;
            g = fb.g || [0.271, 0.784, 0.863];
        } else {
            var cs = getComputedStyle(document.documentElement);
            p = parseColor(cs.getPropertyValue('--blue')) || fb.p;
            s = parseColor(cs.getPropertyValue('--teal')) || fb.s;
            b = parseColor(cs.getPropertyValue('--bg')) || fb.b;
            l = 0;
            g = [p[0] * 0.72 + s[0] * 0.28, p[1] * 0.72 + s[1] * 0.28, p[2] * 0.72 + s[2] * 0.28];
        }
        return { p: p.slice(), s: s.slice(), b: b.slice(), l: l, g: g.slice() };
    }

    function copy3(a) { return [a[0], a[1], a[2]]; }
    function lerp(a, b, t) { return a + (b - a) * t; }
    function lerp3(a, b, t) { return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)]; }

    var tgt = readTarget();
    var cur = { p: copy3(tgt.p), s: copy3(tgt.s), b: copy3(tgt.b), l: tgt.l, g: copy3(tgt.g) };

    function pullTheme() {
        tgt = readTarget();
    }

    document.documentElement.addEventListener('seenmri-themechange', pullTheme);
    if (window.MutationObserver) {
        new MutationObserver(pullTheme).observe(document.documentElement, {
            attributes: true,
            attributeFilter: ['data-theme']
        });
    }

    var mx = 0.5, my = 0.5;
    var smx = 0.5, smy = 0.5;
    var mVelX = 0, mVelY = 0;
    var M_OMEGA = 11.0;
    var M_ZETA = 0.92;
    document.addEventListener('mousemove', function (e) {
        mx = e.clientX / window.innerWidth;
        my = 1.0 - e.clientY / window.innerHeight;
    });

    function readScroll() {
        var el = document.documentElement;
        var max = Math.max(1, (el.scrollHeight || 1) - window.innerHeight);
        var y = window.pageYOffset || el.scrollTop || 0;
        if (y < 0) y = 0;
        if (y > max) y = max;
        return y / max;
    }

    var OMEGA = 12.0;
    var ZETA = 0.88;
    var scrollTgt = 0;
    var scrollPos = 0;
    var scrollVel = 0;
    var lastTs = 0;

    window.addEventListener('scroll', function () {
        scrollTgt = readScroll();
    }, { passive: true });
    scrollTgt = readScroll();
    scrollPos = scrollTgt;

    var frozen = 0;
    function draw(ts) {
        var t = ts * 0.001;
        if (reduced) t = frozen || (frozen = t);

        var dt = lastTs ? Math.min(0.033, (ts - lastTs) * 0.001) : 0.016;
        lastTs = ts;

        scrollTgt = readScroll();
        if (reduced) {
            scrollPos = scrollTgt;
            scrollVel = 0;
        } else {
            var acc = -2.0 * ZETA * OMEGA * scrollVel - OMEGA * OMEGA * (scrollPos - scrollTgt);
            scrollVel += acc * dt;
            scrollPos += scrollVel * dt;
            if (scrollPos < -0.02) { scrollPos = -0.02; if (scrollVel < 0) scrollVel = 0; }
            if (scrollPos > 1.02)  { scrollPos =  1.02; if (scrollVel > 0) scrollVel = 0; }
        }

        if (reduced) {
            smx = mx; smy = my; mVelX = 0; mVelY = 0;
        } else {
            var ax = -2.0 * M_ZETA * M_OMEGA * mVelX - M_OMEGA * M_OMEGA * (smx - mx);
            var ay = -2.0 * M_ZETA * M_OMEGA * mVelY - M_OMEGA * M_OMEGA * (smy - my);
            mVelX += ax * dt;
            mVelY += ay * dt;
            smx += mVelX * dt;
            smy += mVelY * dt;
        }

        var k = 0.08;
        cur.p = lerp3(cur.p, tgt.p, k);
        cur.s = lerp3(cur.s, tgt.s, k);
        cur.b = lerp3(cur.b, tgt.b, k);
        cur.g = lerp3(cur.g, tgt.g, k);
        cur.l = lerp(cur.l, tgt.l, k);

        gl.uniform2f(uRes, canvas.width, canvas.height);
        gl.uniform1f(uTime, t);
        gl.uniform2f(uMouse, smx, smy);
        gl.uniform3f(uPrimary, cur.p[0], cur.p[1], cur.p[2]);
        gl.uniform3f(uSecondary, cur.s[0], cur.s[1], cur.s[2]);
        gl.uniform3f(uBg, cur.b[0], cur.b[1], cur.b[2]);
        gl.uniform3f(uGlow, cur.g[0], cur.g[1], cur.g[2]);
        gl.uniform1f(uLight, cur.l);
        gl.uniform1f(uScroll, scrollPos);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        if (!reduced) requestAnimationFrame(draw);
    }
    requestAnimationFrame(draw);
})();
