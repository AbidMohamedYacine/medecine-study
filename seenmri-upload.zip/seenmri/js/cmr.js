/* ============================================================
   SEENmri — cmr.js
   Cardiac MRI Masterclass engines:
   1) Cine Theater (ECG-synced pathology cases)
   2) First-pass perfusion animation
   3) LGE Pattern Studio
   4) AHA 17-segment interactive bullseye
   5) Transmurality scale
   ============================================================ */
(function () {
    'use strict';
    function $id(x) { return document.getElementById(x); }

    /* ---------- shared helpers ---------- */
    function mulberry32(a) {
        return function () {
            a |= 0; a = a + 0x6D2B79F5 | 0;
            var t = Math.imul(a ^ a >>> 15, 1 | a);
            t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
            return ((t ^ t >>> 14) >>> 0) / 4294967296;
        };
    }
    function organic(cx, cy, rx, ry, waves, amp, seed, n) {
        var r = mulberry32(seed), pts = [];
        n = n || 44;
        for (var i = 0; i < n; i++) {
            var th = (i / n) * Math.PI * 2;
            var w = Math.sin(th * waves + seed) * amp + (r() - 0.5) * amp * 1.2;
            pts.push([cx + Math.cos(th) * (rx + w), cy + Math.sin(th) * (ry + w)]);
        }
        return pts;
    }
    function poly(c, pts, W, H) {
        c.moveTo(pts[0][0] * W, pts[0][1] * H);
        for (var i = 1; i < pts.length; i++) c.lineTo(pts[i][0] * W, pts[i][1] * H);
        c.closePath();
    }
    function ell(c, cx, cy, rx, ry, rot, W, H) {
        c.beginPath();
        c.ellipse(cx * W, cy * H, rx * W, ry * H, rot || 0, 0, Math.PI * 2);
        c.fill();
    }
    function ring(c, cx, cy, rx, ry, rxIn, ryIn, seed, W, H, rot) {
        var o = organic(cx, cy, rx, ry, 5, 0.008, seed || 5, 52);
        var i2 = organic(cx, cy, rxIn, ryIn, 5, 0.006, (seed || 5) + 1, 52);
        c.beginPath();
        if (rot) { c.save(); c.translate(cx * W, cy * H); c.rotate(rot); c.translate(-cx * W, -cy * H); }
        poly(c, o, W, H); poly(c, i2, W, H);
        c.fill('evenodd');
        if (rot) c.restore();
    }
    function grain(c, W, H, alpha) {
        c.globalAlpha = alpha || 0.05;
        for (var i = 0; i < (W * H) / 260; i++) {
            var v = Math.random() < 0.5 ? 255 : 0;
            c.fillStyle = 'rgb(' + v + ',' + v + ',' + v + ')';
            c.fillRect(Math.random() * W, Math.random() * H, 1.2, 1.2);
        }
        c.globalAlpha = 1;
    }
    function vignette(c, W, H) {
        var g = c.createRadialGradient(W / 2, H / 2, H * 0.2, W / 2, H / 2, H * 0.75);
        g.addColorStop(0, 'rgba(0,0,0,0)');
        g.addColorStop(1, 'rgba(0,0,0,0.34)');
        c.fillStyle = g;
        c.fillRect(0, 0, W, H);
    }
    function gray(v) { var g = Math.round(v * 255); return 'rgb(' + g + ',' + g + ',' + g + ')'; }

    /* ============================================================
       1) CINE THEATER
       ============================================================ */
    (function cineTheater() {
        var cv = $id('cineCanvas');
        if (!cv) return;
        var c = cv.getContext('2d');
        var W = cv.width, H = cv.height;

        /* bSSFP-like contrast */
        var T = { air: 0.04, lung: 0.30, fat: 0.87, muscle: 0.44, myo: 0.44, blood: 0.96, liver: 0.52, spleen: 0.47, scar: 0.5, bone: 0.15 };

        var CASES = {
            normal: { label: 'Normal — 4 Chamber', img: 'images/cmr-cases/normal4ch.jpg', cap: 'Simulated CMR illustration — normal four-chamber anatomy', title: 'Normal Heart',
                text: 'Balanced chambers, vigorous symmetric contraction. Atria fill while ventricles empty — the AV plane descends in systole.',
                findings: ['LV/RV size and function normal', 'Myocardium uniform — no LGE', 'No valve lesions'] },
            hcm: { label: 'Hypertrophic CM', img: 'images/cmr-cases/hcm.jpg', cap: 'Simulated CMR illustration — thickened septum, crescent LV cavity', title: 'Hypertrophic Cardiomyopathy',
                text: 'Marked septal hypertrophy squeezes the LV cavity into a crescent. Watch the LVOT — systolic anterior motion of the mitral leaflet causes obstruction and the classic dagger jet.',
                findings: ['Septum ≥15 mm (septal:lateral >1.3)', 'LVOT obstruction + SAM in systole', 'Mid-wall LGE at RV insertion points', 'Crypts may mark gene carriers'] },
            dcm: { label: 'Dilated CM', img: 'images/cmr-cases/dcm.jpg', cap: 'Real clinical image — dilated cardiomyopathy (Wikimedia Commons, CC0)', title: 'Dilated Cardiomyopathy',
                text: 'A spherical, thin-walled LV that barely changes volume between diastole and systole — global hypokinesis with poor contractile reserve.',
                findings: ['Dilated LV + thin walls, EF <40%', 'Mid-wall (often inferoseptal) LGE', 'No LGE in most patients → use T1/ECV', 'Exclude coronary disease (ischaemic DCM)'] },
            tako: { label: 'Takotsubo', img: 'images/cmr-cases/takotsubo.jpg', cap: 'Simulated CMR illustration — apical ballooning in systole', title: 'Tako-Tsubo (Stress) Cardiomyopathy',
                text: 'Post-menopausal woman after emotional stress: the BASE contracts fiercely while the APEX BALLOONS outward in systole — the octopus-trap morphology. Oedema on T2, but no LGE.',
                findings: ['Apical akinesia / ballooning', 'Basal hyperkinesis', 'T2 oedema, no LGE', 'Full recovery within weeks'] },
            arvc: { label: 'ARVC', img: 'images/cmr-cases/arvc.jpg', cap: 'Real clinical image — ARVC (Wikimedia Commons, CC BY 2.0)', title: 'Arrhythmogenic RV Cardiomyopathy',
                text: 'The RV dilates with a dyskinetic bulge of the free wall that paradoxically EXPANDS in systole. Fibro-fatty replacement shows as RV free-wall LGE.',
                findings: ['RV dilatation + regional dyskinesia', 'RVEDVi ≥110 mL/m² (M) / ≥100 (F) or RVEF ≤40%', 'RV free-wall LGE (beware pseudo-enhancement)', '2010 Task Force criteria — never imaging alone'] }
        };

        function drawHeart(caseKey, f) {
            /* f: 1 = end-diastole … ~0.6 = end-systole */
            var syst = 1 - f;
            c.fillStyle = '#000';
            c.fillRect(0, 0, W, H);

            /* thorax */
            c.fillStyle = gray(T.lung);
            c.beginPath(); poly(c, organic(0.22, 0.45, 0.17, 0.30, 5, 0.014, 41), W, H); c.fill();
            c.beginPath(); poly(c, organic(0.80, 0.45, 0.16, 0.28, 5, 0.014, 42), W, H); c.fill();
            c.fillStyle = gray(T.fat);
            c.beginPath(); poly(c, organic(0.5, 0.5, 0.46, 0.48, 3, 0.012, 43), W, H); c.fill();
            c.fillStyle = gray(T.liver); ell(c, 0.78, 0.84, 0.16, 0.14, 0, W, H);
            c.fillStyle = gray(T.spleen); ell(c, 0.20, 0.82, 0.10, 0.10, 0, W, H);
            /* spine + aorta */
            c.fillStyle = gray(T.bone); ell(c, 0.245, 0.665, 0.043, 0.048, 0, W, H);
            c.fillStyle = gray(T.muscle); ell(c, 0.245, 0.665, 0.034, 0.039, 0, W, H);
            c.fillStyle = gray(T.blood); ell(c, 0.315, 0.655, 0.024, 0.026, 0, W, H);

            var aScale = 1 + 0.24 * syst;
            var aShift = 0.022 * syst;
            var lax = 0.475, lay = 0.30 - aShift, rax = 0.615, ray = 0.31 - aShift;

            if (caseKey === 'arvc') {
                /* the LV is present and contracts — with subtle lateral wall involvement */
                var lvS = 0.58 + 0.42 * f;
                c.fillStyle = gray(T.myo);
                ring(c, 0.42, 0.60, 0.095 * lvS + 0.042, 0.168 * lvS + 0.036, 0.095 * lvS, 0.168 * lvS, 93, W, H, 0.30);
                c.fillStyle = gray(T.blood);
                ell(c, 0.42, 0.60, 0.095 * lvS, 0.168 * lvS, 0.30, W, H);
                c.fillStyle = gray(0.55); /* LV lateral fibrotic streak */
                ell(c, 0.345, 0.63, 0.016, 0.05, -0.2, W, H);
                /* dilated dyskinetic RV with aneurysm */
                var rvD = 1.3;
                c.fillStyle = gray(T.myo);
                ring(c, 0.63, 0.60, 0.135 * rvD, 0.20 * rvD, 0.118 * rvD, 0.185 * rvD, 91, W, H, -0.18);
                c.fillStyle = gray(T.blood);
                ell(c, 0.63, 0.60, 0.115 * rvD, 0.182 * rvD, -0.18, W, H);
                /* aneurysm bulge grows in systole (dyskinesia) */
                c.fillStyle = gray(T.blood);
                ell(c, 0.78, 0.68, 0.032 + 0.030 * syst, 0.030 + 0.030 * syst, -0.3, W, H);
                c.fillStyle = gray(T.myo);
                ell(c, 0.795, 0.695, 0.014, 0.014, 0, W, H); /* fibrotic patch */
            } else {
                var vScale;
                if (caseKey === 'dcm') vScale = 0.86 + 0.14 * f;      /* barely contracts */
                else vScale = 0.58 + 0.42 * f;
                var cav = caseKey === 'dcm' ? 1.28 : 1;
                var wall = caseKey === 'dcm' ? 0.024 : 0.042;
                c.fillStyle = gray(T.myo);
                ring(c, 0.62, 0.615, 0.088 * vScale * cav + 0.03, 0.155 * vScale * cav + 0.028, 0.088 * vScale * cav, 0.155 * vScale * cav, 92, W, H, -0.18);
                c.fillStyle = gray(T.blood);
                ell(c, 0.62, 0.615, 0.088 * vScale * cav, 0.155 * vScale * cav, -0.18, W, H);
                /* LV */
                c.fillStyle = gray(T.myo);
                ring(c, 0.44, 0.60, 0.095 * vScale * cav + wall, 0.168 * vScale * cav + wall - 0.004, 0.095 * vScale * cav, 0.168 * vScale * cav, 93, W, H, 0.30);
                if (caseKey === 'hcm') {
                    /* bulging septum into LV */
                    c.fillStyle = gray(T.myo);
                    c.beginPath();
                    poly(c, [[0.50, 0.44], [0.56, 0.46], [0.545, 0.60], [0.545, 0.72], [0.49, 0.72], [0.485, 0.58]].map(function (p) { return [p[0] * (1 - 0.06 * syst) + 0.03 * syst, p[1]]; }), W, H);
                    c.fill();
                }
                if (caseKey === 'tako') {
                    /* apical balloon: cavity extends into apex during systole */
                    var bal = 0.055 + 0.075 * syst;
                    c.fillStyle = gray(T.blood);
                    ell(c, 0.462, 0.755, bal * 1.15, bal, 0.3, W, H);
                    c.fillStyle = gray(T.myo);
                    ring(c, 0.462, 0.755, bal * 1.15 + 0.022, bal + 0.020, bal * 1.15, bal, 94, W, H, 0.3);
                    c.fillStyle = gray(T.blood);
                    ell(c, 0.462, 0.755, bal * 1.15, bal, 0.3, W, H);
                }
                /* LV cavity */
                c.fillStyle = gray(T.blood);
                if (caseKey === 'hcm') {
                    /* crescent cavity (septum pushes) */
                    c.beginPath();
                    var pts = [];
                    for (var a = 0; a <= 28; a++) {
                        var th = -1.25 + (a / 28) * 2 * Math.PI * 0.92;
                        var rr = 0.093 * vScale * (1 - 0.28 * Math.max(0, Math.cos(th)));
                        pts.push([0.44 + Math.cos(th) * rr * 0.62 - 0.02, 0.60 + Math.sin(th) * rr * 1.05]);
                    }
                    poly(c, pts, W, H); c.fill();
                } else {
                    ell(c, 0.44, 0.60, 0.095 * vScale * cav, 0.168 * vScale * cav, 0.30, W, H);
                }
            }
            /* atria */
            c.fillStyle = gray(T.myo);
            ring(c, lax, lay, 0.085 * aScale + 0.016, 0.088 * aScale + 0.014, 0.078 * aScale, 0.080 * aScale, 95, W, H, 0.18);
            c.fillStyle = gray(T.blood);
            ell(c, lax, lay, 0.078 * aScale, 0.080 * aScale, 0.18, W, H);
            c.fillStyle = gray(T.myo);
            ring(c, rax, ray, 0.080 * aScale + 0.014, 0.082 * aScale + 0.012, 0.072 * aScale, 0.075 * aScale, 96, W, H, -0.12);
            c.fillStyle = gray(T.blood);
            ell(c, rax, ray, 0.072 * aScale, 0.075 * aScale, -0.12, W, H);
            /* septum */
            c.fillStyle = gray(T.myo);
            c.beginPath(); poly(c, [[0.52, 0.36], [0.545, 0.36], [0.545, 0.72], [0.52, 0.72]], W, H); c.fill();

            grain(c, W, H, 0.045);
            vignette(c, W, H);
        }

        /* ECG strip */
        var ecgCv = $id('cineEcg');
        var ecgC = ecgCv ? ecgCv.getContext('2d') : null;
        var EW = ecgCv ? ecgCv.width : 0, EH = ecgCv ? ecgCv.height : 0;
        function drawEcg(phase) {
            if (!ecgC) return;
            ecgC.fillStyle = '#02060d'; ecgC.fillRect(0, 0, EW, EH);
            ecgC.strokeStyle = '#34d399'; ecgC.lineWidth = 1.5;
            ecgC.beginPath();
            for (var x = 0; x < EW; x++) {
                var p = (x / EW + (1 - phase)) % 1;
                var g = 0.16 * Math.exp(-Math.pow((p - 0.82) * 14, 2))
                      - 0.08 * Math.exp(-Math.pow((p - 0.10) * 30, 2))
                      - 1.00 * Math.exp(-Math.pow((p - 0.13) * 16, 2))
                      + 0.22 * Math.exp(-Math.pow((p - 0.16) * 20, 2))
                      + 0.26 * Math.exp(-Math.pow((p - 0.40) * 8, 2));
                var y = EH * 0.64 - g * EH * 0.5;
                x ? ecgC.lineTo(x, y) : ecgC.moveTo(x, y);
            }
            ecgC.stroke();
            ecgC.fillStyle = 'rgba(52,211,153,0.85)';
            ecgC.fillRect(((1 - phase) % 1) * EW, 0, 1.5, EH);
        }

        /* state */
        var phase = 0, playing = true, caseKey = 'normal', lastT = null;
        var HR = 68;

        function setCase(k) {
            caseKey = k;
            $id('cineCaseLabel').textContent = CASES[k].label;
            $id('cineInfoTitle').textContent = CASES[k].title;
            $id('cineInfoText').textContent = CASES[k].text;
            $id('cineFindings').innerHTML = '<h4><i class="fas fa-clipboard-list"></i> Key findings</h4><ul>' +
                CASES[k].findings.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>';
            document.querySelectorAll('.cine-case-btn').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-case') === k); });
            if (CASES[k].img) {
                $id('cineRealImg').src = CASES[k].img;
                $id('cineRealCap').textContent = CASES[k].cap;
            }
        }

        var bar = $id('cineCaseBar');
        Object.keys(CASES).forEach(function (k) {
            var b = document.createElement('button');
            b.className = 'cine-case-btn';
            b.setAttribute('data-case', k);
            b.textContent = CASES[k].label.split('—')[0].trim();
            b.addEventListener('click', function () { setCase(k); });
            bar.appendChild(b);
        });

        $id('cinePlayBtn').addEventListener('click', function () {
            playing = !playing;
            this.innerHTML = playing ? '<i class="fas fa-pause"></i> Pause' : '<i class="fas fa-play"></i> Play';
        });
        $id('cineScrub').addEventListener('input', function () {
            phase = (parseInt(this.value, 10) / 24);
            drawFrame(performance.now(), true);
        });

        function drawFrame(ts, force) {
            if (lastT === null) lastT = ts;
            var dt = (ts - lastT) / 1000; lastT = ts;
            if (playing && !force) phase = (phase + dt * (HR / 60)) % 1;

            var f = 0.60 + 0.40 * (0.5 + 0.5 * Math.cos(phase * Math.PI * 2));
            drawHeart(caseKey, f);
            drawEcg(phase);
            var ph = Math.floor(phase * 25) + 1;
            $id('cinePhaseTxt').textContent = 'Phase ' + ph + '/25';
            $id('cinePhaseTag').textContent = (phase > 0.25 && phase < 0.55) ? 'ES — Systole' : 'ED — Diastole';
            if (playing && !force) $id('cineScrub').value = String(Math.floor(phase * 24));
            requestAnimationFrame(drawFrame);
        }
        setCase('normal');
        requestAnimationFrame(drawFrame);
    })();

    /* ============================================================
       2) FIRST-PASS PERFUSION
       ============================================================ */
    (function perfusion() {
        var cv = $id('perfCanvas');
        if (!cv) return;
        var c = cv.getContext('2d');
        var W = cv.width, H = cv.height;
        var t0 = performance.now(), LOOP = 10;   /* seconds */

        function lvCurve(t) { return Math.max(0, Math.exp(-Math.pow((t - 2.4) * 1.4, 2))); }
        function rvCurve(t) { return Math.max(0, Math.exp(-Math.pow((t - 1.1) * 1.5, 2))); }
        function myoCurve(t) { return Math.max(0, 0.9 / (1 + Math.exp(-(t - 3.4) * 1.8))) * Math.exp(-Math.max(0, t - 6.5) * 0.8); }

        function draw(t) {
            c.fillStyle = '#000'; c.fillRect(0, 0, W, H);
            var baseMyo = 0.34, baseBlood = 0.42;
            var rv = rvCurve(t), lv = lvCurve(t), myo = myoCurve(t);

            /* LV myocardium ring */
            var defect = myo * 0.9;      /* normal beds blush; defect stays near zero */
            function myoVal(ang) {
                /* LAD territory: angles -1.0..0.9 rad (upper/anterior) */
                var inLad = (ang > -1.1 && ang < 0.95);
                var v = baseMyo + (inLad ? defect * 0.06 : myo * 0.34);
                /* dark rim artifact at early LV phase */
                var rim = lv * 0.5 * Math.exp(-Math.pow((t - 2.9) * 2.2, 2));
                var endo = 1 - Math.abs(ang) * 0.0;  /* full ring */
                v -= rim * 0.30;
                return Math.max(0.05, Math.min(1, v));
            }
            /* draw ring as radial segments */
            var cx = 0.5, cy = 0.5, Ro = 0.30, Ri = 0.185;
            for (var a = 0; a < 64; a++) {
                var a0 = (a / 64) * Math.PI * 2, a1 = ((a + 1.001) / 64) * Math.PI * 2;
                var mid = (a0 + a1) / 2;
                c.fillStyle = gray(myoVal(mid));
                c.beginPath();
                c.arc(cx * W, cy * H, Ro * H, a0, a1); c.arc(cx * W, cy * H, Ri * H, a1, a0, true);
                c.closePath(); c.fill();
            }
            /* RV crescent */
            c.fillStyle = gray(baseBlood * 0.75 + rv * 0.55);
            c.beginPath();
            c.ellipse(0.755 * W, 0.58 * H, 0.085 * H, 0.15 * H, -0.2, 0, Math.PI * 2);
            c.fill();
            c.fillStyle = gray(0.30);
            c.beginPath();
            c.ellipse(0.755 * W, 0.58 * H, 0.11 * H, 0.175 * H, -0.2, 0, Math.PI * 2);
            c.strokeStyle = gray(0.30); c.lineWidth = 0.02 * H; c.stroke();
            /* LV cavity */
            c.fillStyle = gray(baseBlood + lv * 0.58);
            ell(c, cx, cy, 0.165, 0.165, 0, W, H);
            /* papillary hints */
            c.fillStyle = gray(baseMyo * 0.9);
            ell(c, 0.46, 0.56, 0.03, 0.035, 0, W, H);
            ell(c, 0.55, 0.545, 0.028, 0.033, 0, W, H);

            grain(c, W, H, 0.06);
            vignette(c, W, H);

            /* label */
            var el = $id('perfPhaseTag');
            if (t < 0.9) el.textContent = 'Injecting… bolus in arm veins';
            else if (t < 1.9) el.textContent = 'RV phase — bolus enters right heart';
            else if (t < 2.9) el.textContent = 'LV phase — cavity spikes (dark rim moment!)';
            else if (t < 4.4) el.textContent = 'Myocardial first pass — LAD defect stays dark';
            else if (t < 6.5) el.textContent = 'Myocardial blush — note the LAD territory';
            else el.textContent = 'Wash-out — rest study + LGE to follow';
        }

        function loop(ts) {
            var t = ((ts - t0) / 1000) % LOOP;
            draw(t);
            requestAnimationFrame(loop);
        }
        requestAnimationFrame(loop);
        $id('perfPlayBtn').addEventListener('click', function () { t0 = performance.now(); });
    })();

    /* ============================================================
       3) LGE PATTERN STUDIO
       ============================================================ */
    (function lgeStudio() {
        var cv = $id('lgeCanvas');
        if (!cv) return;
        var c = cv.getContext('2d');
        var W = cv.width, H = cv.height;

        var PATTERNS = [
            { key: 'subendo', label: 'Subendocardial infarct', img: 'images/cmr-cases/lgeexample.jpg', kind: 'REAL CLINICAL IMAGE', cap: 'Real clinical image — 4CH IR infarct (Wikimedia Commons, CC BY-SA 4.0)', dx: 'Ischaemic — subendocardial',
              text: 'Bright rim confined to the inner <50% of wall in a coronary territory — subendocardial infarction. Viable if ≤25–50%: recovery after revascularisation is likely.',
              list: ['Non-Q / partially reperfused MI', 'Ischaemic cardiomyopathy (often multiterritory)', 'Transmurality drives the revascularisation decision'] },
            { key: 'transmural', label: 'Transmural infarct', img: 'images/cmr-cases/lge-trans.jpg', kind: 'SIMULATED ILLUSTRATION', cap: 'CMR-style illustration — full-thickness anterior scar', dx: 'Ischaemic — transmural',
              text: 'Full-thickness enhancement in a coronary bed — chronic occlusion, non-viable myocardium. Thin, akinetic wall on cine (aneurysmal if dyskinetic).',
              list: ['Chronic total occlusion / old MI', '>75% transmurality → recovery unlikely', 'Thrombus risk over transmural scar (check EGE)'] },
            { key: 'mvo', label: 'Infarct + MVO', img: 'images/cmr-cases/lge-mvo.jpg', kind: 'SIMULATED ILLUSTRATION', cap: 'CMR-style illustration — bright infarct with dark no-reflow core', dx: 'Ischaemic — microvascular obstruction',
              text: 'Bright infarct with a DARK CORE — the “no reflow” pattern of an acute, reperfused STEMI. Contrast cannot enter the obstructed microvasculature.',
              list: ['Acute reperfused STEMI', 'High-risk feature: adverse remodelling, arrhythmias', 'Best seen on EGE / early post-Gd imaging'] },
            { key: 'midwall', label: 'Mid-wall (septal)', img: 'images/cmr-cases/lge-midwall.jpg', kind: 'SIMULATED ILLUSTRATION', cap: 'CMR-style illustration — inferoseptal mid-wall streak (DCM)', dx: 'Non-ischaemic — mid-wall',
              text: 'Mid-layer enhancement SPARING the subendocardium — never a coronary pattern. Classic for dilated cardiomyopathy (inferoseptal) and RV-insertion fibrosis.',
              list: ['DCM — mid-wall inferoseptal fibrosis', 'HCM — RV insertion points (non-specific)', 'Sarcoidosis — spotty, basal, patchy'] },
            { key: 'subepi', label: 'Subepicardial (lateral)', img: 'images/cmr-cases/myocarditis.jpg', kind: 'REAL CLINICAL IMAGE', cap: 'Real clinical image — myocarditis (Wikimedia Commons, CC BY-SA 3.0)', dx: 'Non-ischaemic — subepicardial',
              text: 'Outer-rim enhancement, typically inferolateral — the signature of myocarditis and the dystrophinopathies; Fabry shows mid-wall inferolateral LGE with LOW native T1.',
              list: ['Myocarditis (inferolateral subepicardial)', 'Becker/Duchenne muscular dystrophy', 'Anderson-Fabry (mid-wall + low T1)', 'Scleroderma / Churg-Strauss (rare)'] },
            { key: 'global', label: 'Global subendocardial', img: 'images/cmr-cases/amyloid.jpg', kind: 'REAL CLINICAL IMAGE', cap: 'Real clinical image — amyloid deposition (Wikimedia Commons, CC BY 4.0)', dx: 'Infiltrative — amyloidosis',
              text: 'Diffuse circumferential subendocardial enhancement with myocardium that REFUSES to null and blood pool that darkens early — cardiac amyloidosis until proven otherwise.',
              list: ['AL / ATTR amyloidosis (QALE score to separate)', 'Native T1 >1050 ms · ECV >0.40', 'Look-Locker: blood & myocardium null together', 'Atrial septum >6 mm, effusions common'] }
        ];

        function arcBand(a0, a1, rIn, rOut, fill) {
            c.fillStyle = fill;
            c.beginPath();
            c.arc(0.5 * W, 0.5 * H, rOut * H, a0, a1);
            c.arc(0.5 * W, 0.5 * H, rIn * H, a1, a0, true);
            c.closePath(); c.fill();
        }

        function draw(key) {
            c.fillStyle = '#000'; c.fillRect(0, 0, W, H);
            var myo = 0.15, blood = 0.30, scar = 0.97, dark = 0.06;
            var Ro = 0.30, Rmid = 0.245, Rse = 0.205, Ri = 0.165;

            /* myocardium (nulled dark) */
            c.fillStyle = gray(myo);
            c.beginPath(); poly(c, organic(0.5, 0.5, 0.315, 0.315, 5, 0.008, 11), W, H); c.fill();
            /* blood pool */
            c.fillStyle = gray(blood);
            c.beginPath(); poly(c, organic(0.5, 0.5, 0.16, 0.16, 5, 0.006, 12), W, H); c.fill();

            /* territory angles: 0 rad = 12 o'clock (anterior), clockwise */
            var A0 = -Math.PI / 2;
            function ang(deg) { return A0 + deg * Math.PI / 180; }

            if (key === 'subendo') {
                arcBand(ang(-40), ang(80), Ri, Rse + 0.012, gray(scar));            /* LAD: A + AS */
            } else if (key === 'transmural') {
                arcBand(ang(-40), ang(80), Ri, Ro - 0.004, gray(scar));
            } else if (key === 'mvo') {
                arcBand(ang(-40), ang(80), Ri, Ro - 0.004, gray(scar));
                arcBand(ang(-18), ang(58), Ri - 0.004, Rse - 0.012, gray(dark));    /* dark core */
            } else if (key === 'midwall') {
                arcBand(ang(20), ang(140), Rse, Rmid + 0.01, gray(scar));           /* IS/IL mid-wall */
                arcBand(ang(300), ang(348), Rmid, Rmid + 0.022, gray(0.55));        /* RV insertion hint */
            } else if (key === 'subepi') {
                arcBand(ang(110), ang(240), Rmid + 0.008, Ro - 0.002, gray(scar));  /* inferolateral subepi */
            } else if (key === 'global') {
                arcBand(0, Math.PI * 2, Ri, Rse + 0.012, gray(scar * 0.92));        /* circumferential subendo */
                c.fillStyle = gray(0.22);                                            /* dark blood pool */
                c.beginPath(); poly(c, organic(0.5, 0.5, 0.155, 0.155, 5, 0.006, 12), W, H); c.fill();
            }
            /* RV crescent (myo) */
            c.fillStyle = gray(myo * 0.9);
            c.beginPath();
            c.ellipse(0.795 * W, 0.575 * H, 0.075 * H, 0.125 * H, -0.25, 0, Math.PI * 2);
            c.fill();
            c.fillStyle = gray(blood);
            c.beginPath();
            c.ellipse(0.795 * W, 0.575 * H, 0.055 * H, 0.10 * H, -0.25, 0, Math.PI * 2);
            c.fill();

            grain(c, W, H, 0.05);
            vignette(c, W, H);
        }

        var btns = $id('lgeBtns');
        PATTERNS.forEach(function (p) {
            var b = document.createElement('button');
            b.className = 'lge-btn';
            b.textContent = p.label;
            b.addEventListener('click', function () { select(p); });
            btns.appendChild(b);
        });
        function select(p) {
            draw(p.key);
            $id('lgeLabel').textContent = p.label;
            if (p.img) {
                $id('lgeRealImg').src = p.img;
                $id('lgeRealKind').textContent = p.kind;
                $id('lgeRealKind').style.color = p.kind.indexOf('REAL') === 0 ? '#4ade80' : '#fbbf24';
                $id('lgeRealCap').textContent = p.cap;
            }
            $id('lgeDxTitle').textContent = p.dx;
            $id('lgeDxText').textContent = p.text;
            $id('lgeDxList').innerHTML = p.list.map(function (x) { return '<li><i class="fas fa-angle-right"></i> ' + x + '</li>'; }).join('');
            document.querySelectorAll('.lge-btn').forEach(function (b) { b.classList.toggle('active', b.textContent === p.label); });
        }
        select(PATTERNS[0]);
    })();

    /* ============================================================
       4) AHA 17-SEGMENT BULLSEYE
       ============================================================ */
    (function bullseye() {
        var svg = $id('bullseye');
        if (!svg) return;
        var NS = 'http://www.w3.org/2000/svg';

        /* segment definitions: ring index (0=basal..3=apex center), start angle deg (clockwise from top), span, name, territory */
        var NAMES = ['A', 'AS', 'IS', 'I', 'IL', 'AL'];
        var SEG = [];
        var ringDef = [
            { r0: 74, r1: 100, count: 6, base: 1,  names: NAMES },
            { r0: 48, r1: 74, count: 6, base: 7, names: NAMES },
            { r0: 24, r1: 48, count: 4, base: 13, names: ['A', 'S', 'I', 'L'] }
        ];
        var TERR = {
            1: 'LAD', 2: 'LAD', 3: 'RCA', 4: 'RCA', 5: 'CX', 6: 'LAD/CX',
            7: 'LAD', 8: 'LAD', 9: 'RCA', 10: 'RCA', 11: 'CX', 12: 'LAD/CX',
            13: 'LAD', 14: 'LAD', 15: 'RCA/LAD', 16: 'CX/LAD',
            17: 'LAD'
        };
        var COLORS = { LAD: '#3b82f6', CX: '#f59e0b', RCA: '#ef4444' };
        function terrColor(t) {
            if (t === 'LAD') return COLORS.LAD;
            if (t === 'CX') return COLORS.CX;
            if (t === 'RCA') return COLORS.RCA;
            return '#a78bfa';
        }
        var DESC = {
            'LAD': 'Left anterior descending — the anterior wall, septum and apex.',
            'RCA': 'Right coronary artery — the inferior wall and inferoseptum.',
            'CX': 'Circumflex — the lateral wall.',
            'LAD/CX': 'Overlap zone of LAD and circumflex (anterolateral).',
            'RCA/LAD': 'Overlap zone of RCA and LAD at the apical inferior wall.',
            'CX/LAD': 'Overlap zone of circumflex and LAD (apical lateral).'
        };

        ringDef.forEach(function (rd) {
            var span = 360 / rd.count;
            for (var i = 0; i < rd.count; i++) {
                var a0 = -90 + i * span, a1 = a0 + span;
                SEG.push({ n: rd.base + i, r0: rd.r0, r1: rd.r1, a0: a0, a1: a1,
                           name: rd.names[i], terr: TERR[rd.base + i] });
            }
        });
        SEG.push({ n: 17, r0: 0, r1: 24, circle: true, name: 'Apex', terr: 'LAD' });

        function pol(cx, cy, r, deg) {
            var a = deg * Math.PI / 180;
            return [cx + r * Math.cos(a), cy + r * Math.sin(a)];
        }
        var CXa = 150, CYa = 150;

        SEG.forEach(function (s) {
            var el = document.createElementNS(NS, 'path');
            var d;
            if (s.circle) {
                d = 'M ' + (CXa + s.r1) + ' ' + CYa + ' A ' + s.r1 + ' ' + s.r1 + ' 0 1 0 ' + (CXa - s.r1) + ' ' + CYa +
                    ' A ' + s.r1 + ' ' + s.r1 + ' 0 1 0 ' + (CXa + s.r1) + ' ' + CYa + ' Z';
            } else {
                var p1 = pol(CXa, CYa, s.r1, s.a0), p2 = pol(CXa, CYa, s.r1, s.a1);
                var p3 = pol(CXa, CYa, s.r0, s.a1), p4 = pol(CXa, CYa, s.r0, s.a0);
                d = 'M ' + p1[0] + ' ' + p1[1] + ' A ' + s.r1 + ' ' + s.r1 + ' 0 0 1 ' + p2[0] + ' ' + p2[1] +
                    ' L ' + p3[0] + ' ' + p3[1] + ' A ' + s.r0 + ' ' + s.r0 + ' 0 0 0 ' + p4[0] + ' ' + p4[1] + ' Z';
            }
            el.setAttribute('d', d);
            el.setAttribute('fill', terrColor(s.terr));
            el.setAttribute('fill-opacity', '0.32');
            el.setAttribute('stroke', 'rgba(10,16,30,0.9)');
            el.setAttribute('stroke-width', '1.6');
            el.style.cursor = 'pointer';
            el.classList.add('seg-path');
            el.addEventListener('mouseenter', function () {
                el.setAttribute('fill-opacity', '0.75');
                $id('segTitle').textContent = 'Segment ' + s.n + ' — ' + (s.n <= 12 ? (s.n <= 6 ? 'Basal ' : 'Mid ') : s.n <= 16 ? 'Apical ' : '') + full(s.name);
                $id('segTerritory').innerHTML = '<i class="fas fa-droplet"></i> Territory: <b>' + s.terr + '</b>';
                $id('segDesc').textContent = DESC[s.terr];
            });
            el.addEventListener('mouseleave', function () { el.setAttribute('fill-opacity', '0.32'); });
            el.addEventListener('click', function () {
                document.querySelectorAll('.seg-path').forEach(function (x) { x.setAttribute('stroke', 'rgba(10,16,30,0.9)'); x.setAttribute('stroke-width', '1.6'); });
                el.setAttribute('stroke', '#fff');
                el.setAttribute('stroke-width', '2.6');
            });
            svg.appendChild(el);
        });
        function full(n) {
            return { A: 'Anterior', AS: 'Anteroseptal', IS: 'Inferoseptal', I: 'Inferior', IL: 'Inferolateral', AL: 'Anterolateral', S: 'Septal', L: 'Lateral', Apex: 'Apex' }[n] || n;
        }
        /* ring labels */
        [['Basal', 100], ['Mid', 74], ['Apical', 48]].forEach(function (rl) {
            var t = document.createElementNS(NS, 'text');
            t.setAttribute('x', 150); t.setAttribute('y', 150 - rl[1] + 12);
            t.setAttribute('text-anchor', 'middle');
            t.setAttribute('font-size', '9.5');
            t.setAttribute('fill', 'rgba(255,255,255,0.75)');
            t.setAttribute('font-family', 'Space Grotesk, sans-serif');
            t.textContent = rl[0];
            svg.appendChild(t);
        });
    })();

    /* ============================================================
       5) TRANSMURALITY SCALE
       ============================================================ */
    (function tmScale() {
        var wrap = $id('transmuralScale');
        if (!wrap) return;
        [0, 25, 50, 75, 100].forEach(function (pct) {
            var item = document.createElement('div');
            item.className = 'tm-step';
            var cv = document.createElement('canvas');
            cv.width = 84; cv.height = 84;
            var c = cv.getContext('2d');
            c.fillStyle = '#0b1322'; c.fillRect(0, 0, 84, 84);
            var myo = 0.30, Ro = 34, Ri = 20;
            c.fillStyle = 'rgb(' + Math.round(myo * 255) + ',' + Math.round(myo * 255) + ',' + Math.round(myo * 255) + ')';
            c.beginPath(); c.arc(42, 42, Ro, 0, Math.PI * 2); c.fill();
            c.fillStyle = '#0b1322';
            c.beginPath(); c.arc(42, 42, Ri, 0, Math.PI * 2); c.fill();
            var frac = pct / 100;
            var cutR = Ri + (Ro - Ri) * frac;
            if (pct > 0) {
                c.fillStyle = '#f8fafc';
                c.beginPath();
                c.arc(42, 42, Ro - 1, -Math.PI / 2 - 1.05, -Math.PI / 2 + 1.05);
                c.arc(42, 42, cutR, -Math.PI / 2 + 1.05, -Math.PI / 2 - 1.05, true);
                c.closePath(); c.fill();
            }
            c.fillStyle = 'rgba(240,244,255,0.85)';
            c.font = '700 11px Space Grotesk, sans-serif';
            c.textAlign = 'center';
            c.fillText(pct + '%', 42, 78);
            item.appendChild(cv);
            item.appendChild(document.createTextNode(pct === 0 ? 'Micro' : ''));
            wrap.appendChild(item);
        });
    })();

})();
