/* ============================================================
   SEENmri — advisor.js
   Interactive Protocol Advisor (body-parts page)
   ============================================================ */
(function () {
    'use strict';

    function $(id) { return document.getElementById(id); }

    /* ============================================================
       PROTOCOL KNOWLEDGE BASE
       ============================================================ */
    var REGIONS = [
        { id: 'brain',    label: 'Brain / Neuro',   icon: 'fa-brain' },
        { id: 'spine',    label: 'Spine',           icon: 'fa-bone' },
        { id: 'msk',      label: 'Knee / MSK',      icon: 'fa-running' },
        { id: 'cardiac',  label: 'Heart',           icon: 'fa-heart' },
        { id: 'abdomen',  label: 'Liver / MRCP',    icon: 'fa-circle-notch' }
    ];

    var PROTOCOLS = {
        brain: [
            { id: 'stroke', label: 'Acute stroke (sudden deficit)', time: '≈ 10 min', contrast: false,
              sub: 'Hyperacute cerebral ischemia work-up',
              seq: [
                ['DWI b=1000 + ADC', 'Restricted diffusion detects infarct core within minutes — the fastest confirmatory sequence in stroke.'],
                ['FLAIR', 'Old vs new: shows chronic changes and excludes mimics; DWI–FLAIR mismatch suggests wake-up stroke thrombolysis candidates.'],
                ['T2* GRE / SWI', 'Detects hemorrhage instantly — an absolute contraindication to thrombolysis if positive.'],
                ['3D TOF MRA circle of Willis', 'Non-contrast angiogram: locates the vessel occlusion or stenosis driving the event.']
              ] },
            { id: 'ms', label: 'Demyelination / MS follow-up', time: '≈ 25 min', contrast: true,
              sub: 'McDonald criteria — lesion detection and activity',
              seq: [
                ['Sagittal 3D FLAIR', 'Best sequence for periventricular, juxtacortical and infratentorial plaques (corpus callosum “fingers”).'],
                ['Axial T2 / PD', 'Classic lesion count and anatomical localisation complementary to FLAIR.'],
                ['T1 pre + post gadolinium', 'Enhancing plaques = active disease; ring/open-ring enhancement typical of MS.'],
                ['Sagittal cervical spine T2', 'McDonald criteria allow spinal lesions to count — always image the cord in suspected MS.']
              ] },
            { id: 'tumor', label: 'Tumor / metastases follow-up', time: '≈ 30 min', contrast: true,
              sub: 'Characterization and treatment response',
              seq: [
                ['T1 pre-contrast', 'Baseline: fat, blood products, and possible hemorrhage within the mass.'],
                ['T1 post-contrast (3D MPRAGE)', 'Blood–brain barrier disruption enhances — defines active tumor margins.'],
                ['T2 / FLAIR', 'Peritumoral edema and non-enhancing tumor extent.'],
                ['DWI + perfusion (DSC)', 'Diffusion/restriction and rCBV help grade gliomas and distinguish recurrence from pseudoprogression.']
              ] },
            { id: 'epilepsy', label: 'Epilepsy / temporal lobe work-up', time: '≈ 25 min', contrast: false,
              sub: 'Focus detection — mesial temporal sclerosis, malformations',
              seq: [
                ['Coronal T2 + FLAIR (thin, temporal)', 'The sequence for mesial temporal sclerosis: small bright hippocampus with enlarged horn.'],
                ['3D T1 MPRAGE isotropic', 'Cortical malformations (FCD), heterotopia — needs sub-millimeter resolution.'],
                ['T2* GRE / SWI', 'Calcifications and post-traumatic changes.'],
                ['T1 post-contrast (if indicated)', 'Only if a mass or vascular lesion is suspected on the non-contrast set.']
              ] }
        ],

        spine: [
            { id: 'radicular', label: 'Low back pain radiating to leg', time: '≈ 20 min', contrast: false,
              sub: 'Disc herniation and nerve root compression (lumbar)',
              seq: [
                ['Sagittal T2 FSE', 'The “myelogram” view — disc height, hydration, extrusion, canal caliber.'],
                ['Sagittal T1', 'Marrow fat vs water: fracture dating, tumor infiltration.'],
                ['Axial T2 through levels', 'Foraminal stenosis and the exact root being pinched — matches the dermatome.'],
                ['Sagittal STIR', 'Fat-suppressed fluid sensitivity: edema, infection or tumor screening.']
              ] },
            { id: 'infection', label: 'Suspected discitis / epidural abscess', time: '≈ 25 min', contrast: true,
              sub: 'Infectious spondylodiscitis work-up',
              seq: [
                ['Sagittal + axial STIR/T2', 'Disc and adjacent endplate edema — the first sign of discitis.'],
                ['Sagittal T1', 'Destruction of endplate cortex; hypointense marrow.'],
                ['T1 post-contrast fatsat', 'Rim-enhancing abscess, epidural spread, phlegmon — defines surgical extent.'],
                ['Whole-spine screening STIR', 'Skip lesions: 10% have multilevel involvement.']
              ] },
            { id: 'myelopathy', label: 'Cervical myelopathy (arms + gait)', time: '≈ 22 min', contrast: false,
              sub: 'Cord compression and signal change (cervical)',
              seq: [
                ['Sagittal T2', 'Canal stenosis, cord compression and T2 hyperintensity in the cord (myelomalacia).'],
                ['Sagittal T1', 'Marrow and alignment; ossified posterior longitudinal ligament.'],
                ['Axial T2 / GRE across stenosis', 'Transverse cord area — predicts outcome; GRE shows osteophytes without flow artifact.'],
                ['Sagittal STIR', 'Compressive edema vs static myelopathy.']
              ] }
        ],

        msk: [
            { id: 'locking', label: 'Twisting injury, locked knee', time: '≈ 25 min', contrast: false,
              sub: 'Internal derangement — meniscus and ligaments',
              seq: [
                ['Sagittal PD fat-sat', 'Meniscal tears: the workhorse — high-resolution fluid-sensitive detail.'],
                ['Coronal PD fat-sat', 'Collateral ligaments, meniscal roots and the popliteal hiatus.'],
                ['Sagittal T2', 'ACL integrity (Blumensaat angle), effusion, Baker cyst.'],
                ['Axial fat-sat PD/FSE', 'Patellofemoral cartilage and retinacula; extensor mechanism.']
              ] },
            { id: 'occult', label: 'Pain, negative X-ray (occult fracture)', time: '≈ 20 min', contrast: false,
              sub: 'Bone bruise / stress fracture — after sports injury',
              seq: [
                ['Sagittal + coronal STIR', 'Marrow edema shines: occult fractures, bone stress, microtrabecular injury.'],
                ['T1 (both planes)', 'Fracture line = dark linear line inside edema; confirms true fracture vs bruise.'],
                ['PD fat-sat', 'Adjacent cartilage and ligament injury accompanying the trauma.'],
                ['3D T1 GRE (optional)', 'Mapping for surgical planning if displaced.']
              ] }
        ],

        cardiac: [
            { id: 'viability', label: 'Old infarct, heart failure (viability)', time: '≈ 40 min', contrast: true,
              sub: 'Myocardial scar and function — revascularization decision',
              seq: [
                ['Cine bSSFP SAX stack + long axes', 'Volumes, EF, regional wall motion — the functional foundation.'],
                ['Late gadolinium enhancement (PSIR)', 'Scar transmurality: < 50% bright = likely recovery after revascularization.'],
                ['T2 STIR (if acute)', 'Edema = salvageable myocardium at risk (area at risk / infarct size).'],
                ['Optional: dobutamine cine', 'Contractile reserve in borderline viability cases.']
              ] },
            { id: 'myocarditis', label: 'Suspected myocarditis / chest pain, clean coronaries', time: '≈ 35 min', contrast: true,
              sub: 'Inflammation — Lake Louise criteria',
              seq: [
                ['T2-weighted STIR / T2 mapping', 'Global or focal edema — active inflammation.'],
                ['T1 + ECV mapping', 'Interstitial expansion: diffuse fibrosis or inflammation signature.'],
                ['LGE', 'Typic patterns: subepicardial / mid-wall (vs subendocardial infarct).'],
                ['Cine bSSFP', 'Wall motion and functional consequences (reduced EF, ballooning).']
              ] },
            { id: 'iron', label: 'Anemia / thalassemia (iron overload)', time: '≈ 15 min', contrast: false,
              sub: 'Myocardial iron quantification — T2*',
              seq: [
                ['Multi-echo T2* mapping (short axis)', 'T2* < 20 ms = iron overload — chelation threshold. Directly guides therapy.'],
                ['Cine bSSFP', 'Iron cardiomyopathy: EF trend over years.'],
                ['Liver T2*/R2 (same visit)', 'Total body iron burden alongside cardiac measurement.']
              ] }
        ],

        abdomen: [
            { id: 'liver', label: 'Liver lesion characterization', time: '≈ 30 min', contrast: true,
              sub: 'Focal liver lesion — benign vs malignant',
              seq: [
                ['T2 FSE + single-shot', 'Cysts and hemangiomas stay bright on longer TE; metastasis fades.'],
                ['In/opposed-phase GRE', 'Fatty infiltration vs adrenal adenoma (signal dropout).'],
                ['DWI + ADC', 'Restriction favors malignancy over benign lesions.'],
                ['Dynamic T1 post-Gd (arterial/portal/equilibrium)', 'HCC hypervascular washout, hemangioma peripheral nodular fill-in — the decisive set.']
              ] },
            { id: 'mrcp', label: 'Biliary colic / jaundice (MRCP)', time: '≈ 20 min', contrast: false,
              sub: 'Bile ducts and pancreas — stone vs stricture',
              seq: [
                ['3D heavy-T2 MRCP (respiratory gated)', 'Ductal anatomy in one breath-hold-quality volume: stones, strictures, dilatation.'],
                ['2D single-shot thick-slab MRCP', 'Rapid functional views in different angles — mobility of stones.'],
                ['Axial T2 FSE', 'Pancreatic parenchyma and periductal context.'],
                ['T1 post-Gd LAVA (if mass suspected)', 'Only if laboratory/imaging suggests a tumor rather than stone disease.']
              ] }
        ]
    };

    var state = { region: null, protocol: null };

    /* ============================================================
       RENDER STEP 1
       ============================================================ */
    function renderRegions() {
        var wrap = $('advRegions');
        wrap.innerHTML = '';
        REGIONS.forEach(function (r) {
            var chip = document.createElement('button');
            chip.className = 'adv-chip' + (state.region === r.id ? ' active' : '');
            chip.innerHTML = '<i class="fas ' + r.icon + '"></i> ' + r.label;
            chip.addEventListener('click', function () {
                state.region = r.id;
                state.protocol = null;
                renderRegions();
                renderPresentations();
                $('advStep2').classList.remove('locked');
                $('advStep3').classList.add('locked');
                $('advResult').style.display = 'none';
            });
            wrap.appendChild(chip);
        });
    }

    /* ============================================================
       RENDER STEP 2
       ============================================================ */
    function renderPresentations() {
        var wrap = $('advPresentations');
        wrap.innerHTML = '';
        if (!state.region) return;
        (PROTOCOLS[state.region] || []).forEach(function (p) {
            var chip = document.createElement('button');
            chip.className = 'adv-chip' + (state.protocol && state.protocol.id === p.id ? ' active' : '');
            chip.textContent = p.label;
            chip.addEventListener('click', function () {
                state.protocol = p;
                renderPresentations();
                $('advStep3').classList.remove('locked');
                $('advResult').style.display = 'none';
                $('advStep3').scrollIntoView({ behavior: 'smooth', block: 'center' });
            });
            wrap.appendChild(chip);
        });
    }

    /* ============================================================
       GENERATE RESULT
       ============================================================ */
    $('advGenerate').addEventListener('click', function () {
        if (!state.region || !state.protocol) return;

        var renal = $('fct-renal').checked;
        var preg = $('fct-preg').checked;
        var claustro = $('fct-claustro').checked;
        var implant = $('fct-implant').checked;
        var needsGd = state.protocol.contrast;
        var gdRemoved = needsGd && (renal || preg);

        /* head */
        var regionLabel = REGIONS.find(function (r) { return r.id === state.region; }).label;
        $('advResultTag').textContent = regionLabel.toUpperCase() + ' PROTOCOL';
        $('advResultTitle').textContent = state.protocol.label;
        $('advResultSub').textContent = state.protocol.sub;
        $('advTime').textContent = gdRemoved ? state.protocol.time + ' (shorter)' : state.protocol.time;

        var contrastTxt, contrastIcon = $('advContrastIcon');
        if (!needsGd) { contrastTxt = 'No contrast'; contrastIcon.style.color = 'var(--green)'; }
        else if (gdRemoved) { contrastTxt = 'Contrast CANCELLED'; contrastIcon.style.color = 'var(--red)'; }
        else { contrastTxt = 'With gadolinium'; contrastIcon.style.color = 'var(--blue)'; }
        $('advContrast').textContent = contrastTxt;

        /* sequences */
        var list = $('advSequences');
        list.innerHTML = '';
        var seqs = state.protocol.seq;
        if (gdRemoved) {
            seqs = seqs.filter(function (s) { return !/contrast|gadolinium|LGE|post-Gd|PSIR/i.test(s[0]); });
        }
        seqs.forEach(function (s, i) {
            var item = document.createElement('div');
            item.className = 'adv-seq-item';
            item.style.setProperty('--d', (i * 0.08) + 's');
            item.innerHTML =
                '<span class="adv-seq-num">' + (i + 1) + '</span>' +
                '<div><h4>' + s[0] + '</h4><p>' + s[1] + '</p></div>';
            list.appendChild(item);
        });
        if (gdRemoved) {
            var note = document.createElement('div');
            note.className = 'adv-seq-item adv-seq-note';
            note.innerHTML = '<span class="adv-seq-num"><i class="fas fa-ban"></i></span>' +
                '<div><h4>Gadolinium sequences withheld</h4><p>Renal impairment / pregnancy — contrast arm removed from the protocol (see warnings below).</p></div>';
            list.appendChild(note);
        }

        /* warnings */
        var warn = $('advWarnings');
        warn.innerHTML = '';
        function addWarn(level, icon, title, text) {
            var el = document.createElement('div');
            el.className = 'adv-warn ' + level;
            el.innerHTML = '<i class="fas ' + icon + '"></i><div><strong>' + title + '</strong> ' + text + '</div>';
            warn.appendChild(el);
        }
        if (renal && needsGd) {
            addWarn('danger', 'fa-droplet', 'Severe renal impairment:', 'eGFR &lt; 30 → NSF risk. Cancel the gadolinium order or obtain radiologist approval for a macrocyclic group II agent after risk–benefit discussion.');
        } else if (renal) {
            addWarn('caution', 'fa-droplet', 'Renal impairment noted:', 'Protocol is non-contrast — no NSF risk. Document eGFR in the record.');
        }
        if (preg) {
            addWarn(needsGd ? 'danger' : 'caution', 'fa-baby', 'Pregnancy:', 'Proceed only if the benefit outweighs risk (non-contrast MRI has no known adverse effects). Gadolinium is avoided unless life-critical.');
        }
        if (claustro) {
            addWarn('caution', 'fa-head-side-mask', 'Claustrophobia / restlessness:', 'Explain the bore, offer prism glasses + music + buzzer. Consider shortened protocol, and pre-medication or sedation per departmental policy.');
        }
        if (implant) {
            addWarn('danger', 'fa-magnet', 'Implant / metal history:', 'STOP at Zone II: full screening, device card, MR-conditional verification (mrisafety.com / manufacturer) BEFORE approaching the magnet. If unverified ferromagnetic aneurysm clip or pacemaker — scan contraindicated.');
        }
        if (!renal && !preg && !claustro && !implant) {
            addWarn('ok', 'fa-check-circle', 'No special factors:', 'Standard safety screening and preparation apply.');
        }

        $('advResult').style.display = '';
        $('advResult').scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    /* restart */
    $('advRestart').addEventListener('click', function () {
        state.region = null;
        state.protocol = null;
        ['fct-renal', 'fct-preg', 'fct-claustro', 'fct-implant'].forEach(function (id) { $(id).checked = false; });
        $('advResult').style.display = 'none';
        $('advStep2').classList.add('locked');
        $('advStep3').classList.add('locked');
        renderRegions();
        renderPresentations();
        window.scrollTo({ top: document.getElementById('protocol-advisor').offsetTop - 80, behavior: 'smooth' });
    });

    /* init */
    renderRegions();
    renderPresentations();
})();
