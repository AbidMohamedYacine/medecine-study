/* ============================================================
   SEENmri — main.js
   Shared behaviours: navigation, scroll-reveal, counters,
   home demo widgets, back-to-top, dynamic footer year.
   ============================================================ */
(function () {
    'use strict';

    var prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* ============================================================
       THEME SYSTEM — dark · light · aurora · ocean
       ============================================================ */
    var THEME_KEY = 'seenmri-theme';
    var htmlEl = document.documentElement;
    var savedTheme = 'dark';
    try { savedTheme = localStorage.getItem(THEME_KEY) || 'dark'; } catch (e) {}

    var THEMES = [
        { id: 'dark',   icon: 'fa-moon',               label: 'Dark' },
        { id: 'light',  icon: 'fa-sun',                label: 'Light' },
        { id: 'aurora', icon: 'fa-wand-magic-sparkles', label: 'Aurora' },
        { id: 'ocean',  icon: 'fa-water',              label: 'Ocean' }
    ];

    function setTheme(t) {
        if (t === 'dark') htmlEl.removeAttribute('data-theme');
        else htmlEl.setAttribute('data-theme', t);
        try { localStorage.setItem(THEME_KEY, t); } catch (e) {}
        var def = THEMES.filter(function (x) { return x.id === t; })[0] || THEMES[0];
        var btn = document.getElementById('themeToggle');
        if (btn) {
            btn.innerHTML = '<i class="fas ' + def.icon + '"></i>';
            btn.title = 'Theme: ' + def.label + ' — click to change';
            btn.setAttribute('aria-label', btn.title);
        }
        try {
            htmlEl.dispatchEvent(new CustomEvent('seenmri-themechange', { detail: { theme: t } }));
        } catch (e) {}
    }

    function cycleTheme() {
        var cur = htmlEl.getAttribute('data-theme') || 'dark';
        var idx = THEMES.map(function (x) { return x.id; }).indexOf(cur);
        setTheme(THEMES[(idx + 1) % THEMES.length].id);
    }

    /* ============================================================
       PRELOADER (loading screen)
       ============================================================ */
    var preloader = document.createElement('div');
    preloader.id = 'preloader';
    preloader.setAttribute('aria-hidden', 'true');
    preloader.innerHTML =
        '<div class="pre-inner">' +
            '<div class="pre-logo"><img src="images/logo.svg" class="pre-logo-icon" alt=""><span class="logo-seen">SEEN</span><span class="logo-mri">mri</span></div>' +
            '<div class="pre-bar"><div class="pre-fill"></div></div>' +
            '<div class="pre-tip">Preparing your MRI learning experience…</div>' +
        '</div>';
    document.body.appendChild(preloader);

    function hidePreloader() {
        if (!preloader.parentNode) return;
        preloader.classList.add('done');
        setTimeout(function () { if (preloader.parentNode) preloader.parentNode.removeChild(preloader); }, 700);
    }
    if (document.readyState === 'complete') {
        setTimeout(hidePreloader, 350);
    } else {
        window.addEventListener('load', function () { setTimeout(hidePreloader, 300); });
    }
    /* safety: never keep the loader longer than 2.5 s */
    setTimeout(hidePreloader, 2500);

    /* attention pulse on the hero CTA once the curtain lifts */
    setTimeout(function () {
        var cta = document.querySelector('.btn-hero-ring');
        if (!cta) return;
        cta.classList.add('attn');
        setTimeout(function () { cta.classList.remove('attn'); }, 2200);
    }, 2900);

    /* ============================================================
       SCROLL PROGRESS BAR
       ============================================================ */
    var scrollProgress = document.createElement('div');
    scrollProgress.id = 'scrollProgress';
    document.body.appendChild(scrollProgress);

    function updateScrollProgress() {
        var doc = document.documentElement;
        var max = doc.scrollHeight - window.innerHeight;
        var pct = max > 0 ? (window.scrollY / max) * 100 : 0;
        scrollProgress.style.width = pct + '%';
    }

    /* ---------------- NAVBAR ---------------- */
    var navbar = document.getElementById('navbar');

    function onScrollNav() {
        if (!navbar) return;
        var shrink = window.scrollY > 30;
        navbar.classList.toggle('scrolled', shrink);
        document.documentElement.classList.toggle('nav-scrolled', shrink);
        if (backToTop) backToTop.classList.toggle('visible', window.scrollY > 600);
        updateScrollProgress();
    }

    /* Theme toggle button (inside the navbar) */
    var navContainer = document.querySelector('.nav-container');
    if (navContainer) {
        var themeBtn = document.createElement('button');
        themeBtn.id = 'themeToggle';
        themeBtn.className = 'theme-toggle';
        themeBtn.innerHTML = '<i class="fas fa-sun"></i>';
        themeBtn.title = 'Switch to light mode';
        var navToggleEl = document.getElementById('navToggle');
        if (navToggleEl) navContainer.insertBefore(themeBtn, navToggleEl);
        else navContainer.appendChild(themeBtn);
        themeBtn.addEventListener('click', function () {
            cycleTheme();
            if (window.toast) {
                setTimeout(function () {
                    var names = { dark: 'Dark', light: 'Light', aurora: 'Aurora', ocean: 'Ocean' };
                    var cur = document.documentElement.getAttribute('data-theme') || 'dark';
                    window.toast(names[cur] + ' theme', cur === 'dark' ? 'info' : 'brand');
                }, 0);
            }
        });
    }

    /* Apply saved theme now (button icon syncs too) */
    setTheme(savedTheme);

    /* Mobile toggle */
    var navToggle = document.getElementById('navToggle');
    var navMenu = document.getElementById('navMenu');

    if (navToggle && navMenu) {
        navToggle.addEventListener('click', function () {
            var open = navMenu.classList.toggle('open');
            navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            navToggle.innerHTML = open
                ? '<i class="fas fa-xmark"></i>'
                : '<i class="fas fa-bars"></i>';
        });

        /* Dropdowns / mega menu — click toggles on ANY viewport.
           FIX: desktop clicks on href="#" used to run the default anchor
           behaviour and JUMP TO TOP instead of opening the menu. */
        document.addEventListener('click', function (e) {
            document.querySelectorAll('.nav-item.dropdown.open, .nav-item.mega-item.open').forEach(function (li) {
                if (!li.contains(e.target)) li.classList.remove('open');
            });
        });
        document.querySelectorAll('.nav-item.dropdown > .nav-link, .nav-item.mega-item > .nav-link').forEach(function (link) {
            link.addEventListener('click', function (e) {
                e.preventDefault();                       /* never jump to top */
                var li = link.parentElement;
                var wasOpen = li.classList.contains('open');
                document.querySelectorAll('.nav-item.dropdown.open, .nav-item.mega-item.open').forEach(function (o) {
                    o.classList.remove('open');
                });
                li.classList.toggle('open', !wasOpen);
            });
        });

        /* Close menu after navigating (mobile) */
        navMenu.querySelectorAll('a').forEach(function (a) {
            a.addEventListener('click', function () {
                navMenu.classList.remove('open');
                navToggle.innerHTML = '<i class="fas fa-bars"></i>';
            });
        });
    }

    /* ---------------- BACK TO TOP ---------------- */
    var backToTop = document.createElement('button');
    backToTop.id = 'backToTop';
    backToTop.setAttribute('aria-label', 'Back to top');
    backToTop.innerHTML = '<i class="fas fa-arrow-up"></i>';
    document.body.appendChild(backToTop);
    backToTop.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
    });

    window.addEventListener('scroll', onScrollNav, { passive: true });
    onScrollNav();

    /* ---------------- FOOTER YEAR ---------------- */
    document.querySelectorAll('.footer-bottom p').forEach(function (p) {
        p.textContent = p.textContent.replace('2024', String(new Date().getFullYear()));
    });

    /* ============================================================
       SCROLL REVEAL SYSTEM
       Auto-tags key content blocks, then reveals them with a
       staggered IntersectionObserver as they enter the viewport.
       ============================================================ */
    var REVEAL_SELECTORS = [
        '.section-header',
        '.card', '.info-card', '.step-card', '.zone-card', '.glossary-card',
        '.param-card-detail', '.astm-card', '.book-card', '.axis-card',
        '.comparison-card', '.challenge-card', '.hazard-card', '.case-card',
        '.concept-box', '.content-card-box', '.component-block', '.calc-box',
        '.contra-box', '.dwi-card', '.step', '.demo-box', '.quiz-box',
        '.clinical-case-card', '.highlight-box', '.table-wrap',
        '.quiz-container-card', '.glossary-search-container',
        '.kspace-lab', '.ks-lesson-cards > *', '.decay-lab',
        '.figure-card', '.artifact-card', '.ab-studio', '.credits-box',
        '.section-figure',
        '.prep-workflow-grid > *', '.prep-step-card', '.screener-box',
        '.cardiac-protocol-grid > *', '.cardiac-challenge-grid > *',
        '.checklist-grid > *', '.hazards-grid > *', '.books-grid > *',
        '.glossary-grid > *', '.concept-steps > *'
    ];

    if (!prefersReducedMotion && 'IntersectionObserver' in window) {
        var seen = new Set();
        var targets = [];

        REVEAL_SELECTORS.forEach(function (sel) {
            document.querySelectorAll(sel).forEach(function (el) {
                if (seen.has(el) || el.closest('.navbar')) return;
                seen.add(el);
                targets.push(el);
            });
        });

        /* Stagger siblings that share the same parent */
        var parentCounts = new Map();
        targets.forEach(function (el) {
            var parent = el.parentElement;
            var n = parentCounts.get(parent) || 0;
            if (n < 8) el.style.setProperty('--reveal-delay', (n * 0.08).toFixed(2) + 's');
            parentCounts.set(parent, n + 1);
            el.setAttribute('data-reveal', '');
            el.classList.add('pre-reveal'); /* no-op hook for debug */
        });

        var revealObserver = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    revealObserver.unobserve(entry.target);
                    /* hand transitions back to hover styles once revealed */
                    setTimeout(function (el) {
                        el.removeAttribute('data-reveal');
                        el.style.removeProperty('--reveal-delay');
                        el.classList.remove('pre-reveal');
                    }.bind(null, entry.target), 1400);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

        targets.forEach(function (el) { revealObserver.observe(el); });
    }

    /* ============================================================
       ANIMATED COUNTERS (hero stats: 10+, 100+, 5+ ...)
       ============================================================ */
    function animateCounter(el) {
        var raw = el.getAttribute('data-count');
        if (raw === null) return;
        var target = parseInt(raw, 10);
        if (isNaN(target)) return;
        var suffix = el.getAttribute('data-suffix') || '';
        var duration = 1500;
        var start = null;

        function frame(ts) {
            if (!start) start = ts;
            var p = Math.min((ts - start) / duration, 1);
            var eased = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.round(target * eased) + suffix;
            if (p < 1) requestAnimationFrame(frame);
        }
        requestAnimationFrame(frame);
    }

    var counterEls = document.querySelectorAll('.stat-number');
    counterEls.forEach(function (el) {
        var m = el.textContent.match(/^(\d+)\s*(\+)?$/);
        if (!m) return;
        el.setAttribute('data-count', m[1]);
        el.setAttribute('data-suffix', m[2] || '');
        el.textContent = '0' + (m[2] || '');
    });

    if (counterEls.length && !prefersReducedMotion && 'IntersectionObserver' in window) {
        var counterObserver = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    animateCounter(entry.target);
                    counterObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.4 });
        counterEls.forEach(function (el) { counterObserver.observe(el); });
    } else {
        counterEls.forEach(function (el) {
            var m = el.getAttribute('data-count');
            if (m !== null) el.textContent = m + (el.getAttribute('data-suffix') || '');
        });
    }

    /* ============================================================
       HOME PAGE — hero demo widgets
       ============================================================ */

    /* Quick quiz box */
    window.homeQuiz = function (btn, isCorrect) {
        var box = document.getElementById('quizOpts');
        var result = document.getElementById('quizResult');
        if (!box || !result) return;

        var buttons = Array.prototype.slice.call(box.querySelectorAll('.quiz-btn'));
        buttons.forEach(function (b) { b.disabled = true; });

        btn.classList.add(isCorrect ? 'correct' : 'wrong');
        if (!isCorrect) {
            buttons.forEach(function (b) {
                if (b.getAttribute('onclick') && b.getAttribute('onclick').indexOf('true') !== -1) {
                    b.classList.add('correct');
                }
            });
        }

        result.className = 'quiz-result ' + (isCorrect ? 'correct' : 'wrong');
        result.innerHTML = isCorrect
            ? '<i class="fas fa-check-circle"></i> Correct! TR = Repetition Time — the time between RF pulses.'
            : '<i class="fas fa-times-circle"></i> Not quite — TR stands for Repetition Time, the interval between successive RF pulses.';
    };

    /* TR/TE weighting demo */
    var demoTR = document.getElementById('demoTR');
    var demoTE = document.getElementById('demoTE');

    function signalWord(v) {
        if (v >= 70) return 'Bright';
        if (v >= 40) return 'Medium';
        return 'Dark';
    }

    function updateDemo() {
        if (!demoTR || !demoTE) return;
        var tr = parseInt(demoTR.value, 10);
        var te = parseInt(demoTE.value, 10);

        document.getElementById('trVal').textContent = tr + ' ms';
        document.getElementById('teVal').textContent = te + ' ms';

        var type, desc, tissues;

        if (tr <= 800 && te <= 35) {
            type = 'T1-Weighted';
            desc = 'Short TR + Short TE = T1 Weighting';
            tissues = { fat: 90, water: 15, gm: 45, wm: 70, muscle: 40 };
        } else if (tr >= 2000 && te >= 60) {
            type = 'T2-Weighted';
            desc = 'Long TR + Long TE = T2 Weighting';
            tissues = { fat: 60, water: 95, gm: 38, wm: 30, muscle: 32 };
        } else if (tr >= 1600 && te <= 35) {
            type = 'PD-Weighted';
            desc = 'Long TR + Short TE = Proton Density';
            tissues = { fat: 75, water: 82, gm: 66, wm: 62, muscle: 55 };
        } else {
            type = 'Mixed Weighting';
            desc = 'Intermediate TR/TE — contrast falls between weightings';
            tissues = { fat: 72, water: 55, gm: 52, wm: 55, muscle: 46 };
        }

        document.getElementById('resultType').textContent = type;
        document.getElementById('resultDesc').textContent = desc;

        ['fat', 'water', 'gm', 'wm', 'muscle'].forEach(function (t) {
            var v = tissues[t];
            var bar = document.getElementById(t + 'Bar');
            var word = document.getElementById(t + 'Word');
            if (bar) bar.style.width = v + '%';
            if (word) word.textContent = signalWord(v);
        });
    }

    if (demoTR && demoTE) {
        demoTR.addEventListener('input', updateDemo);
        demoTE.addEventListener('input', updateDemo);
        updateDemo();
    }

})();

/* ============================================================
   PAGE FADE TRANSITIONS + SHORTCUTS DIALOG
   ============================================================ */
(function () {
    'use strict';

    var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* ---- smooth page-to-page fade ----
       skipped when the browser supports MPA View Transitions
       (the @view-transition at-rule in CSS handles it natively) */
    var vtNative = window.CSS && CSS.supports && CSS.supports('view-transition-name', 'vt-probe');
    if (!prefersReduced && !vtNative) {
        document.addEventListener('click', function (e) {
            var a = e.target.closest ? e.target.closest('a') : null;
            if (!a) return;
            var href = a.getAttribute('href') || '';
            if (!href || href.charAt(0) === '#' || href.indexOf('javascript:') === 0) return;
            if (a.target === '_blank' || a.dataset.noFade !== undefined) return;
            if (href.indexOf('http') === 0 && href.indexOf(location.hostname) === -1) return;
            e.preventDefault();
            document.body.classList.add('page-leaving');
            setTimeout(function () { location.href = href; }, 180);
        });
    }

    /* ---- keyboard shortcuts dialog (press ?) ---- */
    var dlg = document.createElement('div');
    dlg.id = 'shortcutDialog';
    dlg.innerHTML =
        '<div class="sc-modal">' +
            '<h3><i class="fas fa-keyboard"></i> Keyboard Shortcuts</h3>' +
            '<div class="sc-row"><span>Open search</span><span class="sc-keys"><kbd>Ctrl</kbd><kbd>K</kbd></span></div>' +
            '<div class="sc-row"><span>Open search (quick)</span><span class="sc-keys"><kbd>/</kbd></span></div>' +
            '<div class="sc-row"><span>This shortcut list</span><span class="sc-keys"><kbd>?</kbd></span></div>' +
            '<div class="sc-row"><span>Close dialog / overlay</span><span class="sc-keys"><kbd>Esc</kbd></span></div>' +
            '<div class="sc-row"><span>Change theme</span><span class="sc-keys"><kbd>T</kbd></span></div>' +
            '<div class="sc-row"><span>Back to top</span><span class="sc-keys"><kbd>Home</kbd></span></div>' +
            '<div class="sc-row"><span>Flip flashcard <em style="opacity:.6">(quiz)</em></span><span class="sc-keys"><kbd>Space</kbd></span></div>' +
            '<div class="sc-row"><span>Rate card: again / got it</span><span class="sc-keys"><kbd>1</kbd><kbd>2</kbd></span></div>' +
        '</div>';
    document.body.appendChild(dlg);

    function toggleDlg(force) {
        dlg.classList.toggle('open', force);
    }
    dlg.addEventListener('click', function (e) { if (e.target === dlg) toggleDlg(false); });

    document.addEventListener('keydown', function (e) {
        var typing = ['INPUT', 'TEXTAREA', 'SELECT'].indexOf(e.target.tagName) !== -1;
        if (e.key === '?' && !typing) { e.preventDefault(); toggleDlg(!dlg.classList.contains('open')); }
        else if (e.key === 'Escape') toggleDlg(false);
        /* T cycles themes (when the toggle button exists) */
        else if ((e.key === 't' || e.key === 'T') && !typing && !e.ctrlKey && !e.metaKey && !e.altKey) {
            var btn = document.getElementById('themeToggle');
            if (btn) btn.click();
        }
    });
})();

/* ============================================================
   OBSIDIAN VAULT — touch flip only
   (pointer steering removed: it moved cards under the cursor
   and caused hover flicker / rapid open-close glitching)
   ============================================================ */
(function () {
    'use strict';
    var scene = document.querySelector('[data-vault-scene]');
    if (!scene) return;
    scene.querySelectorAll('.vault-card').forEach(function (card) {
        card.addEventListener('click', function (e) {
            if (e.target.closest('.back-cta')) return;   /* let the button work */
            card.classList.toggle('is-flipped');
        });
    });
})();


/* ============================================================
   TOAST NOTIFICATIONS — glass, stacked, auto-dismiss (#9)
   usage: toast('Saved', 'success'|'info'|'brand', durationMs)
   ============================================================ */
(function () {
    'use strict';

    var ICONS = { success: 'fa-circle-check', info: 'fa-circle-info', brand: 'fa-wand-magic-sparkles' };

    window.toast = function (message, type, duration) {
        type = ICONS[type] ? type : 'info';
        duration = duration || 3400;

        var stack = document.getElementById('toastStack');
        if (!stack) {
            stack = document.createElement('div');
            stack.id = 'toastStack';
            document.body.appendChild(stack);
        }
        /* keep max 4 visible */
        while (stack.children.length >= 4) stack.firstElementChild.remove();

        var el = document.createElement('div');
        el.className = 'toast t-' + type;
        el.setAttribute('role', 'status');
        el.style.setProperty('--t-dur', duration + 'ms');
        el.innerHTML = '<i class="fas ' + ICONS[type] + '"></i><span>' + message + '</span><span class="t-bar"></span>';
        stack.appendChild(el);

        var killed = false;
        function kill() {
            if (killed) return;
            killed = true;
            el.classList.add('t-leaving');
            setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 320);
        }
        el.addEventListener('click', kill);
        setTimeout(kill, duration);
        return kill;
    };
})();


/* ============================================================
   PROTON FIELD (#4) — spawn drifting particles in the hero.
   Pure rendering stays in CSS; JS only creates ~26 nodes once.
   ============================================================ */
(function () {
    'use strict';
    var field = document.getElementById('protonField');
    if (!field) return;
    /* the interactive canvas field replaces the CSS particles when present */
    if (document.getElementById('heroFieldCanvas')) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    /* golden-ratio scatter so the field looks organic, not gridded */
    var N = 26, phi = 0.61803398875;
    for (var i = 0; i < N; i++) {
        var d = document.createElement('span');
        d.className = 'pf-dot' + (i % 3 === 2 ? ' t' : '');
        var fx = (i * phi) % 1;                       /* 0..1 */
        var fy = ((i * phi * 1.13) % 1 + (i % 5) * 0.19) % 1;
        var size = 3 + ((i * 7) % 5);                 /* 3..7 px */
        var dur  = 9 + ((i * 13) % 9);                /* 9..17 s */
        var dx   = (((i * 17) % 60) - 30);            /* -30..29 px */
        var dy   = -30 - ((i * 11) % 55);             /* -30..-84 px */
        d.style.cssText =
            'left:' + (fx * 100).toFixed(2) + '%;' +
            'top:' + (fy * 100).toFixed(2) + '%;' +
            'width:' + size + 'px;height:' + size + 'px;' +
            '--pf-dx:' + dx + 'px;--pf-dy:' + dy + 'px;' +
            '--pf-o:' + (0.45 + ((i * 3) % 5) * 0.11).toFixed(2) + ';' +
            'animation-duration:' + dur + 's;' +
            'animation-delay:-' + ((i * 29) % 17) + 's;';   /* negative = mid-flight start */
        field.appendChild(d);
    }
})();


/* ============================================================
   SKELETON LOADERS (#5) — swap skeleton → real image on load.
   Works for .section-figure imgs and .figure-card gallery imgs.
   Zero CLS: skeletons match exact rendered ratios.
   ============================================================ */
(function () {
    'use strict';

    function dress(img) {
        if (img.dataset.skelDone) return;
        img.dataset.skelDone = '1';
        if (img.complete && img.naturalWidth > 0) return;   /* cached */
        img.classList.add('img-loading');
        var parent = img.parentElement;
        var skel = document.createElement('div');
        skel.className = 'skel ' + (parent.classList.contains('figure-img-wrap') ? 'skel-card-img' : 'skel-banner');
        if (parent.classList.contains('figure-img-wrap')) skel.style.cssText = 'position:absolute;inset:0;';
        parent.style.position = parent.style.position || 'relative';
        parent.appendChild(skel);
        function done() {
            img.classList.remove('img-loading');
            img.classList.add('img-loaded');
            if (skel.parentNode) skel.parentNode.removeChild(skel);
        }
        img.addEventListener('load', done, { once: true });
        img.addEventListener('error', done, { once: true });
        /* safety: never hold a skeleton over 6s */
        setTimeout(done, 6000);
    }

    function scan() {
        document.querySelectorAll('.section-figure img, .figure-img-wrap img').forEach(dress);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scan);
    else scan();
    /* late-injected content (atlas cards render on scroll) */
    window.addEventListener('load', scan);
})();




/* ============================================================
   SUITE WALKTHROUGH TABS (components page)
   ============================================================ */
(function () {
    'use strict';
    var tabs = document.querySelectorAll('.suite-tab');
    if (!tabs.length) return;
    tabs.forEach(function (t) {
        t.addEventListener('click', function () {
            tabs.forEach(function (x) { x.classList.remove('active'); });
            document.querySelectorAll('.suite-pane').forEach(function (p) { p.classList.remove('active'); });
            t.classList.add('active');
            var pane = document.getElementById('suite-' + t.getAttribute('data-suite'));
            if (pane) pane.classList.add('active');
        });
    });
})();
