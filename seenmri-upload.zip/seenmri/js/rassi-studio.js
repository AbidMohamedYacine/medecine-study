const input = document.querySelector('#promptInput');
const sendButton = document.querySelector('#sendButton');
const conversation = document.querySelector('#conversation');
const welcomeBlock = document.querySelector('#welcomeBlock');
const sidebar = document.querySelector('#sidebar');

function resizeInput() {
  input.style.height = 'auto';
  input.style.height = `${Math.min(input.scrollHeight, 120)}px`;
}

function addMessage(text, role) {
  const message = document.createElement('article');
  message.className = `${role}-message`;
  message.innerHTML = `<div class="message-label">${role === 'user' ? 'YOU' : 'RASSI'}</div><div>${text.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>')}</div>`;
  conversation.append(message);
  message.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function sendMessage() {
  const text = input.value.trim();
  if (!text) return;
  welcomeBlock.hidden = true;
  addMessage(text, 'user');
  input.value = '';
  resizeInput();
  const waiting = document.createElement('article');
  waiting.className = 'assistant-message';
  waiting.innerHTML = '<div class="message-label">RASSI</div><div class="typing">Preparing your workspace</div>';
  conversation.append(waiting);
  sendToEngine(text, waiting);
}

async function sendToEngine(text, waiting) {
  const form = new FormData();
  form.append('field-0', text);
  form.append('field-1', 'Editorial standard');
  try {
    const submit = await fetch('/rassi-api/form', { method: 'POST', body: form });
    if (!submit.ok) throw new Error(`The engine returned ${submit.status}.`);
    const { formWaitingUrl } = await submit.json();
    waiting.querySelector('.typing').textContent = 'Thinking through your brief';
    const result = await fetch(`/rassi-api/waiting?url=${encodeURIComponent(formWaitingUrl)}`);
    if (!result.ok) throw new Error(`The result returned ${result.status}.`);
    const html = await result.text();
    const page = new DOMParser().parseFromString(html, 'text/html');
    const content = page.querySelector('.form-success, .completion-message, main, body')?.innerText?.trim();
    if (!content) throw new Error('The engine returned an empty result.');
    waiting.querySelector('.typing').innerHTML = content.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
    waiting.querySelector('.typing').classList.remove('typing');
  } catch (error) {
    waiting.querySelector('.typing').textContent = `I could not complete that request: ${error.message} Check that n8n and OmniRoute are running, then try again.`;
    waiting.querySelector('.typing').classList.remove('typing');
  }
}

document.querySelectorAll('[data-prompt]').forEach((button) => {
  button.addEventListener('click', () => {
    input.value = button.dataset.prompt;
    resizeInput();
    input.focus();
  });
});

input.addEventListener('input', resizeInput);
input.addEventListener('keydown', (event) => {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
});
sendButton.addEventListener('click', sendMessage);
document.querySelector('#newChat').addEventListener('click', () => window.location.reload());
document.querySelector('#menuButton').addEventListener('click', () => sidebar.classList.toggle('open'));
