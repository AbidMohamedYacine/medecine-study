/* ============================================================
   SEENmri — quiz.js  (v2)
   Modes: MCQ practice (100-question bank) · Clinical cases
        · Spaced-repetition flashcards · Timed exam mode
   ============================================================ */
(function () {
    'use strict';

    function $(id) { return document.getElementById(id); }
    function shuffle(arr) {
        var a = arr.slice();
        for (var i = a.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var t = a[i]; a[i] = a[j]; a[j] = t;
        }
        return a;
    }
    function store(key, val) { try { localStorage.setItem(key, val); } catch (e) {} }
    function load(key) { try { return localStorage.getItem(key); } catch (e) { return null; } }

    /* ============================================================
       QUESTION BANK — 100 board-style questions (20 per category)
       ============================================================ */
    var QUESTIONS = [
        /* ================= PHYSICS & HARDWARE (20) ================= */
        { cat: 'physics', q: 'At a field strength of 1.5 T, the Larmor (resonance) frequency of hydrogen protons is approximately:', options: ['21.3 MHz', '42.6 MHz', '63.9 MHz', '127.7 MHz'], correct: 2, exp: 'The gyromagnetic ratio of hydrogen is 42.58 MHz/T. At 1.5 T: 42.58 × 1.5 ≈ 63.9 MHz. At 3 T it doubles to ≈ 127.7 MHz.' },
        { cat: 'physics', q: 'T2 relaxation is best described as:', options: ['Recovery of longitudinal magnetization through energy transfer to the lattice', 'Loss of transverse magnetization due to spin–spin dephasing', 'Realignment of protons with B0 after the 180° pulse', 'The transfer of energy from protons to surrounding fat molecules'], correct: 1, exp: 'T2 is the decay of transverse magnetization caused by spin–spin interactions (dephasing). Recovery of longitudinal magnetization is T1 (spin–lattice) relaxation.' },
        { cat: 'physics', q: 'Which combination produces a T1-weighted image?', options: ['Short TR + short TE', 'Long TR + long TE', 'Short TR + long TE', 'Long TR + short TE'], correct: 0, exp: 'Short TR (~500 ms) emphasizes differences in T1 recovery; short TE (~15 ms) minimizes T2 effects. Long TR + short TE = PD weighting; long TR + long TE = T2.' },
        { cat: 'physics', q: 'The primary purpose of the gradient coils in an MRI system is to:', options: ['Generate the main magnetic field B0', 'Transmit the RF excitation pulse', 'Provide spatial localization (encoding) of the signal', 'Actively shield the room from RF noise'], correct: 2, exp: 'Gradient coils produce linear field variations along X, Y and Z for slice selection, phase encoding and frequency encoding — the basis of spatial localization.' },
        { cat: 'physics', q: 'In k-space, the central lines primarily determine:', options: ['Spatial resolution and fine detail', 'Image contrast and overall signal', 'The receiver bandwidth', 'The slice thickness'], correct: 1, exp: 'Central k-space contains low-spatial-frequency data → contrast and bulk signal. Peripheral k-space contains high frequencies → edges and fine detail.' },
        { cat: 'physics', q: 'The MRI signal in clinical imaging predominantly originates from:', options: ['Sodium-23 nuclei', 'Phosphorus-31 nuclei', 'Hydrogen-1 (protons) in water and fat', 'Carbon-13 nuclei'], correct: 2, exp: 'Hydrogen-1 is used because of its abundance in body water and fat and its high gyromagnetic ratio — the strongest signal of any stable nucleus.' },
        { cat: 'physics', q: 'At equilibrium inside the magnet, net magnetization:', options: ['Points along B0 (longitudinal), with no transverse component', 'Rotates in the transverse plane', 'Is zero because protons point randomly', 'Points opposite to B0'], correct: 0, exp: 'Slightly more protons align parallel than anti-parallel to B0, producing a small net longitudinal magnetization along B0. There is no coherent transverse component.' },
        { cat: 'physics', q: 'The 180° refocusing pulse in spin echo primarily serves to:', options: ['Invert the image contrast', 'Rephase transverse magnetization and cancel T2* effects', 'Select the slice thickness', 'Suppress fat signal'], correct: 1, exp: 'The 180° pulse flips dephased spins so they rephase at the echo time — reversing field inhomogeneity (T2*) effects and measuring true T2 decay.' },
        { cat: 'physics', q: 'Compared with T2, the T2* time constant is:', options: ['Longer, because inhomogeneity is corrected', 'Shorter, because it also includes magnetic field inhomogeneity', 'Identical in all tissues', 'Independent of the main field'], correct: 1, exp: 'T2* = spin–spin decay PLUS dephasing from B0 inhomogeneity and susceptibility differences — always shorter than T2, and the contrast basis of GRE/SWI.' },
        { cat: 'physics', q: 'Slice selection is achieved by:', options: ['Applying a gradient during the RF pulse', 'Applying a gradient only during readout', 'Using the 180° pulse alone', 'Changing the receiver bandwidth after acquisition'], correct: 0, exp: 'A slice-select gradient makes resonance frequency vary along one axis; the RF pulse (with a chosen bandwidth) then excites only the protons in the desired slab.' },
        { cat: 'physics', q: 'Frequency encoding is performed:', options: ['Before the RF pulse', 'During signal readout, with the readout gradient on', 'Using a 180° pulse', 'Only in 3D imaging'], correct: 1, exp: 'The readout (frequency-encoding) gradient is on while the echo is sampled — position along that axis maps directly to signal frequency.' },
        { cat: 'physics', q: 'Phase encoding works by:', options: ['Making protons precess at different frequencies permanently', 'Briefly applying a gradient before readout so spins accumulate position-dependent phase', 'Reversing the main field', 'Detecting the FID directly'], correct: 1, exp: 'A short phase-encoding gradient gives each row a different phase angle. This step must be repeated for every phase-encoding step — the main reason for scan time.' },
        { cat: 'physics', q: 'The Fourier transform in MRI converts:', options: ['Frequency data into time-domain signals', 'Time-domain signal into frequency/spatial data', 'Magnetic field into gradient strength', 'T1 values into image brightness'], correct: 1, exp: 'The coil records a time-varying sum of frequencies; the FFT untangles them into amplitudes at each frequency — i.e., locations along the encoded axes.' },
        { cat: 'physics', q: 'Shimming is performed to:', options: ['Increase the main field strength', 'Improve B0 homogeneity across the anatomy', 'Cool the gradient coils', 'Adjust the RF transmit gain only'], correct: 1, exp: 'Shimming (passive/active) smooths field variations so T2* is longer, distortion smaller, and fat saturation more uniform.' },
        { cat: 'physics', q: 'Signal detection in the receiver coil relies on:', options: ['The Zeeman effect', 'Faraday induction: rotating transverse magnetization induces a voltage', 'Direct proton counting', 'Photoelectric absorption'], correct: 1, exp: 'By Faraday\u2019s law of induction, the precessing net transverse magnetization changes flux through the coil and induces the measured electrical signal.' },
        { cat: 'physics', q: 'The free induction decay (FID) signal decreases rapidly because of:', options: ['T1 recovery only', 'Dephasing from field inhomogeneity (T2*)', 'Excess receiver bandwidth', 'Gradient overheating'], correct: 1, exp: 'Immediately after excitation, spins dephase quickly from inhomogeneity and susceptibility — the FID vanishes far faster than true T2 (hence spin-echo refocusing).' },
        { cat: 'physics', q: 'An inversion recovery sequence begins with which pulse?', options: ['90° pulse', '180° pulse', 'Alpha pulse of 30°', 'A saturation pulse'], correct: 1, exp: 'IR starts with a 180° inversion pulse; after inversion time TI, a 90° pulse samples the recovering magnetization — the basis of FLAIR, STIR and LGE.' },
        { cat: 'physics', q: 'Increasing B0 from 1.5 T to 3 T typically:', options: ['Doubles SNR exactly and halves all artifacts', 'Increases signal and chemical shift but worsens susceptibility and SAR', 'Has no effect on T1 values', 'Makes sequences slower'], correct: 1, exp: '3 T roughly doubles magnetization (better SNR and T1 contrast) but doubles chemical shift and RF deposition (SAR) and amplifies susceptibility artifacts; T1 times lengthen.' },
        { cat: 'physics', q: 'The gradient echo differs from spin echo mainly because it:', options: ['Uses smaller flip angles and no 180° refocusing pulse', 'Requires a longer TR', 'Cannot produce T1 contrast', 'Uses no gradients at all'], correct: 0, exp: 'GRE uses flip angles < 90° and rephases with gradient reversal only — fast and T2*-sensitive, but vulnerable to field inhomogeneity and metal.' },
        { cat: 'physics', q: 'In a spin echo, signal intensity is proportional to:', options: ['PD × (1 − e^−TR/T1) × e^−TE/T2', 'PD × TR × TE', 'PD / (T1 × T2)', 'T1 × T2 / TR'], correct: 0, exp: 'This classic equation shows TR controls T1 weighting and TE controls T2 weighting, scaled by proton density (PD).' },

        /* ================= SEQUENCES & CONTRAST (20) ================= */
        { cat: 'sequences', q: 'A FLAIR sequence is essentially a T2-weighted image in which:', options: ['Fat signal is nulled', 'CSF signal is suppressed', 'Blood products are highlighted', 'Water molecules are diffusion-sensitized'], correct: 1, exp: 'FLAIR (Fluid-Attenuated Inversion Recovery) uses a long inversion time to null CSF, making periventricular and cortical lesions (e.g. MS plaques) far more conspicuous.' },
        { cat: 'sequences', q: 'The most sensitive sequence for detecting acute ischemic infarction is:', options: ['T1-weighted spin echo', 'T2-weighted FSE', 'DWI with ADC map', 'T2*-weighted GRE'], correct: 2, exp: 'Cytotoxic edema in acute stroke restricts diffusion → high DWI signal with low ADC, visible within minutes — long before conventional sequences change.' },
        { cat: 'sequences', q: 'STIR sequences are used mainly to:', options: ['Suppress fluid and highlight CSF', 'Suppress fat signal and show bone marrow edema', 'Highlight flowing blood', 'Improve T1 contrast after gadolinium'], correct: 1, exp: 'STIR nulls fat with a short inversion time (~150–180 ms). It is robust (insensitive to field inhomogeneity) for marrow edema and musculoskeletal work.' },
        { cat: 'sequences', q: 'Compared with spin echo, gradient echo sequences:', options: ['Always use a 180° refocusing pulse', 'Are slower but higher resolution', 'Use variable flip angles and are more sensitive to susceptibility', 'Cannot be used with 3D acquisition'], correct: 2, exp: 'GRE has no 180° pulse, uses flip angles < 90°, and is fast — but more sensitive to inhomogeneity, metal and susceptibility effects (a strength in SWI/T2*).' },
        { cat: 'sequences', q: 'The workhorse sequence for cardiac cine (function) imaging is:', options: ['T2-weighted FSE', 'Balanced SSFP (bSSFP)', 'DWI EPI', 'T1 spin echo'], correct: 1, exp: 'bSSFP gives high blood–myocardium contrast with short, motion-robust acquisitions — ideal for segmented cine loops through the cardiac cycle.' },
        { cat: 'sequences', q: 'Susceptibility-weighted imaging (SWI) is particularly valuable for detecting:', options: ['Acute infarction', 'Calcification and old blood products (hemosiderin)', 'Meniscal tears', 'Biliary calculi'], correct: 1, exp: 'SWI exploits T2* susceptibility differences, exquisitely showing venous blood, hemosiderin, calcification and microhemorrhages.' },
        { cat: 'sequences', q: 'High DWI signal that is NOT stroke (normal ADC) is called:', options: ['T2 shine-through', 'Magnetic susceptibility', 'Chemical shift artifact', 'Pseudo-normalization'], correct: 0, exp: 'Long-T2 lesions stay bright on DWI simply from their T2 signal — “shine-through”. A dark ADC map excludes true restriction; always interpret DWI with ADC.' },
        { cat: 'sequences', q: 'Single-shot echo-planar imaging (EPI) is used for DWI because it:', options: ['Has the highest spatial resolution', 'Freezes motion by acquiring all k-space lines after one RF pulse', 'Removes all susceptibility artifact', 'Requires no gradients'], correct: 1, exp: 'Single-shot EPI fills k-space in ~100 ms — fast enough to freeze bulk motion, making diffusion imaging of the moving brain practical (at the cost of distortion).' },
        { cat: 'sequences', q: '3D MPRAGE (sagittal T1) is preferred for brain volumetry because it provides:', options: ['Fluid suppression', 'Isotropic sub-millimeter slices for multiplanar reformats', 'Diffusion data', 'The fastest single acquisition possible'], correct: 1, exp: 'MPRAGE yields thin, contiguous, high-contrast T1 volumes — ideal for hippocampal/whole-brain volumetry, surgical planning and cortical lesion search.' },
        { cat: 'sequences', q: 'Chemical-shift (CHESS) fat saturation works by:', options: ['A saturation pulse tuned to the fat resonance frequency', 'A short inversion time nulling fat', 'Inverting water only', 'Increasing the bandwidth'], correct: 0, exp: 'CHESS applies a narrow-band RF pulse at the fat frequency (3.5 ppm from water) followed by spoiler gradients — fast and effective in homogeneous fields.' },
        { cat: 'sequences', q: 'Proton density (PD) weighting results from:', options: ['Short TR + short TE', 'Long TR + short TE', 'Long TR + long TE', 'Short TR + long TE'], correct: 1, exp: 'With long TR, T1 differences recover; with short TE, T2 decay has little effect — leaving mostly proton density differences (classic for meniscus imaging).' },
        { cat: 'sequences', q: 'HASTE / single-shot FSE sequences are especially useful for:', options: ['Breath-hold imaging of fluid-filled structures (e.g. MRCP)', 'Diffusion imaging', 'Calcium detection', 'Cardiac perfusion'], correct: 0, exp: 'HASTE acquires an entire image in one shot (~1 s per slice) — robust to motion, perfect for fluid-heavy indications like MRCP and fetal imaging.' },
        { cat: 'sequences', q: 'In time-of-flight (TOF) MRA, vessels appear bright because:', options: ['Gadolinium shortens blood T1', 'Unsaturated spins enter the slab between RF pulses (flow-related enhancement)', 'Blood has inherently high proton density', 'Flow voids are reversed'], correct: 1, exp: 'Repeated RF pulses saturate stationary tissue; fresh spins flowing into the slab retain full magnetization → bright. Slow or in-plane flow saturates too (the MOTSA solution).' },
        { cat: 'sequences', q: 'Phase-contrast MRA is unique because it can:', options: ['Only image arteries', 'Quantify flow velocity and direction (e.g. CSF flow, regurgitant volume)', 'Suppress fat automatically', 'Run without gradients'], correct: 1, exp: 'Velocity-encoded phase differences allow quantitative flow measurement — the method of choice for CSF flow studies and valvular regurgitation quantification.' },
        { cat: 'sequences', q: 'Compared with TOF, contrast-enhanced MRA (Gd-MRA):', options: ['Is more sensitive to slow or turbulent flow artifacts', 'Relies on T1 shortening of blood rather than inflow, so it is less flow-dependent', 'Cannot image the abdomen', 'Requires no timing'], correct: 1, exp: 'First-pass gadolinium MRA shortens blood T1 directly — robust in slow/turbulent flow, ideal for aortoiliac run-off and carotids; but bolus timing matters.' },
        { cat: 'sequences', q: 'At 1.5 T, in-phase and opposed-phase TE times for water/fat are approximately:', options: ['2.3 ms and 4.6 ms', '4.6 ms and 2.3 ms', '10 ms and 20 ms', '50 ms and 100 ms'], correct: 1, exp: 'Water and fat dephase/rephase every ~2.3 ms at 1.5 T: TE 4.6 ms = in-phase (add), 2.3 ms = opposed-phase (cancel) — the basis of Dixon/chemical-shift imaging.' },
        { cat: 'sequences', q: 'Increasing the b-value in diffusion imaging:', options: ['Increases T2 contribution', 'Increases diffusion weighting but lowers SNR', 'Shortens scan time', 'Suppresses fat'], correct: 1, exp: 'Higher b-values sensitize to diffusion but cost signal — restriction becomes more specific (e.g. prostate/ONCO lesions), at the price of noisier images.' },
        { cat: 'sequences', q: 'Driven equilibrium (DRIVE/RESTORE) is used to:', options: ['Allow shorter TR in heavily T2-weighted FSE', 'Suppress artifacts from metal', 'Speed up gradient echo sequences', 'Improve fat saturation'], correct: 0, exp: 'A -90° pulse pushes residual transverse magnetization back to the longitudinal axis, allowing shorter TRs in heavily T2-weighted (3D) FSE/FRFSE like inner-ear imaging.' },
        { cat: 'sequences', q: 'Multi-slab (MOTSA) 3D TOF is used to overcome:', options: ['Saturation of slow in-plane flow in single thick slabs', 'Excessive scan time', 'Poor spatial resolution', 'RF deposition limits'], correct: 0, exp: 'Thin overlapping slabs reduce the distance spins travel within each slab, keeping intracranial and carotid flow fresh (bright) over long vascular segments.' },
        { cat: 'sequences', q: 'Susceptibility artifacts from hip prostheses are MINIMIZED by:', options: ['Gradient echo with long TE', 'Fast/turbo spin echo with wide receiver bandwidth and STIR', 'EPI with high b-value', 'Narrow bandwidth GRE'], correct: 1, exp: 'FSE\u2019s 180° trains refocus inhomogeneity, wide bandwidth limits spatial misregistration, and STIR beats CHESS fat-sat near metal — the MARS philosophy.' },

        /* ================= CARDIAC MRI (20) ================= */
        { cat: 'cardiac', q: 'Late gadolinium enhancement (LGE) imaging is typically performed:', options: ['During the first pass of contrast', '10–15 minutes after contrast injection', 'Before contrast administration', 'Only with exercise stress'], correct: 1, exp: 'After ~10–15 min, gadolinium washes out of normal myocardium but accumulates in scar/fibrosis (expanded interstitium), which appears bright on LGE.' },
        { cat: 'cardiac', q: 'In LGE imaging, the inversion time (TI) is chosen so that:', options: ['Blood pool is nulled', 'Normal myocardium appears dark (nulled)', 'Fat is suppressed', 'The LV cavity is black'], correct: 1, exp: 'Correct TI nulls normal myocardium — scar stays bright. Too-short TI darkens myocardium excessively; Look–Locker scouts help find the null point.' },
        { cat: 'cardiac', q: 'A first-pass perfusion study under vasodilator stress is used to detect:', options: ['Myocardial scar', 'Inducible ischemia', 'Pericardial effusion', 'Congenital shunts'], correct: 1, exp: 'Adenosine/dipyridamole stress + first-pass Gd reveals perfusion defects in territories supplied by stenotic coronaries — a perfusion reserve deficit.' },
        { cat: 'cardiac', q: 'Increased myocardial signal on T2-weighted / T2-mapped images indicates:', options: ['Chronic fibrosis', 'Iron overload', 'Edema / inflammation (e.g. myocarditis, acute infarction)', 'Lipomatous metaplasia'], correct: 2, exp: 'T2-bright myocardium reflects edema — acute MI, myocarditis, transplant rejection. Iron overload conversely LOWERS T2/T2* signal.' },
        { cat: 'cardiac', q: 'Retrospective ECG gating in cardiac MRI means:', options: ['Data is acquired only in diastole', 'The full RR interval is reconstructed after acquisition, including atrial systole', 'The scanner ignores the ECG signal', 'Images are only reconstructed at end-expiration'], correct: 1, exp: 'Retrospective gating acquires continuously and bins data to the cardiac cycle afterwards — complete systole+diastole coverage, ideal for functional analysis.' },
        { cat: 'cardiac', q: 'LV thrombus on LGE typically appears:', options: ['Bright, like scar', 'Dark (avascular) — best seen with long-TI “thrombus-sensitive” sequences', 'Identical to blood pool', 'Only on T1-weighted spin echo'], correct: 1, exp: 'Thrombus is avascular and does not enhance — it stays dark against bright blood and is conspicuously black on long-TI LGE.' },
        { cat: 'cardiac', q: 'A short-axis (SAX) cine stack is prescribed:', options: ['Parallel to the interventricular septum', 'Perpendicular to the long axis of the LV, covering apex through base', 'Along the 4-chamber plane', 'Free-breathing in any orientation'], correct: 1, exp: 'SAX slices are double-oblique, perpendicular to a line from mitral valve to apex on 2- and 4-chamber localizers — required for accurate volumes and EF.' },
        { cat: 'cardiac', q: 'Dark banding artifacts in bSSFP cine most often result from:', options: ['Excessive TR', 'Off-resonance (B0 inhomogeneity), e.g. at the lung–heart interface or post-surgery', 'Low flip angle', 'Gd contrast'], correct: 1, exp: 'bSSFP bands where spins are off-resonance (mitral/aortic prostheses, air-tissue interfaces) — improve with shimming, shorter TR, or swap to GRE.' },
        { cat: 'cardiac', q: 'Myocardial tagging (SPAMM) sequences are used to assess:', options: ['Intracardiac thrombus', 'Regional wall motion and strain (grid deformation)', 'Myocardial iron', 'Coronary stenosis'], correct: 1, exp: 'Saturation grids deform with contraction — visualizing and quantifying regional strain/rotation (strain analysis, LV twist).' },
        { cat: 'cardiac', q: 'Through-plane phase-contrast flow mapping of the aorta is commonly used to quantify:', options: ['Aortic regurgitant fraction / stroke volume (and shunts: Qp:Qs)', 'Myocardial scar size', 'Coronary calcium', 'Pericardial thickness'], correct: 0, exp: 'Velocity-encoded imaging integrates flow over the cardiac cycle — valvular regurgitant volumes and Qp:Qs shunt ratios without invasive catheterization.' },
        { cat: 'cardiac', q: 'A SUBENDOCARDIAL LGE pattern classically indicates:', options: ['Myocarditis', 'Previous myocardial infarction (coronary-territory)', 'Hypertrophic cardiomyopathy', 'Sarcoidosis'], correct: 1, exp: 'Subendocardial or transmural enhancement in a coronary distribution = infarct. Subepicardial/mid-wall patterns suggest myocarditis/DCM; patchy mid-wall suggests sarcoid/HCMP.' },
        { cat: 'cardiac', q: 'Elevated native T1 and extracellular volume (ECV) on T1 mapping are characteristic of:', options: ['Iron overload', 'Amyloidosis, diffuse fibrosis and edema', 'Focal fat infiltration', 'Normal myocardium'], correct: 1, exp: 'Expanded interstitial space (amyloid, fibrosis, edema) raises native T1/ECV; iron overload LOWERS T1 and T2* — mapping quantifies tissue composition.' },
        { cat: 'cardiac', q: 'A myocardial T2* below 20 ms indicates:', options: ['Normal iron levels', 'Myocardial iron overload requiring chelation intensification', 'Acute infarction', 'Myocardial edema'], correct: 1, exp: 'T2* < 20 ms is the established threshold of clinically significant myocardial siderosis in thalassemia — directly triggers chelation strategy changes.' },
        { cat: 'cardiac', q: 'Low-dose dobutamine cine stress assesses:', options: ['Myocardial iron', 'Contractile reserve / viability in hibernating myocardium', 'Pericardial constriction', 'Valvular stenosis gradients'], correct: 1, exp: 'Improvement of wall thickening with low-dose dobutamine identifies viable myocardium that may recover after revascularization.' },
        { cat: 'cardiac', q: 'Arrhythmogenic right ventricular cardiomyopathy (ARVC) MRI findings include:', options: ['Left-dominant subendocardial scar', 'RV dilation, global dysfunction, and DWI bright fat/fibrosis of the RV free wall', 'Pericardial thickening', 'LV non-compaction only'], correct: 1, exp: 'Task-force criteria combine RV regional/global dysfunction with tissue characterization (fat/fibrosis) and LGE — beware interpreter variability.' },
        { cat: 'cardiac', q: 'The “dark rim” artifact on first-pass perfusion typically appears:', options: ['In the right atrium', 'As a thin subendocardial dark band, worst at end-systole/first frames — mimicking a defect', 'As circumferential brightening', 'Only on LGE'], correct: 1, exp: 'Dark rim artifact (susceptibility + motion + Gibbs at the blood–myocardium boundary) can mimic ischemia — check whether it persists across phases and matches a coronary territory.' },
        { cat: 'cardiac', q: 'The most common primary cardiac tumor, typically attached to the interatrial septum, is:', options: ['Metastasis', 'Myxoma', 'Rhabdomyoma', 'Lipoma'], correct: 1, exp: 'Atrial myxoma (left atrium, septal attachment, mobile pedunculated mass) — look for the “waltz” of prolapse through the mitral valve on cine.' },
        { cat: 'cardiac', q: 'Real-time free-breathing cine is particularly helpful in suspected pericardial constriction because it shows:', options: ['Coronary anatomy', 'Septal bounce / ventricular interdependence with respiration', 'Myocardial iron', 'Valve vegetations'], correct: 1, exp: 'Septal flattening/shifting with respiration (interdependence) supports constrictive physiology; add tagged cine for pericardial–myocardial adherence.' },
        { cat: 'cardiac', q: 'Coronary MRA remains technically difficult primarily because of:', options: ['Excessive SAR', 'Combined cardiac and respiratory motion of small-caliber vessels', 'Lack of contrast agents', 'Theoretical signal limits'], correct: 1, exp: 'Sub-millimeter coronary arteries move with both heartbeat and breathing — navigators, motion correction and isotropic 3D acquisitions mitigate but don\u2019t fully solve it.' },
        { cat: 'cardiac', q: 'On LGE performed 10–15 minutes post-Gd, an area of infarcted myocardium appears bright because:', options: ['Scar retains gadolinium in its expanded interstitial space with slower washout', 'Gadolinium concentrates inside myocytes', 'Infarcted tissue has more protons', 'Blood pool enters the scar'], correct: 0, exp: 'Ruptured myocyte membranes and expanded extracellular matrix trap the extracellular Gd agent — higher concentration, slower kinetics → hyperenhancement.' },

        /* ================= SAFETY & SCREENING (20) ================= */
        { cat: 'safety', q: 'According to ACR guidance, Zone III of an MRI facility is:', options: ['The public area outside the magnet room', 'The interface/reception area', 'A controlled-access area behind a physical barrier (e.g. control room)', 'The scanner room itself'], correct: 2, exp: 'Zone I = unrestricted public; Zone II = interface; Zone III = controlled access (fringe field — screening required); Zone IV = the magnet room itself.' },
        { cat: 'safety', q: 'An implant labelled “MR Conditional” means:', options: ['It is safe in any MRI environment', 'It poses no risk under all conditions', 'It is safe only under specific documented conditions (field strength, SAR, gradients…)', 'It must never enter the MRI environment'], correct: 2, exp: 'MR Conditional = tested safe only under the exact documented conditions. MR Safe = no hazard in any MRI environment. MR Unsafe = never enters Zone IV.' },
        { cat: 'safety', q: 'An emergency quench should ONLY be activated when:', options: ['The patient feels claustrophobic', 'A life-threatening situation exists (e.g. a person pinned against the magnet)', 'Image quality degrades', 'The patient moves during the scan'], correct: 1, exp: 'Quenching boils off helium and collapses the field — costly and potentially dangerous (asphyxiation, cold, pressure). Reserved for life-threatening entrapment only.' },
        { cat: 'safety', q: 'The cryogen used to supercool modern MRI magnet windings is:', options: ['Liquid nitrogen', 'Liquid helium', 'Liquid argon', 'Compressed oxygen'], correct: 1, exp: 'Liquid helium at ≈ 4 K (−269 °C) keeps the niobium–titanium windings superconducting.' },
        { cat: 'safety', q: 'The main biological risk from rapidly switched gradients (high dB/dt) is:', options: ['Skin burns', 'Peripheral nerve stimulation', 'Cataracts', 'Magnetophosphenes only'], correct: 1, exp: 'Fast gradient switching induces currents that can stimulate peripheral nerves (tingling, twitching). RF drives SAR/heating; acoustic noise drives hearing risk.' },
        { cat: 'safety', q: 'Nephrogenic systemic fibrosis (NSF) is a recognized risk of gadolinium contrast in patients with:', options: ['Asthma', 'Severe renal impairment (eGFR < 30 mL/min/1.73 m²)', 'Prior iodinated contrast reaction', 'Sickle cell trait'], correct: 1, exp: 'NSF is associated with gadolinium in severe/acute renal failure, particularly older linear agents — hence renal screening and group II (macrocyclic) agents.' },
        { cat: 'safety', q: 'The 5-gauss line defines:', options: ['The RF safety boundary', 'The fringe-field contour where the static field falls to 0.5 mT — the pacemaker/general-public limit', 'The gradient duty cycle limit', 'The SAR limit zone'], correct: 1, exp: 'Beyond the 5-G (0.5 mT) line, the field is considered safe for the general public and pacemakers — this boundary must be inside controlled Zones III/IV.' },
        { cat: 'safety', q: 'The attractive force on a ferromagnetic object near the magnet increases most strongly with:', options: ['Object weight only', 'Decreasing distance and increasing field GRADIENT (spatial variation)', 'Room temperature', 'Humidity'], correct: 1, exp: 'Translational force ∝ the field gradient — it rises steeply toward the bore entrance, which is why objects “jump” from meters away.' },
        { cat: 'safety', q: 'Gradient noise in the scanner can reach levels requiring:', options: ['No protection', 'Certified hearing protection for every patient (earplugs/headphones)', 'Only oxygen monitoring', 'Lead aprons'], correct: 1, exp: 'Gradient switching can exceed 110–120 dB — hearing protection (≥29 dB NRR) is standard for all patients and staff in Zone IV.' },
        { cat: 'safety', q: 'A fire-fighter wearing a steel SCBA air cylinder approaches Zone IV. You must:', options: ['Allow entry if accompanied', 'Stop them firmly before the 5-gauss line — the cylinder is a lethal projectile', 'Turn off the magnet quickly', 'Proceed if they remove their helmet'], correct: 1, exp: 'Ferromagnetic compressed-air cylinders are classic lethal projectiles. All emergency staff must be briefed before ANY entry; equipment stays outside the 5-G line.' },
        { cat: 'safety', q: 'During a quench, the primary immediate danger to people in the room is:', options: ['Electric shock', 'Oxygen displacement by helium gas (asphyxiation) and extreme cold', 'RF burns', 'X-ray radiation'], correct: 1, exp: 'Boiling helium expands ~750×; if the quench pipe fails, oxygen is displaced and fog/freezing gas floods the room — evacuate immediately.' },
        { cat: 'safety', q: 'Regarding pregnancy and MRI:', options: ['MRI is absolutely contraindicated in all trimesters', 'Non-contrast MRI may be performed when the benefit justifies it; gadolinium only in life-critical situations', 'Only 3 T scanners are safe', 'MR technologists cannot scan pregnant patients at all'], correct: 1, exp: 'Current guidance: no known adverse effects from non-contrast MRI at any stage when justified; gadolinium is restricted to critical need (ACR/Safety Committee).' },
        { cat: 'safety', q: 'Transdermal patches with metallic foil backing (e.g. nicotine, fentanyl) must be:', options: ['Left in place to maintain dosing', 'Removed before the scan — RF heating can cause burns', 'Covered with a cold cloth', 'Monitored visually during scanning'], correct: 1, exp: 'Foil backing acts as an RF antenna → skin burns. Remove before entry and document reapplication time.' },
        { cat: 'safety', q: 'Extensive dark tattoos pose a risk mainly because of:', options: ['Magnetic migration of pigment', 'RF heating of metallic pigments (iron oxide) — cold compresses and monitoring advised', 'Image quality degradation only', 'Allergic reaction to B0'], correct: 1, exp: 'Iron-oxide pigment absorbs RF energy; burns (rare) are prevented with cold compresses and instructing patients to report warmth.' },
        { cat: 'safety', q: 'Screening for MRI safety applies to:', options: ['Patients only', 'Patients, staff, family members, and visitors — everyone entering Zone III/IV', 'Only implant carriers', 'Children only'], correct: 1, exp: 'Every person crossing into Zones III/IV must be screened (forms + verbal + metal detector where available) — no exceptions, including repair technicians.' },
        { cat: 'safety', q: 'Sedated or critically ill patients in Zone IV require:', options: ['Standard visual observation only', 'MR-conditional monitoring equipment and trained staff present throughout', 'No monitoring for scans under 10 minutes', 'Transfer to the magnet is prohibited'], correct: 1, exp: 'Anesthetised/ICU patients need MR-conditional monitors, MR-safe ventilation and emergency drugs inside Zone IV, with an anesthesiologist-trained team.' },
        { cat: 'safety', q: 'Gadolinium extravasation at the IV site is first managed by:', options: ['Continuing rapid injection', 'Stopping injection, aspirating what is possible, elevating the limb and cold compresses', 'Immediate surgical consult in all cases', 'Applying a magnet to the arm'], correct: 1, exp: 'Stop, aspirate, elevate, cold compress and observe — plastic surgery consult only for compartment-suspicion or large volumes.' },
        { cat: 'safety', q: 'The MR-safety classification “MR Safe” (square green icon) means the device:', options: ['Is safe only at 1.5 T', 'Poses no hazard in ANY MRI environment (non-conducting, non-metallic, non-magnetic)', 'Has never been tested', 'Is safe only with patient monitoring'], correct: 1, exp: 'MR Safe items are non-magnetic, non-conductive and non-metallic — no risk in any environment. Conditional items carry the yellow triangle and specific conditions.' },
        { cat: 'safety', q: 'The static field B0 can affect patients primarily through:', options: ['Tissue heating', 'Magnetophosphenes, dizziness/metallic taste at very high fields (transient, no known lasting harm)', 'DNA damage as with ionizing radiation', 'Bone demineralization'], correct: 1, exp: 'Static fields cause transient sensations (vertigo, phosphenes, taste) — no convincing evidence of lasting harm; MRI has no ionizing radiation.' },
        { cat: 'safety', q: 'The correct order of events after a contrast reaction (mild urticaria) is:', options: ['Finish the scan first', 'Stop/assess, call the radiologist, observe — antihistamine per protocol; prepare for progression', 'Quench the magnet immediately', 'Send the patient home'], correct: 1, exp: 'Even mild reactions can progress: stop injection, assess airway/vitals, treat per the department\u2019s ACR reaction ladder and document.' },

        /* ================= PARAMETERS & TRADE-OFFS (20) ================= */
        { cat: 'parameters', q: 'Increasing the number of signal averages (NEX/NSA) from 1 to 4 will:', options: ['Double the SNR and scan time', 'Improve SNR by √4 = 2× and quadruple scan time', 'Improve SNR 4× with no time penalty', 'Reduce noise but also reduce resolution'], correct: 1, exp: 'SNR ∝ √NEX: 4 averages → 2× SNR, but scan time increases linearly (4×). The classic MRI trade-off.' },
        { cat: 'parameters', q: 'Reducing the receiver bandwidth will:', options: ['Increase noise and reduce chemical shift', 'Decrease noise (higher SNR) but increase chemical shift artifact and minimum TE', 'Have no effect on SNR', 'Shorten the echo time'], correct: 1, exp: 'Narrow bandwidth samples fewer frequencies → less noise, but fat–water chemical shift spreads over more pixels and the longer sampling window raises minimum TE.' },
        { cat: 'parameters', q: 'Halving the FOV while keeping the matrix constant will:', options: ['Improve resolution but reduce SNR and risk aliasing (wrap-around)', 'Improve SNR with no downside', 'Have no effect on pixel size', 'Double the SNR'], correct: 0, exp: 'Pixel = FOV ÷ matrix. Smaller FOV → smaller voxels → better resolution, less signal per voxel (SNR ↓) and possible phase wrap-around.' },
        { cat: 'parameters', q: 'Which parameter most directly controls T2 contrast in spin echo imaging?', options: ['TR', 'TE', 'Flip angle', 'NEX'], correct: 1, exp: 'TE sets how much transverse decay occurs before readout → T2 weighting. TR mainly modulates T1 weighting; flip angle matters chiefly in GRE.' },
        { cat: 'parameters', q: 'In gradient echo imaging, increasing the flip angle (α) results in:', options: ['More T2* weighting', 'More T1 weighting', 'More PD weighting', 'No contrast change'], correct: 1, exp: 'Larger flip angles saturate spins and emphasize T1 differences (spoiled GRE T1); small angles (~5–10°) minimize T1 sensitivity → PD/T2* weighting.' },
        { cat: 'parameters', q: 'Increasing the echo train length (ETL / turbo factor) in FSE:', options: ['Increases scan time', 'Shortens scan time at the cost of image blur', 'Increases SNR proportionally', 'Is only possible in GRE'], correct: 1, exp: 'More echoes per TR → fewer repetitions → faster, at the price of blurring along the phase direction (broader point-spread function).' },
        { cat: 'parameters', q: 'Pixel size in the frequency-encoding direction equals:', options: ['Matrix ÷ FOV', 'FOV ÷ frequency matrix', 'Bandwidth ÷ TR', 'Slice thickness × NEX'], correct: 1, exp: 'Pixel size = FOV ÷ matrix along each axis — the fundamental resolution equation (and the route to computing voxel volume).' },
        { cat: 'parameters', q: 'Which change improves SNR the most with the LEAST cost in scan time?', options: ['Doubling NEX', 'Doubling slice thickness', 'Halving the matrix in both directions', 'Doubling TR'], correct: 1, exp: 'Doubling slice thickness doubles voxel volume (and SNR ~doubles) at no time cost — the trade-off is through-plane resolution (partial volume).' },
        { cat: 'parameters', q: 'The total scan time of a 2D spin echo series equals:', options: ['TR × matrix(frequency) × NEX', 'TR × phase steps × NEX (÷ ETL in FSE)', 'TE × NEX × slices', 'TR + TE + NEX'], correct: 1, exp: 'Time per slice = TR × phase-encoding steps × NEX; FSE divides by ETL — which is why phase matrix, not frequency matrix, drives duration.' },
        { cat: 'parameters', q: 'Parallel imaging (GRAPPA/SENSE) with factor R = 2 will:', options: ['Halve scan time and reduce SNR (≈ by √2 plus g-factor), with possible aliasing', 'Double SNR and halve time', 'Not affect image quality', 'Work only in 3D imaging'], correct: 0, exp: 'Undersampling phase lines gains speed but costs SNR and can unfold poorly (g-factor) — calibration and coil geometry matter.' },
        { cat: 'parameters', q: 'Chemical-shift artifact (dark/bright band at fat–water interfaces) is measured in:', options: ['Millimeters of spatial shift, proportional to (frequency difference × matrix ÷ bandwidth)', 'Seconds', 'Decibels', 'Tesla'], correct: 0, exp: 'The shift in pixels = Δf(fat-water) × FOV ÷ (BW × matrix): narrow BW and high field magnify it; it occurs along the frequency-encoding axis only.' },
        { cat: 'parameters', q: 'Increasing slice thickness causes:', options: ['Better through-plane resolution', 'More partial-volume averaging but higher SNR', 'Longer TE', 'More chemical shift'], correct: 1, exp: 'Thicker slices average more anatomy into each voxel — brighter signal but blurred boundaries (partial volume), a resolution/SNR trade.' },
        { cat: 'parameters', q: 'A rectangular (reduced phase) FOV is commonly used in:', options: ['Brain axial imaging', 'Coronal spine or axial body imaging (anatomy longer in one axis) — fewer phase steps, shorter scan', 'Finger imaging', 'Diffusion only'], correct: 1, exp: 'Sampling fewer phase steps over a shorter axis (e.g. RFOV 80%) cuts scan time — watch for wrap-around along the phase direction.' },
        { cat: 'parameters', q: 'Zero-filling k-space (k-space interpolation):', options: ['Creates true new resolution', 'Improves apparent smoothness/interpolation but adds no true detail', 'Increases SNR', 'Doubles scan time'], correct: 1, exp: 'Zero-padding interpolates between measured points — the matrix LOOKS bigger but true resolution is unchanged; useful for small-FOV/3D display.' },
        { cat: 'parameters', q: 'Increasing TR will:', options: ['Reduce scan time and increase T1 weighting', 'Increase scan time, reduce T1 weighting (more PD/T2), and allow more slices per TR', 'Shorten TE automatically', 'Always improve the image'], correct: 1, exp: 'Longer TR lets magnetization recover (less T1 contrast, better PD/T2), permits more slice encodings — but lengthens the acquisition proportionally.' },
        { cat: 'parameters', q: 'Increasing TE will:', options: ['Improve SNR', 'Increase T2 weighting while decreasing SNR (signal decays)', 'Shorten scan time', 'Suppress fat'], correct: 1, exp: 'Waiting longer samples a decayed signal — more T2 contrast, less signal; very long TEs are used deliberately for heavy T2 (MRCP, myelogram-like).' },
        { cat: 'parameters', q: 'Doubling the PHASE matrix from 256 to 512 (FOV constant) will:', options: ['Halve scan time', 'Double scan time, reduce SNR, improve in-plane resolution', 'Not affect time', 'Only affect the frequency axis'], correct: 1, exp: 'Each phase step costs a full TR repetition — doubling phase matrix doubles time; smaller pixels also lower SNR (∝ voxel volume).' },
        { cat: 'parameters', q: 'The slice-select RF bandwidth determines:', options: ['Receiver noise', 'Slice thickness (wider transmitted bandwidth = thicker slice, with the gradient fixed)', 'TE', 'Contrast weighting'], correct: 1, exp: 'Slice thickness = RF bandwidth ÷ gradient strength: a wider band excites a thicker slab (basis of variable slice thickness).' },
        { cat: 'parameters', q: 'PROPELLER / BLADE sequences reduce motion artifact by:', options: ['Filling k-space in rotating blades about the center and rejecting corrupt data', 'Increasing NEX', 'Suppressing fat', 'Shortening TR'], correct: 0, exp: 'Rotating, overlapping blades repeatedly sample central k-space — motion-corrupt data are compared and rejected/weighted, rescuing head/abdomen studies.' },
        { cat: 'parameters', q: 'The fundamental trade-off triangle of MRI states you can optimize only two of:', options: ['SNR · Spatial resolution · Scan time', 'TR · TE · TI', 'FOV · Matrix · NEX', 'T1 · T2 · PD'], correct: 0, exp: 'Improve any two at the cost of the third: fast AND high-resolution means low SNR; fast AND high-SNR means coarse voxels — every protocol navigates this triangle.' }
    ];

    var CATEGORY_LABELS = {
        physics: 'Physics', sequences: 'Sequences', cardiac: 'Cardiac',
        safety: 'Safety', parameters: 'Parameters'
    };

    /* ============================================================
       CLINICAL CASES (6)
       ============================================================ */
    var CASES = [
        { badge: 'Neuro · Acute', title: 'Sudden focal deficit',
          patient: '68-year-old male. Acute onset right arm weakness and slurred speech 2 hours ago. Non-contrast CT head: no hemorrhage, no early ischemic changes.',
          question: 'Which MRI study best confirms the diagnosis and shows the ischemic core?',
          options: ['T1-weighted spin echo pre/post gadolinium', 'DWI with ADC map', 'Susceptibility-weighted imaging (SWI)', 'Cardiac cine bSSFP'], correct: 1,
          feedback: 'Acute ischemia restricts diffusion — bright on DWI with low ADC — detectable within minutes. This is the study of choice for early infarction.' },
        { badge: 'Neuro · Demyelination', title: 'Young woman with sensory episodes',
          patient: '28-year-old female. Two episodes of transient sensory loss. Neurology suspects multiple sclerosis. Previous MRI mentioned “periventricular white matter lesions”.',
          question: 'Which sequence best demonstrates periventricular and juxtacortical demyelinating lesions?',
          options: ['T1 spin echo', 'FLAIR', 'DWI', 'STIR'], correct: 1,
          feedback: 'FLAIR suppresses the bright CSF around the ventricles, making periventricular and cortical/juxtacortical plaques far more conspicuous than on T2.' },
        { badge: 'MSK · Trauma', title: 'Twisting knee injury',
          patient: '45-year-old male, twisting injury playing football. Locked knee, joint-line tenderness, positive McMurray test. Suspected medial meniscal tear.',
          question: 'Which protocol element is most appropriate?',
          options: ['Axial T1 without fat saturation', 'Sagittal PD with fat saturation', 'Coronal SWI', 'Diffusion-weighted EPI'], correct: 1,
          feedback: 'PD fat-saturated images in the sagittal plane give excellent meniscus and cartilage detail — high-resolution fluid-sensitive imaging for internal derangement.' },
        { badge: 'Cardiac · Viability', title: 'Old infarction with new heart failure',
          patient: '60-year-old male with prior anterior MI, now LV dysfunction (EF 32%). The team must decide between revascularization and medical therapy — a viability study is requested.',
          question: 'Which study defines hibernating myocardium and scar burden?',
          options: ['T2-weighted edema imaging only', 'Late gadolinium enhancement (LGE) ± dobutamine cine', 'First-pass stress perfusion', 'Chest CT angiography'], correct: 1,
          feedback: 'LGE shows scar transmurality (thinner scar = more viable). Dobutamine cine stress assesses contractile reserve — together they guide revascularization decisions.' },
        { badge: 'MSK · Occult fracture', title: 'Ankle pain after sport',
          patient: '20-year-old athlete, inversion ankle injury. Radiographs negative but persistent pain and inability to bear weight. Clinically suspected occult fracture / bone bruise.',
          question: 'Which sequence highlights bone marrow edema best?',
          options: ['T1-weighted SE', 'STIR (or PDFS)', 'T2* GRE without fat sat', 'Phase-contrast MRA'], correct: 1,
          feedback: 'Fluid-sensitive fat-suppressed sequences (STIR / PD fat-sat) make marrow edema bright — ideal for occult fractures and bone bruises.' },
        { badge: 'Spine · Radiculopathy', title: 'Radiating leg pain',
          patient: '55-year-old female, 3 weeks of shooting pain down the left leg to the foot. Straight-leg-raise positive at 40°. Suspected disc herniation with nerve root compression.',
          question: 'Which sequence best shows the disc, the canal and the nerve roots on a sagittal plane?',
          options: ['Sagittal T2 FSE', 'Sagittal T1 without contrast', 'Axial DWI', 'Coronal STIR'], correct: 0,
          feedback: 'Sagittal T2 FSE gives a myelography-like view: bright CSF, dark disc, and excellent depiction of canal stenosis and disc extrusion.' }
    ];

    /* ============================================================
       FLASHCARDS (16) — for spaced repetition
       ============================================================ */
    var FLASHCARDS = [
        { cat: 'Parameter', term: 'TR — Repetition Time', def: 'Time between successive RF excitation pulses. Short TR (< 800 ms) → T1 weighting; long TR (> 2000 ms) → PD/T2 weighting.' },
        { cat: 'Parameter', term: 'TE — Echo Time', def: 'Time from excitation to signal readout. Short TE (< 35 ms) minimizes T2 effects; long TE (> 60 ms) creates T2 weighting.' },
        { cat: 'Parameter', term: 'TI — Inversion Time', def: 'Delay between the 180° inversion pulse and 90° excitation. Chosen to null a tissue: CSF in FLAIR (~2500 ms), fat in STIR (~160 ms).' },
        { cat: 'Parameter', term: 'Flip Angle (α)', def: 'Angle the net magnetization is tipped by the RF pulse. 90° in spin echo; variable angles in GRE control T1 vs PD weighting.' },
        { cat: 'Parameter', term: 'FOV — Field of View', def: 'Physical size of the image. Pixel = FOV ÷ matrix. Smaller FOV → higher resolution but lower SNR and possible wrap-around.' },
        { cat: 'Parameter', term: 'Matrix', def: 'Number of frequency × phase encoding steps. Larger matrix → better resolution, lower SNR, longer scan time (phase steps cost TR repeats).' },
        { cat: 'Parameter', term: 'NEX / NSA', def: 'Number of signal averages. SNR improves as √NEX; scan time increases linearly with NEX.' },
        { cat: 'Parameter', term: 'ETL — Echo Train Length', def: 'Echoes collected per TR in FSE/TSE. Longer ETL → faster scan but more blur in the phase-encode direction.' },
        { cat: 'Parameter', term: 'Receiver Bandwidth', def: 'Frequency range sampled per pixel. Narrow BW → higher SNR, more chemical shift; wide BW → less metal artifact, shorter TE.' },
        { cat: 'Physics', term: 'Larmor Frequency', def: 'Precession frequency of protons: f = 42.58 MHz/T × B0. 1.5 T → 63.9 MHz; 3 T → 127.7 MHz. Sets the RF transmit frequency.' },
        { cat: 'Physics', term: 'K-space', def: 'Raw data matrix of spatial frequencies. Center = contrast/signal; periphery = detail and edges. Filled by frequency/phase encoding.' },
        { cat: 'Physics', term: 'T1 Relaxation', def: 'Recovery of longitudinal magnetization (spin–lattice). Fat recovers fast (bright on T1); water slowly (dark on T1).' },
        { cat: 'Physics', term: 'T2 Relaxation', def: 'Decay of transverse magnetization from spin–spin dephasing. Water retains signal → bright on T2. T2 ≤ T2*.' },
        { cat: 'Clinical', term: 'DWI & ADC', def: 'Restricted diffusion (stroke, cellular tumors) is bright on DWI with LOW ADC. ADC distinguishes true restriction from “T2 shine-through”.' },
        { cat: 'Safety', term: 'SAR', def: 'Specific Absorption Rate — RF power deposited per kg of tissue (W/kg). Depends on flip angle, TR and patient size; monitored by the system.' },
        { cat: 'Safety', term: 'ACR Zones I–IV', def: 'I public → II interface → III controlled (fringe field) → IV scanner room. Screening happens moving from II to III/IV; Zone IV access strictly controlled.' }
    ];

    /* ============================================================
       MODE SWITCHING
       ============================================================ */
    var modes = ['mcq', 'cases', 'flashcards', 'exam'];
    var modeSections = { mcq: 'mode-mcq', cases: 'mode-cases', flashcards: 'mode-flashcards', exam: 'mode-exam' };

    window.setMode = function (mode) {
        modes.forEach(function (m) {
            var sec = $(modeSections[m]);
            if (sec) sec.style.display = (m === mode) ? '' : 'none';
        });
        document.querySelectorAll('.mode-tab-btn').forEach(function (b) {
            b.classList.remove('active');
        });
        var activeBtn = document.querySelector('.mode-tab-btn[onclick*="' + mode + '"]');
        if (activeBtn) activeBtn.classList.add('active');
        if (mode !== 'exam') examCleanup();
    };

    /* ============================================================
       MCQ PRACTICE ENGINE
       ============================================================ */
    var currentCategory = 'all';
    var quizPool = [];
    var qIndex = 0;
    var score = 0;
    var answered = 0;
    var catStats = {};

    function poolForCategory(cat) {
        var src = cat === 'all' ? QUESTIONS : QUESTIONS.filter(function (q) { return q.cat === cat; });
        return shuffle(src).slice(0, Math.min(10, src.length));
    }

    window.filterQuizCategory = function (cat) {
        currentCategory = cat;
        document.querySelectorAll('.cat-pill').forEach(function (p) { p.classList.remove('active'); });
        var pill = document.querySelector('.cat-pill[onclick*="' + cat + '"]');
        if (pill) pill.classList.add('active');
        startQuiz();
    };

    function startQuiz() {
        quizPool = poolForCategory(currentCategory);
        qIndex = 0; score = 0; answered = 0; catStats = {};
        if ($('quizSummaryCard')) $('quizSummaryCard').style.display = 'none';
        if ($('quizContainer')) $('quizContainer').style.display = '';
        renderQuestion();
    }
    window.restartQuiz = startQuiz;

    function renderQuestion() {
        if (qIndex >= quizPool.length) { showSummary(); return; }
        var q = quizPool[qIndex];
        $('qCurrent').textContent = qIndex + 1;
        $('qTotal').textContent = quizPool.length;
        $('qCategoryBadge').textContent = CATEGORY_LABELS[q.cat] || q.cat;
        $('qCurrentScore').textContent = score;
        $('qAnswered').textContent = answered;
        $('qProgressFill').style.width = Math.max(Math.round((qIndex / quizPool.length) * 100), 8) + '%';
        $('qQuestionText').textContent = q.q;

        var list = $('qOptionsList');
        list.innerHTML = '';
        var letters = ['A', 'B', 'C', 'D'];
        q.options.forEach(function (opt, i) {
            var btn = document.createElement('button');
            btn.className = 'quiz-opt-btn';
            btn.innerHTML = '<span class="opt-letter">' + letters[i] + '</span><span>' + opt + '</span>';
            btn.addEventListener('click', function () { answer(i, btn); });
            list.appendChild(btn);
        });
        $('qExplanationBox').style.display = 'none';
        $('btnNextQuestion').style.display = 'none';
    }

    function answer(i, btn) {
        var q = quizPool[qIndex];
        var buttons = $('qOptionsList').querySelectorAll('.quiz-opt-btn');
        buttons.forEach(function (b) { b.disabled = true; });
        var correct = i === q.correct;
        if (correct) { btn.classList.add('correct'); score++; }
        else { btn.classList.add('incorrect'); buttons[q.correct].classList.add('correct'); }
        answered++;
        if (!catStats[q.cat]) catStats[q.cat] = { c: 0, t: 0 };
        catStats[q.cat].t++;
        if (correct) catStats[q.cat].c++;
        $('qCurrentScore').textContent = score;
        $('qAnswered').textContent = answered;

        var box = $('qExplanationBox');
        $('expHeader').innerHTML = correct
            ? '<i class="fas fa-check-circle"></i> <strong>Correct!</strong>'
            : '<i class="fas fa-times-circle"></i> <strong>Not quite</strong>';
        $('expText').textContent = q.exp;
        box.style.display = '';
        $('qProgressFill').style.width = Math.round(((qIndex + 1) / quizPool.length) * 100) + '%';
        $('btnNextQuestion').style.display = '';
        $('btnNextQuestion').innerHTML = (qIndex + 1 >= quizPool.length)
            ? 'See Results <i class="fas fa-flag-checkered"></i>'
            : 'Next Question <i class="fas fa-arrow-right"></i>';
    }

    window.nextQuestion = function () {
        qIndex++;
        if (qIndex >= quizPool.length) showSummary();
        else renderQuestion();
    };

    function showSummary() {
        $('quizContainer').style.display = 'none';
        var card = $('quizSummaryCard');
        card.style.display = '';
        var pct = quizPool.length ? Math.round((score / quizPool.length) * 100) : 0;
        var icon = $('summaryIcon');
        icon.className = 'summary-icon';
        if (pct >= 80) { icon.classList.add('pass'); icon.innerHTML = '<i class="fas fa-trophy"></i>'; $('summaryGrade').textContent = 'Excellent Performance!'; }
        else if (pct >= 50) { icon.classList.add('warn'); icon.innerHTML = '<i class="fas fa-medal"></i>'; $('summaryGrade').textContent = 'Good Effort — Keep Going!'; }
        else { icon.classList.add('fail'); icon.innerHTML = '<i class="fas fa-book-open"></i>'; $('summaryGrade').textContent = 'Time to Review the Material'; }
        $('summaryScoreLarge').textContent = pct + '%';
        $('summaryMessage').textContent = 'You answered ' + score + ' out of ' + quizPool.length + ' questions correctly.';

        var bd = $('summaryBreakdown');
        bd.innerHTML = '';
        Object.keys(catStats).forEach(function (cat) {
            var s = catStats[cat];
            var row = document.createElement('div');
            row.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:10px;';
            row.innerHTML = '<span style="font-size:0.9rem;color:var(--text-dim);"><i class="fas fa-tag" style="color:var(--blue);margin-right:8px;"></i>' +
                (CATEGORY_LABELS[cat] || cat) + '</span>' +
                '<strong style="color:' + (s.c === s.t ? 'var(--green)' : 'var(--yellow)') + ';">' + s.c + ' / ' + s.t + '</strong>';
            bd.appendChild(row);
        });
    }

    /* ============================================================
       CLINICAL CASES
       ============================================================ */
    var caseIndex = 0;
    var caseScore = 0;

    function renderCase() {
        var c = CASES[caseIndex];
        var card = $('caseCard');
        card.classList.add('revealed');
        card.innerHTML =
            '<div class="clinical-case-card">' +
              '<span class="case-badge">Case ' + (caseIndex + 1) + ' / ' + CASES.length + ' — ' + c.badge + '</span>' +
              '<h3 style="font-size:1.3rem;margin:6px 0 0;">' + c.title + '</h3>' +
              '<div class="case-patient-banner"><i class="fas fa-user" style="color:var(--teal);margin-right:8px;"></i>' + c.patient + '</div>' +
              '<p class="case-question-text"><strong>' + c.question + '</strong></p>' +
              '<div class="case-options-list" id="caseOptionsList"></div>' +
              '<div id="caseFeedbackWrap"></div>' +
            '</div>';

        var list = card.querySelector('#caseOptionsList');
        var wrap = card.querySelector('#caseFeedbackWrap');
        c.options.forEach(function (opt, i) {
            var btn = document.createElement('button');
            btn.className = 'case-opt-btn';
            btn.innerHTML = '<span class="c-opt-num">' + (i + 1) + '</span><span>' + opt + '</span>';
            btn.addEventListener('click', function () { answerCase(i, btn, wrap, list); });
            list.appendChild(btn);
        });
    }

    function answerCase(i, btn, wrap, list) {
        var c = CASES[caseIndex];
        var buttons = list.querySelectorAll('.case-opt-btn');
        buttons.forEach(function (b) { b.disabled = true; });
        var correct = i === c.correct;
        if (correct) { btn.classList.add('correct'); caseScore++; }
        else { btn.classList.add('incorrect'); buttons[c.correct].classList.add('correct'); }

        var fb = document.createElement('div');
        fb.className = 'case-feedback-box ' + (correct ? 'fb-correct' : 'fb-incorrect');
        fb.innerHTML =
            '<strong style="display:block;margin-bottom:6px;color:' + (correct ? 'var(--green)' : 'var(--red)') + ';">' +
            (correct ? '<i class="fas fa-check-circle"></i> Correct decision' : '<i class="fas fa-times-circle"></i> Suboptimal choice') + '</strong>' +
            c.feedback + '<div style="margin-top:12px;font-size:0.8rem;color:var(--text-muted);">Cases answered correctly: ' + caseScore + '</div>';
        wrap.appendChild(fb);

        var next = document.createElement('button');
        next.className = 'btn btn-primary';
        next.style.marginTop = '18px';
        next.innerHTML = (caseIndex + 1 >= CASES.length) ? 'Restart Cases <i class="fas fa-rotate-left"></i>' : 'Next Case <i class="fas fa-arrow-right"></i>';
        next.addEventListener('click', function () {
            caseIndex++;
            if (caseIndex >= CASES.length) { caseIndex = 0; caseScore = 0; }
            renderCase();
        });
        wrap.appendChild(next);
    }

    /* ============================================================
       SPACED-REPETITION FLASHCARDS
       ============================================================ */
    var SR_KEY = 'seenmri-sr';
    var srBoxes = {};
    try { srBoxes = JSON.parse(load(SR_KEY) || '{}') || {}; } catch (e) { srBoxes = {}; }
    var srQueue = [];       /* indices into FLASHCARDS */
    var srPos = 0;
    var srFlipped = false;
    var srSessionDone = 0;
    var srSessionTotal = 0;

    function saveSR() { store(SR_KEY, JSON.stringify(srBoxes)); }

    function boxOf(i) { return srBoxes[i] || 1; }

    function buildQueue() {
        /* unseen + lowest boxes first, then higher boxes; shuffle within groups */
        var unseen = [], byBox = { 1: [], 2: [], 3: [], 4: [], 5: [] };
        FLASHCARDS.forEach(function (fc, i) {
            if (srBoxes[i]) byBox[srBoxes[i]].push(i); else unseen.push(i);
        });
        srQueue = [];
        [1, 2, 3, 4, 5].forEach(function (b) { srQueue = srQueue.concat(shuffle(byBox[b])); });
        srQueue = shuffle(unseen).concat(srQueue);   /* new cards first */
        srPos = 0;
        srSessionTotal = srQueue.length;
        srSessionDone = 0;
    }

    function masteredPct() {
        var m = 0;
        FLASHCARDS.forEach(function (fc, i) { if (boxOf(i) >= 4) m++; });
        return Math.round((m / FLASHCARDS.length) * 100);
    }

    function renderSR() {
        if (srPos >= srQueue.length) {
            buildQueue();
        }
        var i = srQueue[srPos];
        var fc = FLASHCARDS[i];
        srFlipped = false;
        var card = $('srCard');
        card.classList.remove('flipped');

        $('srPos').textContent = srSessionDone + 1;
        $('srTotal').textContent = srSessionTotal;
        $('srBox').textContent = boxOf(i);
        $('srMastered').textContent = masteredPct() + '%';
        $('srCatTag').textContent = fc.cat;
        $('srTerm').textContent = fc.term;
        $('srDef').textContent = fc.def;
        $('srActions').classList.remove('visible');
    }

    function srFlip() {
        if (srPos >= srQueue.length) return;
        srFlipped = !srFlipped;
        $('srCard').classList.toggle('flipped', srFlipped);
        if (srFlipped) $('srActions').classList.add('visible');
    }

    function srRate(got) {
        var i = srQueue[srPos];
        if (got) {
            srBoxes[i] = Math.min(5, boxOf(i) + 1);
            srPos++;
            srSessionDone++;
        } else {
            srBoxes[i] = 1;
            /* push this card back into the queue a few positions later */
            var insertAt = Math.min(srPos + 3 + Math.floor(Math.random() * 3), srQueue.length);
            srQueue.splice(insertAt, 0, i);
            srPos++;
            srSessionDone++;
        }
        saveSR();
        renderSR();
    }

    function initSR() {
        if (!$('srCard')) return;
        buildQueue();
        renderSR();
        $('srCard').addEventListener('click', srFlip);
        $('srAgain').addEventListener('click', function (e) { e.stopPropagation(); if (srFlipped) srRate(false); });
        $('srGot').addEventListener('click', function (e) { e.stopPropagation(); if (srFlipped) srRate(true); });

        $('srBrowse').addEventListener('click', function () {
            var grid = $('flashcardsGrid');
            var showing = grid.style.display !== 'none';
            grid.style.display = showing ? 'none' : '';
            this.innerHTML = showing
                ? '<i class="fas fa-table-cells"></i> Browse all cards as grid'
                : '<i class="fas fa-eye-slash"></i> Hide card browser';
            if (!showing) renderBrowseGrid();
        });

        $('srReset').addEventListener('click', function () {
            srBoxes = {};
            saveSR();
            buildQueue();
            renderSR();
        });

        /* keyboard: space = flip, 1 = again, 2 = got it */
        document.addEventListener('keydown', function (e) {
            var flashVisible = $('mode-flashcards') && $('mode-flashcards').style.display !== 'none';
            if (!flashVisible) return;
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
            if (e.code === 'Space') { e.preventDefault(); srFlip(); }
            else if (e.key === '1' && srFlipped) srRate(false);
            else if (e.key === '2' && srFlipped) srRate(true);
        });
    }

    function renderBrowseGrid() {
        var grid = $('flashcardsGrid');
        grid.innerHTML = '';
        FLASHCARDS.forEach(function (fc, i) {
            var card = document.createElement('div');
            card.className = 'flashcard-3d';
            card.innerHTML =
                '<div class="fc-inner">' +
                  '<div class="fc-front">' +
                    '<span class="fc-tag">' + fc.cat + ' · Box ' + boxOf(i) + '</span>' +
                    '<h3>' + fc.term + '</h3>' +
                    '<span class="fc-hint"><i class="fas fa-hand-pointer"></i> Click to flip</span>' +
                  '</div>' +
                  '<div class="fc-back">' +
                    '<span class="fc-tag back-tag">Definition</span>' +
                    '<p>' + fc.def + '</p>' +
                    '<span class="fc-hint">Click to flip back</span>' +
                  '</div>' +
                '</div>';
            card.addEventListener('click', function () { card.classList.toggle('flipped'); });
            grid.appendChild(card);
        });
    }

    /* ============================================================
       TIMED EXAM MODE
       ============================================================ */
    var exam = { active: false, questions: [], answers: [], idx: 0, timeLeft: 0, timerId: null, length: 20 };
    var EXAM_BEST_KEY = 'seenmri-exam-best';

    document.querySelectorAll('.exam-len-btn').forEach(function (b) {
        b.addEventListener('click', function () {
            document.querySelectorAll('.exam-len-btn').forEach(function (x) { x.classList.remove('active'); });
            b.classList.add('active');
            exam.length = parseInt(b.getAttribute('data-len'), 10) || 20;
        });
    });

    function updateBest() {
        var best = load(EXAM_BEST_KEY);
        $('examBest').innerHTML = best
            ? '<i class="fas fa-crown"></i> Your best exam score: <strong>' + best + '%</strong>'
            : '<i class="fas fa-crown"></i> No exam taken yet — set your first record!';
    }

    function startExam() {
        exam.questions = shuffle(QUESTIONS).slice(0, exam.length);
        exam.answers = new Array(exam.questions.length).fill(null);
        exam.idx = 0;
        exam.timeLeft = exam.length * 60;      /* 60 s per question */
        exam.active = true;

        $('examSetup').style.display = 'none';
        $('examSummary').style.display = 'none';
        $('examContainer').style.display = '';
        $('exTotal').textContent = exam.questions.length;

        clearInterval(exam.timerId);
        exam.timerId = setInterval(function () {
            exam.timeLeft--;
            renderTimer();
            if (exam.timeLeft <= 0) submitExam(true);
        }, 1000);

        renderExamQuestion();
        renderNavigator();
        renderTimer();
    }

    function fmtTime(s) {
        var m = Math.floor(s / 60), r = s % 60;
        return m + ':' + (r < 10 ? '0' : '') + r;
    }

    function renderTimer() {
        var el = $('exTimer');
        $('exTimerText').textContent = fmtTime(Math.max(0, exam.timeLeft));
        el.classList.remove('warn', 'danger');
        if (exam.timeLeft < 120) el.classList.add('danger');
        else if (exam.timeLeft < 300) el.classList.add('warn');
    }

    function renderExamQuestion() {
        var q = exam.questions[exam.idx];
        $('exCurrent').textContent = exam.idx + 1;
        $('exQuestionText').textContent = q.q;
        $('exProgressFill').style.width = Math.round(((exam.idx + 1) / exam.questions.length) * 100) + '%';

        var list = $('exOptionsList');
        list.innerHTML = '';
        var letters = ['A', 'B', 'C', 'D'];
        q.options.forEach(function (opt, i) {
            var btn = document.createElement('button');
            btn.className = 'quiz-opt-btn' + (exam.answers[exam.idx] === i ? ' selected' : '');
            btn.innerHTML = '<span class="opt-letter">' + letters[i] + '</span><span>' + opt + '</span>';
            btn.addEventListener('click', function () {
                exam.answers[exam.idx] = i;
                list.querySelectorAll('.quiz-opt-btn').forEach(function (b) { b.classList.remove('selected'); });
                btn.classList.add('selected');
                renderNavigator();
            });
            list.appendChild(btn);
        });

        $('exPrev').disabled = exam.idx === 0;
        $('exNext').innerHTML = (exam.idx + 1 >= exam.questions.length)
            ? 'Finish <i class="fas fa-flag-checkered"></i>'
            : 'Next <i class="fas fa-arrow-right"></i>';
    }

    function renderNavigator() {
        var nav = $('exNavigator');
        nav.innerHTML = '';
        exam.questions.forEach(function (q, i) {
            var b = document.createElement('button');
            b.className = 'ex-nav-dot' + (i === exam.idx ? ' current' : '') + (exam.answers[i] !== null ? ' answered' : '');
            b.textContent = i + 1;
            b.title = exam.answers[i] !== null ? 'Answered' : 'Not answered';
            b.addEventListener('click', function () { exam.idx = i; renderExamQuestion(); renderNavigator(); });
            nav.appendChild(b);
        });
    }

    function submitExam(timedOut) {
        if (!exam.active) return;
        exam.active = false;
        clearInterval(exam.timerId);
        examCleanup();

        var correctCount = 0;
        var byCat = {};
        exam.questions.forEach(function (q, i) {
            var ok = exam.answers[i] === q.correct;
            if (ok) correctCount++;
            if (!byCat[q.cat]) byCat[q.cat] = { c: 0, t: 0 };
            byCat[q.cat].t++;
            if (ok) byCat[q.cat].c++;
        });

        var pct = Math.round((correctCount / exam.questions.length) * 100);

        /* persist best */
        var best = parseInt(load(EXAM_BEST_KEY) || '0', 10);
        if (pct > best) {
            store(EXAM_BEST_KEY, String(pct));
            if (window.toast) window.toast('New personal best: ' + pct + '%!', 'success');
        }

        $('examContainer').style.display = 'none';
        var sum = $('examSummary');
        sum.style.display = '';

        var icon = $('exSummaryIcon');
        icon.className = 'summary-icon';
        if (pct >= 80) { icon.classList.add('pass'); icon.innerHTML = '<i class="fas fa-trophy"></i>'; $('exSummaryGrade').textContent = 'Certification Level — Passed!'; }
        if (pct >= 80 && typeof window.celebrate === 'function') window.celebrate();
        else if (pct >= 60) { icon.classList.add('warn'); icon.innerHTML = '<i class="fas fa-medal"></i>'; $('exSummaryGrade').textContent = 'Close — Solid Foundation'; }
        else { icon.classList.add('fail'); icon.innerHTML = '<i class="fas fa-book-open"></i>'; $('exSummaryGrade').textContent = 'Keep Studying — Review Below'; }

        $('exScoreLarge').textContent = pct + '%';
        $('exSummaryMessage').textContent =
            (timedOut ? 'Time expired! ' : '') + correctCount + ' / ' + exam.questions.length + ' correct' +
            (best && pct <= best ? ' · Best: ' + best + '%' : ' · New personal best! 🎉');

        /* breakdown */
        var bd = $('exBreakdown');
        bd.innerHTML = '';
        Object.keys(byCat).forEach(function (cat) {
            var s = byCat[cat];
            var pctC = Math.round((s.c / s.t) * 100);
            var row = document.createElement('div');
            row.style.cssText = 'display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:var(--bg);border:1px solid var(--border);border-radius:10px;';
            row.innerHTML = '<span style="font-size:0.9rem;color:var(--text-dim);"><i class="fas fa-tag" style="color:var(--blue);margin-right:8px;"></i>' +
                (CATEGORY_LABELS[cat] || cat) + '</span>' +
                '<strong style="color:' + (pctC >= 70 ? 'var(--green)' : pctC >= 40 ? 'var(--yellow)' : 'var(--red)') + ';">' + s.c + ' / ' + s.t + ' (' + pctC + '%)</strong>';
            bd.appendChild(row);
        });

        /* full review */
        var review = $('examReview');
        review.innerHTML = '<h3 class="review-title"><i class="fas fa-list-check"></i> Question Review</h3>';
        exam.questions.forEach(function (q, i) {
            var userAns = exam.answers[i];
            var ok = userAns === q.correct;
            var letters = ['A', 'B', 'C', 'D'];
            var item = document.createElement('div');
            item.className = 'review-item ' + (ok ? 'ok' : 'bad');
            item.innerHTML =
                '<div class="review-q">' +
                    '<span class="review-badge">' + (ok ? '<i class="fas fa-check"></i>' : '<i class="fas fa-xmark"></i>') + ' Q' + (i + 1) + '</span>' +
                    q.q +
                '</div>' +
                '<div class="review-answers">' +
                    (userAns !== null
                        ? '<span class="' + (ok ? 'rev-ok' : 'rev-bad') + '">Your answer: ' + letters[userAns] + '. ' + q.options[userAns] + '</span>'
                        : '<span class="rev-bad">Not answered</span>') +
                    (ok ? '' : '<span class="rev-ok">Correct: ' + letters[q.correct] + '. ' + q.options[q.correct] + '</span>') +
                '</div>' +
                '<p class="review-exp">' + q.exp + '</p>';
            review.appendChild(item);
        });
    }

    function examCleanup() {
        clearInterval(exam.timerId);
    }

    $('examStart').addEventListener('click', startExam);
    $('exSubmitTop').addEventListener('click', function () { submitExam(false); });
    $('exPrev').addEventListener('click', function () {
        if (exam.idx > 0) { exam.idx--; renderExamQuestion(); renderNavigator(); }
    });
    $('exNext').addEventListener('click', function () {
        if (exam.idx + 1 < exam.questions.length) { exam.idx++; renderExamQuestion(); renderNavigator(); }
        else submitExam(false);
    });
    $('exRetake').addEventListener('click', function () {
        $('examSummary').style.display = 'none';
        $('examSetup').style.display = '';
        updateBest();
    });
    $('exBackSetup').addEventListener('click', function () {
        $('examSummary').style.display = 'none';
        $('examSetup').style.display = '';
        updateBest();
    });

    /* ============================================================
       INIT
       ============================================================ */
    function init() {
        var allCount = $('count-all');
        if (allCount) allCount.textContent = QUESTIONS.length;
        startQuiz();
        renderCase();
        initSR();
        updateBest();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    /* deep links: quiz.html#cases / #exam / #flashcards */
    var hash = (location.hash || '').replace('#', '');
    if (['cases', 'exam', 'flashcards', 'mcq'].indexOf(hash) !== -1) {
        setMode(hash);
    }
})();
