/* ============================================================
   SEENmri — mri-kit.js
   Shared teaching kit: connection path · compare slider ·
   consequence controls. Drop on any page; no extra layout.
   ============================================================ */
(function () {
    'use strict';

    var NODES = [
        { id: 'patient',  label: 'Patient',  href: 'preparation.html', icon: 'fa-user' },
        { id: 'magnet',   label: 'Magnet',   href: 'about-mri.html#physics', icon: 'fa-magnet' },
        { id: 'pulse',    label: 'Pulse',    href: 'components.html',  icon: 'fa-bolt' },
        { id: 'contrast', label: 'T1 / T2',  href: 'about-mri.html#t1t2', icon: 'fa-adjust' },
        { id: 'sequence', label: 'Sequence', href: 'sequences.html',   icon: 'fa-layer-group' },
        { id: 'knobs',    label: 'Knobs',    href: 'parameters.html',  icon: 'fa-sliders-h' },
        { id: 'image',    label: 'Image',    href: 'scan-atlas.html',  icon: 'fa-images' },
        { id: 'body',     label: 'Body',     href: 'body-parts.html',  icon: 'fa-lungs' },
        { id: 'safety',   label: 'Safety',   href: 'safety.html',      icon: 'fa-shield-halved' }
    ];

    var PAGE_NODE = {
        'index.html':          '',
        'preparation.html':    'patient',
        'about-mri.html':      'magnet',
        'components.html':     'pulse',
        'sequences.html':      'sequence',
        'parameters.html':     'knobs',
        'scan-atlas.html':     'image',
        'body-parts.html':     'body',
        'cardiac-mri.html':    'body',
        'safety.html':         'safety',
        'simulator.html':      'knobs',
        'quiz.html':           'image',
        'resources.html':      ''
    };

    function fileName() {
        var p = (location.pathname || '').split('/').pop() || 'index.html';
        if (!p || p.indexOf('.') === -1) return 'index.html';
        return p;
    }

    function currentId() {
        var forced = document.body && document.body.getAttribute('data-mri-node');
        if (forced) return forced;
        var file = fileName();
        var hash = (location.hash || '').replace(/^#/, '');
        if (file === 'about-mri.html') {
            if (hash === 't1t2' || hash === 'decayCanvas') return 'contrast';
            return 'magnet';
        }
        var id = PAGE_NODE[file];
        return id == null ? '' : id;
    }

    function paintPath() {
        var ol = document.querySelector('.mri-path-line');
        if (!ol) return;
        var now = currentId();
        var nowIndex = -1;
        NODES.forEach(function (n, i) { if (n.id === now) nowIndex = i; });
        Array.prototype.forEach.call(ol.children, function (li, i) {
            var state = 'is-next';
            if (nowIndex < 0) state = 'is-idle';
            else if (i < nowIndex) state = 'is-done';
            else if (i === nowIndex) state = 'is-now';
            li.className = state;
            var a = li.querySelector('a');
            if (!a) return;
            if (state === 'is-now') a.setAttribute('aria-current', 'page');
            else a.removeAttribute('aria-current');
        });
    }

    function mountPath() {
        if (!document.body) return;
        if (document.body.classList.contains('workstation-body')) return;
        if (document.querySelector('.mri-path')) return;

        var now = currentId();
        var nowIndex = -1;
        NODES.forEach(function (n, i) { if (n.id === now) nowIndex = i; });

        var nav = document.createElement('nav');
        nav.className = 'mri-path';
        nav.setAttribute('aria-label', 'How MRI connects');

        var kicker = document.createElement('p');
        kicker.className = 'mri-path-kicker';
        kicker.textContent = 'How MRI connects';
        nav.appendChild(kicker);

        var ol = document.createElement('ol');
        ol.className = 'mri-path-line';

        NODES.forEach(function (n, i) {
            var li = document.createElement('li');
            var state = 'is-next';
            if (nowIndex < 0) state = 'is-idle';
            else if (i < nowIndex) state = 'is-done';
            else if (i === nowIndex) state = 'is-now';
            li.className = state;

            var a = document.createElement('a');
            a.href = n.href;
            if (state === 'is-now') a.setAttribute('aria-current', 'page');
            a.innerHTML = '<i class="fas ' + n.icon + '" aria-hidden="true"></i><span>' + n.label + '</span>';
            li.appendChild(a);
            ol.appendChild(li);
        });

        nav.appendChild(ol);
        document.body.classList.add('mri-kit-on');
        var bar = document.getElementById('navbar') || document.querySelector('.navbar');
        if (bar) bar.appendChild(nav);
        else document.body.insertBefore(nav, document.body.firstChild);

        var here = ol.querySelector('.is-now');
        if (here && here.scrollIntoView) {
            try { here.scrollIntoView({ inline: 'center', block: 'nearest', behavior: 'instant' }); }
            catch (e) { here.scrollIntoView(false); }
        }
    }

    function mountCompare(root) {
        if (!root) return;
        var wrap = typeof root === 'string' ? document.querySelector(root) : root;
        if (!wrap || wrap.getAttribute('data-mri-ready')) return;
        var b = wrap.querySelector('.mri-compare-b');
        var range = wrap.querySelector('.mri-compare-range');
        if (!b || !range) return;
        wrap.setAttribute('data-mri-ready', '1');

        function paint() {
            var v = Number(range.value);
            b.style.clipPath = 'inset(0 ' + (100 - v) + '% 0 0)';
            wrap.style.setProperty('--split', v + '%');
        }
        range.addEventListener('input', paint);
        paint();
    }

    function mountAllCompares() {
        document.querySelectorAll('.mri-compare').forEach(mountCompare);
    }

    /* Generic consequence panel:
       root [data-mri-conseq]
         .mri-conseq-meters [data-meter="snr|time|detail|sar"]
         .mri-conseq-pay
         input[data-conseq]  (range/select)
       opts.render(state, root)
       opts.meters(state) -> {snr, time, detail, sar} 0..1
       opts.pay(state) -> string
    */
    function conseq(root, opts) {
        opts = opts || {};
        var el = typeof root === 'string' ? document.querySelector(root) : root;
        if (!el) return null;

        function readState() {
            var s = {};
            el.querySelectorAll('[data-conseq]').forEach(function (inp) {
                var key = inp.getAttribute('data-conseq');
                s[key] = inp.type === 'range' || inp.type === 'number'
                    ? Number(inp.value)
                    : inp.value;
            });
            return s;
        }

        function setMeter(name, t) {
            var m = el.querySelector('[data-meter="' + name + '"]');
            if (!m) return;
            t = Math.max(0, Math.min(1, t));
            var fill = m.querySelector('.mri-meter-fill');
            if (fill) fill.style.width = Math.round(t * 100) + '%';
            m.setAttribute('data-level', t < 0.34 ? 'low' : t < 0.67 ? 'mid' : 'high');
        }

        function tick() {
            var state = readState();
            if (typeof opts.render === 'function') opts.render(state, el);
            var meters = typeof opts.meters === 'function' ? opts.meters(state) : {};
            Object.keys(meters).forEach(function (k) { setMeter(k, meters[k]); });
            var pay = el.querySelector('.mri-conseq-pay');
            if (pay && typeof opts.pay === 'function') pay.textContent = opts.pay(state) || '';
        }

        el.querySelectorAll('[data-conseq]').forEach(function (inp) {
            inp.addEventListener('input', tick);
            inp.addEventListener('change', tick);
        });
        tick();
        return { update: tick, state: readState };
    }

    var Kit = {
        nodes: NODES,
        current: currentId,
        mountPath: mountPath,
        compare: mountCompare,
        conseq: conseq
    };
    window.MRIKit = Kit;

    function boot() {
        mountPath();
        mountAllCompares();
        window.addEventListener('hashchange', paintPath);
        window.addEventListener('popstate', paintPath);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();
})();
