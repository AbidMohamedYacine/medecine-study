/* ============================================================
   SEENmri — param-lab.js
   Parameters “drive it” studio: change a knob, watch SNR,
   sharpness, time, contrast and wrap move together.
   ============================================================ */
(function () {
    'use strict';

    var root = document.getElementById('driveLab');
    if (!root) return;

    var canvas = document.getElementById('driveCanvas');
    var ctx = canvas && canvas.getContext('2d');
    if (!canvas || !ctx) return;

    var imgT1 = new Image();
    var imgT2 = new Image();
    var readyT1 = false;
    var readyT2 = false;
    imgT1.onload = function () { readyT1 = true; requestRender(); };
    imgT2.onload = function () { readyT2 = true; requestRender(); };
    imgT1.src = 'images/atlas/brain-t1.jpg';
    imgT2.src = 'images/atlas/brain-t2.jpg';

    var lastKey = 'tr';
    var raf = 0;
    var off = document.createElement('canvas');
    var ox = off.getContext('2d');
    var noiseCv = document.createElement('canvas');
    var nx = noiseCv.getContext('2d');
    var noiseBuilt = 0;

    var BASE = { tr: 600, te: 15, fov: 230, matrix: 256, thick: 4, nex: 1 };
    var ETL = 16;

    function readState() {
        var s = {};
        root.querySelectorAll('[data-conseq]').forEach(function (inp) {
            s[inp.getAttribute('data-conseq')] = Number(inp.value);
        });
        return s;
    }

    function scores(state) {
        var pixel = state.fov / state.matrix;
        var voxel = pixel * pixel * state.thick;
        var snr = voxel * Math.sqrt(state.nex) * Math.exp(-state.te / 85) * (1 - Math.exp(-state.tr / 900));
        var snrN = Math.max(0.08, Math.min(1, snr / 18));
        var resN = Math.max(0.08, Math.min(1, 1.15 / (pixel * Math.sqrt(state.thick / 3))));
        var timeSec = (state.tr / 1000) * state.matrix * state.nex / ETL;
        var speedN = Math.max(0.08, Math.min(1, 25 / Math.max(6, timeSec)));
        var t1w = Math.max(0, Math.min(1, (1100 - state.tr) / 800));
        var t2w = Math.max(0, Math.min(1, (state.te - 12) / 90)) * (state.tr > 1200 ? 1 : 0.25);
        return {
            snr: snrN,
            detail: resN,
            speed: speedN,
            timeSec: timeSec,
            pixel: pixel,
            t1w: t1w,
            t2w: t2w,
            wrap: state.fov < 198,
            mix: t2w / (t1w + t2w + 0.2)
        };
    }

    function weighting(sc) {
        if (sc.mix > 0.55) return 'T2-weighted';
        if (sc.t1w > 0.55 && sc.mix < 0.28) return 'T1-weighted';
        return 'Mixed / PD-leaning';
    }

    function payLine(state, sc) {
        var k = lastKey;
        if (k === 'tr') {
            return state.tr < 900
                ? 'Short TR → T1 contrast. Scan is quicker; T2 contrast is gone.'
                : 'Long TR → T2 can appear and SNR rises. Time paid.';
        }
        if (k === 'te') {
            return state.te > 50
                ? 'Long TE → T2 contrast (fluid bright). Signal paid — noisier, darker.'
                : 'Short TE → less T2 decay. Fluid stays darker; SNR is protected.';
        }
        if (k === 'fov') {
            if (state.fov < 198) return 'FOV smaller than the head → wrap-around. Sharpness rose; anatomy folds over itself.';
            if (state.fov > 260) return 'Large FOV → more SNR, less wrap. Detail paid — pixels got bigger.';
            return 'FOV sets pixel size. Smaller FOV sharpens, but wrap and noise wait.';
        }
        if (k === 'matrix') {
            return state.matrix > 320
                ? 'Higher matrix → sharper. SNR and time paid (smaller voxels, more phase steps).'
                : 'Lower matrix → faster and brighter. Detail paid.';
        }
        if (k === 'thick') {
            return state.thick > 5
                ? 'Thicker slice → more SNR. Through-plane detail paid (partial volume).'
                : 'Thin slice → less partial volume. SNR paid.';
        }
        if (k === 'nex') {
            return state.nex > 1
                ? 'More averages → quieter image (SNR ∝ √NEX). Time paid 1:1 with NEX.'
                : 'Single average → shortest time. Noise is the price.';
        }
        var worst = sc.snr <= sc.detail && sc.snr <= sc.speed ? 'SNR'
            : sc.detail <= sc.speed ? 'detail' : 'time';
        return 'You cannot max SNR, detail and speed together. Right now ' + worst + ' is paying.';
    }

    function setMeter(name, t) {
        var m = root.querySelector('[data-meter="' + name + '"]');
        if (!m) return;
        t = Math.max(0, Math.min(1, t));
        var fill = m.querySelector('.mri-meter-fill');
        if (fill) fill.style.width = Math.round(t * 100) + '%';
        m.setAttribute('data-level', t < 0.34 ? 'low' : t < 0.67 ? 'mid' : 'high');
    }

    function placeDot(sc) {
        var dot = document.getElementById('driveTriDot');
        if (!dot) return;
        var s = sc.snr, r = sc.detail, p = sc.speed, sum = s + r + p;
        s /= sum; r /= sum; p /= sum;
        dot.setAttribute('cx', (s * 60 + r * 12 + p * 108).toFixed(1));
        dot.setAttribute('cy', (s * 14 + r * 100 + p * 100).toFixed(1));
    }

    function markCards(sc) {
        var paid = sc.snr <= sc.detail && sc.snr <= sc.speed ? 'snr'
            : sc.detail <= sc.speed ? 'res' : 'time';
        document.querySelectorAll('.triangle-card').forEach(function (c) {
            c.classList.toggle('is-paying',
                (paid === 'snr' && c.classList.contains('snr-card')) ||
                (paid === 'res' && c.classList.contains('res-card')) ||
                (paid === 'time' && c.classList.contains('time-card'))
            );
        });
    }

    function drawCover(g, img, dx, dy, dw, dh) {
        if (!img || !img.width) return;
        var ir = img.width / img.height, cr = dw / dh;
        var sw, sh, sx, sy;
        if (ir > cr) { sh = img.height; sw = sh * cr; sx = (img.width - sw) / 2; sy = 0; }
        else { sw = img.width; sh = sw / cr; sx = 0; sy = (img.height - sh) / 2; }
        g.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
    }

    function drawPhantom(g, tw, th, mix) {
        g.fillStyle = '#0b1020';
        g.fillRect(0, 0, tw, th);
        g.save();
        g.translate(tw / 2, th / 2);
        g.scale(tw / 480, th / 480);
        function ell(rx, ry, color) {
            g.beginPath();
            g.ellipse(0, 8, rx, ry, 0, 0, Math.PI * 2);
            g.fillStyle = color;
            g.fill();
        }
        ell(188, 210, '#1a1f2c');
        ell(170, 192, mix > 0.5 ? '#c8d2e0' : '#2a3144');
        ell(118, 128, mix > 0.5 ? '#8a96aa' : '#6d7384');
        ell(22, 70, mix > 0.5 ? '#e8eef8' : '#1c2230');
        g.beginPath(); g.ellipse(-48, 40, 28, 32, 0, 0, Math.PI * 2);
        g.fillStyle = mix > 0.5 ? '#dfe6f2' : '#252b3a'; g.fill();
        g.beginPath(); g.ellipse(48, 40, 28, 32, 0, 0, Math.PI * 2); g.fill();
        g.restore();
    }

    function layer(g, img, a, x, y, zw, zh, tw, wrap) {
        if (!img || !img.width) return;
        g.save();
        g.globalAlpha = a;
        drawCover(g, img, x, y, zw, zh);
        if (wrap) {
            var shift = tw * 0.46;
            g.globalAlpha = a * 0.7;
            drawCover(g, img, x - shift, y, zw, zh);
            drawCover(g, img, x + shift, y, zw, zh);
        }
        g.restore();
    }

    function fillNoise(w, h) {
        if (noiseBuilt === w * 10000 + h) return;
        noiseCv.width = w;
        noiseCv.height = h;
        var id = nx.createImageData(w, h);
        var d = id.data;
        for (var i = 0; i < d.length; i += 4) {
            var n = (Math.random() * 255) | 0;
            d[i] = d[i + 1] = d[i + 2] = n;
            d[i + 3] = 255;
        }
        nx.putImageData(id, 0, 0);
        noiseBuilt = w * 10000 + h;
    }

    function render() {
        var state = readState();
        var sc = scores(state);
        var stage = canvas.parentElement;
        var cssW = Math.max(280, stage.clientWidth | 0);
        var cssH = Math.max(280, stage.clientHeight | 0);
        var dpr = Math.min(window.devicePixelRatio || 1, 1.5);
        var W = cssW * dpr | 0, H = cssH * dpr | 0;
        if (canvas.width !== W || canvas.height !== H) {
            canvas.width = W;
            canvas.height = H;
            canvas.style.width = cssW + 'px';
            canvas.style.height = cssH + 'px';
            noiseBuilt = 0;
        }

        var lo = Math.max(72, Math.round(W * (state.matrix / 480)));
        off.width = lo;
        off.height = Math.max(72, Math.round(lo * H / W));
        ox.fillStyle = '#070b14';
        ox.fillRect(0, 0, off.width, off.height);

        var zoom = 230 / state.fov;
        var zw = off.width * zoom, zh = off.height * zoom;
        var x = (off.width - zw) / 2, y = (off.height - zh) / 2;

        if (readyT1) {
            layer(ox, imgT1, 1, x, y, zw, zh, off.width, sc.wrap);
            if (readyT2) layer(ox, imgT2, sc.mix, x, y, zw, zh, off.width, sc.wrap);
        } else {
            drawPhantom(ox, off.width, off.height, sc.mix);
        }

        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.fillStyle = '#070b14';
        ctx.fillRect(0, 0, W, H);
        ctx.save();
        var blur = (Math.max(0, state.fov / state.matrix - 0.7) * 1.8 + Math.max(0, state.thick - 3.5) * 0.35) * dpr;
        if (blur > 0.35) ctx.filter = 'blur(' + Math.min(6.5, blur) + 'px)';
        ctx.imageSmoothingEnabled = state.matrix >= 220;
        ctx.drawImage(off, 0, 0, W, H);
        ctx.filter = 'none';
        ctx.restore();

        var noiseAmt = Math.max(0, 0.4 - sc.snr * 0.36);
        if (noiseAmt > 0.045) {
            fillNoise(W, H);
            ctx.save();
            ctx.globalAlpha = noiseAmt;
            ctx.globalCompositeOperation = 'overlay';
            ctx.drawImage(noiseCv, 0, 0);
            ctx.globalCompositeOperation = 'source-over';
            ctx.globalAlpha = noiseAmt * 0.28;
            ctx.drawImage(noiseCv, 0, 0);
            ctx.restore();
        }

        root.querySelectorAll('[data-val]').forEach(function (el) {
            var k = el.getAttribute('data-val');
            var map = {
                tr: Math.round(state.tr) + ' ms',
                te: Math.round(state.te) + ' ms',
                fov: Math.round(state.fov) + ' mm',
                matrix: String(Math.round(state.matrix)),
                thick: Number(state.thick).toFixed(1) + ' mm',
                nex: String(state.nex)
            };
            if (map[k] != null) el.textContent = map[k];
        });
        var wt = document.getElementById('driveWeight');
        if (wt) wt.textContent = weighting(sc);
        var px = document.getElementById('drivePixel');
        if (px) px.textContent = sc.pixel.toFixed(2) + ' mm';
        var tm = document.getElementById('driveTime');
        if (tm) {
            var mins = Math.floor(sc.timeSec / 60);
            var secs = Math.round(sc.timeSec % 60);
            tm.textContent = mins + ' min ' + secs + ' s';
        }
        var wrapEl = document.getElementById('driveWrap');
        if (wrapEl) wrapEl.hidden = !sc.wrap;
        var pay = root.querySelector('.mri-conseq-pay');
        if (pay) pay.textContent = payLine(state, sc);

        setMeter('snr', sc.snr);
        setMeter('detail', sc.detail);
        setMeter('time', sc.speed);
        placeDot(sc);
        markCards(sc);
    }

    function requestRender() {
        if (raf) return;
        raf = requestAnimationFrame(function () { raf = 0; render(); });
    }

    root.querySelectorAll('[data-conseq]').forEach(function (inp) {
        function on() {
            lastKey = inp.getAttribute('data-conseq') || lastKey;
            requestRender();
        }
        inp.addEventListener('input', on);
        inp.addEventListener('change', on);
    });

    var reset = document.getElementById('driveReset');
    if (reset) {
        reset.addEventListener('click', function () {
            Object.keys(BASE).forEach(function (k) {
                var inp = root.querySelector('[data-conseq="' + k + '"]');
                if (inp) inp.value = String(BASE[k]);
            });
            lastKey = 'tr';
            requestRender();
        });
    }

    if (window.ResizeObserver) new ResizeObserver(requestRender).observe(canvas.parentElement);
    else window.addEventListener('resize', requestRender);

    requestRender();
})();
