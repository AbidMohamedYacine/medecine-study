/* ============================================================
   CMR PHYSICS LAB — gating · tagging · VENC · MOLLI · ECV  (v2)
   v2 fixes: time-based scrolling gating monitor (HR slider now
   visibly changes beat spacing / phase bins / dead space) and a
   properly clipped SPAMM grid that compresses + twists + fades.
   ============================================================ */
(function () {
    'use strict';
    function $id(x) { return document.getElementById(x); }

    /* ============ 1) ECG GATING SIMULATOR (time-based) ============ */
    (function gating() {
        var cv = $id('gateCanvas');
        if (!cv) return;
        var c = cv.getContext('2d');
        var W = cv.width, H = cv.height;
        var mode = 'pros';
        var HR = 68;
        var TR = 45;                    /* ms — temporal resolution */
        var WIN = 4;                    /* seconds visible */
        var clock = 0, lastT = null;

        function rr() { return 60 / HR; }   /* seconds */
        function ecgY(p) {
            return 0.16 * Math.exp(-Math.pow((p - 0.82) * 14, 2))
                 - 0.08 * Math.exp(-Math.pow((p - 0.10) * 30, 2))
                 - 1.00 * Math.exp(-Math.pow((p - 0.13) * 16, 2))
                 + 0.22 * Math.exp(-Math.pow((p - 0.16) * 20, 2))
                 + 0.26 * Math.exp(-Math.pow((p - 0.40) * 8, 2));
        }

        function draw(ts) {
            if (lastT === null) lastT = ts;
            var dt = (ts - lastT) / 1000; lastT = ts;
            clock += dt;

            c.fillStyle = '#03060d';
            c.fillRect(0, 0, W, H);

            var x0 = 40, winW = W - 55;
            var xOf = function (tau) { return x0 + winW * (1 - (clock - tau) / WIN); };
            var yBase = 64;

            /* time gridlines (scroll left with real time) */
            c.strokeStyle = 'rgba(120,160,255,0.10)';
            c.lineWidth = 1;
            c.font = '9px monospace';
            c.fillStyle = 'rgba(125,146,189,0.55)';
            for (var t = Math.ceil((clock - WIN)); t <= clock; t += 0.5) {
                var gx = xOf(t);
                c.beginPath(); c.moveTo(gx, 14); c.lineTo(gx, 172); c.stroke();
                if (Math.abs(t % 1) < 0.01) c.fillText(t.toFixed(0) + 's', gx - 8, 186);
            }

            /* beat parameters */
            var RR = rr();
            var fill = mode === 'pros' ? 0.86 : 1.0;
            var N = Math.max(4, Math.min(30, Math.floor((RR * 1000 * fill) / TR)));

            /* acquisition bins per beat */
            var colors = ['#1d4ed8', '#0891b2', '#0d9488', '#059669', '#65a30d', '#a16207', '#b45309', '#c2410c', '#dc2626', '#e11d48', '#be185d', '#7e22ce', '#6d28d9', '#4f46e5', '#2563eb'];
            var bStart = Math.floor((clock - WIN) / RR) * RR;
            for (var b = bStart; b <= clock + RR; b += RR) {
                var bx = xOf(b), bw = xOf(b + RR) - xOf(b);

                /* ECG trace segment */
                c.strokeStyle = '#34d399';
                c.lineWidth = 1.7;
                c.beginPath();
                var segEnd = Math.min(b + RR, clock);
                var segStart = Math.max(b, clock - WIN);
                if (segEnd > segStart) {
                    for (var s = 0; s <= 40; s++) {
                        var tau = segStart + (segEnd - segStart) * (s / 40);
                        var p = (tau - b) / RR;
                        var y = yBase - ecgY(p) * 42;
                        s ? c.lineTo(xOf(tau), y) : c.moveTo(xOf(tau), y);
                    }
                    c.stroke();
                }

                /* R-wave marker */
                if (bx > x0 - 6 && bx < x0 + winW + 6) {
                    c.fillStyle = '#fbbf24';
                    c.beginPath(); c.arc(bx, yBase - 46, 3, 0, Math.PI * 2); c.fill();
                    c.fillStyle = 'rgba(251,191,36,0.8)';
                    c.font = '700 9px monospace';
                    c.fillText('R', bx - 3, 176);
                }

                /* phase bins */
                var binW = (bw * fill) / N;
                for (var ph = 0; ph < N; ph++) {
                    if (bx + ph * binW < x0 - 40 || bx + (ph + 1) * binW > x0 + winW + 40) continue;
                    c.fillStyle = colors[ph % colors.length];
                    c.globalAlpha = 0.85;
                    c.fillRect(bx + ph * binW, 126, Math.max(1.5, binW - 1), 26);
                    c.globalAlpha = 1;
                }
                /* dead space (prospective) */
                if (mode === 'pros') {
                    var dx = bx + bw * fill, dw = bw * (1 - fill);
                    if (dx < x0 + winW) {
                        c.fillStyle = 'rgba(248,113,113,0.15)';
                        c.fillRect(dx, 126, dw, 26);
                        c.strokeStyle = 'rgba(248,113,113,0.55)';
                        c.lineWidth = 1;
                        for (var hx = 0; hx < dw; hx += 7) {
                            c.beginPath(); c.moveTo(dx + hx, 152); c.lineTo(dx + hx + 6, 126); c.stroke();
                        }
                        c.fillStyle = '#f87171';
                        c.font = '700 9px monospace';
                        c.fillText('DEAD SPACE', Math.min(dx + 4, x0 + winW - 66), 120);
                    }
                }
            }

            /* live cursor (right edge) */
            c.fillStyle = 'rgba(110,231,183,0.9)';
            c.fillRect(x0 + winW, 12, 1.6, 160);

            c.fillStyle = '#7d92bd';
            c.font = '10px Inter, sans-serif';
            var deadMs = Math.round(RR * 1000 * (1 - fill));
            c.fillText('R-R ' + Math.round(RR * 1000) + ' ms  ·  ' + N + ' phases @ TR ' + TR + ' ms' +
                       (mode === 'pros' ? '  ·  dead ' + deadMs + ' ms' : '  ·  continuous'), x0, 200);

            requestAnimationFrame(draw);
        }
        requestAnimationFrame(draw);

        function setMode(m) {
            mode = m;
            $id('gatePros').classList.toggle('active', m === 'pros');
            $id('gateRetro').classList.toggle('active', m === 'retro');
            $id('gateReadout').innerHTML = m === 'pros'
                ? '<b>Prospective:</b> acquisition stops ~14% before the next R-wave — atrial contraction and late diastole are <b>never imaged</b> (hatched dead space). Robust to arrhythmia.'
                : '<b>Retrospective:</b> acquisition runs continuously across the whole R-R and data are binned onto the average cycle — <b>every phase recovered</b> (ideal for volumes/EF). Interpolates beat-to-beat variation; poor in gross arrhythmia.';
        }
        $id('gatePros').addEventListener('click', function () { setMode('pros'); });
        $id('gateRetro').addEventListener('click', function () { setMode('retro'); });
        $id('gateHR').addEventListener('input', function () {
            HR = parseInt(this.value, 10);
            $id('gateHRVal').textContent = HR;
        });
        setMode('pros');
    })();

    /* ============ 2) MYOCARDIAL TAGGING (SPAMM) — v2 ============ */
    (function tagging() {
        var cv = $id('tagCanvas');
        if (!cv) return;
        var c = cv.getContext('2d');
        var W = cv.width, H = cv.height;
        var phase = 0, playing = true, postContrast = false, lastT = null;

        function ringPath(cx, cy, Ro, Ri) {
            c.beginPath();
            c.arc(cx, cy, Ro, 0, Math.PI * 2, false);
            c.moveTo(cx + Ri, cy);
            c.arc(cx, cy, Ri, 0, Math.PI * 2, true);   /* opposite winding → nonzero ring */
        }

        function draw(f, fade) {
            c.fillStyle = '#05070d';
            c.fillRect(0, 0, W, H);

            var cx = 0.47 * W, cy = 0.5 * H;
            var wallOuter = 0.37 * H * (1 - 0.05 * (1 - f));          /* epicardium pulls in slightly */
            var cavity = 0.185 * H * (0.55 + 0.45 * f);               /* cavity shrinks in systole */
            var sq = 0.70 + 0.30 * f;                                 /* circumferential shortening */
            var twist = 0.22 * (1 - f);                               /* torsion radians at ES */

            /* LV myocardium ring */
            c.fillStyle = '#46536b';
            ringPath(cx, cy, wallOuter, cavity);
            c.fill();
            /* endocardial/epicardial rims */
            c.strokeStyle = '#5d6c8a'; c.lineWidth = 2;
            c.beginPath(); c.arc(cx, cy, wallOuter - 1, 0, Math.PI * 2); c.stroke();
            c.strokeStyle = '#333d52';
            c.beginPath(); c.arc(cx, cy, cavity + 1, 0, Math.PI * 2); c.stroke();

            /* blood pool */
            c.fillStyle = '#0c1220';
            c.beginPath(); c.arc(cx, cy, cavity, 0, Math.PI * 2); c.fill();
            /* papillary muscles — pull toward centre in systole */
            c.fillStyle = '#46536b';
            var papOff = cavity * 0.55;
            c.beginPath(); c.ellipse(cx - papOff * 0.7, cy + papOff * 0.6, 0.045 * H * (0.8 + 0.2 * f), 0.05 * H * (0.8 + 0.2 * f), 0.4, 0, Math.PI * 2); c.fill();
            c.beginPath(); c.ellipse(cx + papOff * 0.8, cy + papOff * 0.45, 0.038 * H * (0.8 + 0.2 * f), 0.043 * H * (0.8 + 0.2 * f), -0.3, 0, Math.PI * 2); c.fill();

            /* RV crescent with its own tags */
            var rvx = 0.80 * W, rvy = 0.55 * H, rvR = 0.115 * H * (0.88 + 0.12 * f), rvRi = rvR * 0.62;
            c.fillStyle = '#3d4757';
            c.beginPath();
            c.ellipse(rvx, rvy, rvR * 0.75, rvR * 1.35, -0.25, 0, Math.PI * 2, false);
            c.moveTo(rvx - rvRi * 0.75, rvy);
            c.ellipse(rvx, rvy, rvRi * 0.75, rvRi * 1.35, -0.25, 0, Math.PI * 2, true);
            c.fill();

            /* ===== SPAMM grid — clipped to myocardium (LV ring + RV crescent) ===== */
            c.save();
            c.beginPath();
            c.arc(cx, cy, wallOuter, 0, Math.PI * 2, false);
            c.moveTo(cx + cavity, cy);
            c.arc(cx, cy, cavity, 0, Math.PI * 2, true);
            c.ellipse(rvx, rvy, rvR * 0.75, rvR * 1.35, -0.25, 0, Math.PI * 2, false);
            c.clip();

            var fadeA = Math.max(0.05, fade);
            var grid = 7;
            var span = wallOuter * 2 / grid;
            c.fillStyle = 'rgba(2,4,10,' + fadeA + ')';
            c.translate(cx, cy);
            c.rotate(twist);                       /* the whole grid twists with torsion */
            for (var i = -Math.ceil(grid / 2); i <= Math.ceil(grid / 2); i++) {
                var pos = i * span * sq;
                /* vertical tag bands */
                c.fillRect(pos - span * sq * 0.16, -wallOuter * 1.2, span * sq * 0.32, wallOuter * 2.4);
                /* horizontal tag bands */
                c.fillRect(-wallOuter * 1.2, pos - span * sq * 0.16, wallOuter * 2.4, span * sq * 0.32);
            }
            c.restore();

            /* status text */
            var strain = Math.round((1 - sq) * 100);
            c.fillStyle = '#94a3b8';
            c.font = '11px monospace';
            c.fillText(f > 0.8 ? 'END-DIASTOLE' : (f < 0.68 ? 'END-SYSTOLE' : ''), 12, H - 30);
            c.fillStyle = fadeA < 0.3 ? '#f87171' : '#6ee7b7';
            c.fillText('tag contrast ' + Math.round(fadeA * 100) + '%', 12, H - 14);
            c.fillStyle = '#7dd3fc';
            c.fillText('circ. strain ≈ ' + strain + '%', W - 140, H - 14);
            c.fillStyle = '#c4b5fd';
            c.fillText('twist ' + Math.round(twist * 57.3) + '°', W - 140, H - 30);

            /* live readout for tests / screen readers */
            var live = $id('tagLive');
            if (live) live.textContent = 'Circumferential shortening ' + strain + '% · torsion ' + Math.round(twist * 57.3) + '° · tag contrast ' + Math.round(fadeA * 100) + '%' + (postContrast ? ' · POST-CONTRAST (rapid fade)' : '');
        }

        function loop(ts) {
            if (lastT === null) lastT = ts;
            var dt = (ts - lastT) / 1000; lastT = ts;
            if (playing) phase = (phase + dt * (68 / 60)) % 1;
            var f = 0.62 + 0.38 * (0.5 + 0.5 * Math.cos(phase * Math.PI * 2));
            var fade = postContrast
                ? Math.max(0.08, 0.9 - phase * 1.3)
                : Math.max(0.28, 0.9 - phase * 0.5);
            draw(f, fade);
            requestAnimationFrame(loop);
        }
        requestAnimationFrame(loop);

        $id('tagPlayBtn').addEventListener('click', function () {
            playing = !playing;
            this.innerHTML = playing ? '<i class="fas fa-pause"></i> Pause' : '<i class="fas fa-play"></i> Play';
        });
        $id('tagContrastBtn').addEventListener('click', function () {
            postContrast = !postContrast;
            this.classList.toggle('btn-primary', postContrast);
            this.classList.toggle('btn-outline', !postContrast);
        });
    })();

    /* ============ 3) VENC ALIASING ============ */
    (function venc() {
        var vt = $id('vencTrue'), vs = $id('vencSet');
        if (!vt || !vs) return;
        function update() {
            var v = parseInt(vt.value, 10), enc = parseInt(vs.value, 10);
            $id('vencTrueVal').textContent = v;
            $id('vencSetVal').textContent = enc;
            var el = $id('vencVerdict');
            if (v <= enc * 0.5) {
                el.className = 'venc-verdict warn';
                el.innerHTML = '<i class="fas fa-triangle-exclamation"></i> VENC far above true velocity (' + v + ' cm/s) — <b>severe underestimation</b> of velocity and noisy phase. Aim within ~25% above peak.';
            } else if (v <= enc) {
                el.className = 'venc-verdict ok';
                var margin = Math.round((enc - v) / v * 100);
                el.innerHTML = '<i class="fas fa-circle-check"></i> Optimal — measured velocity = <b>' + v + ' cm/s</b> (' + margin + '% headroom).';
            } else {
                var aliased = v - 2 * enc;
                el.className = 'venc-verdict bad';
                el.innerHTML = '<i class="fas fa-circle-xmark"></i> <b>ALIASED</b> — true ' + v + ' cm/s exceeds VENC ' + enc + ': phase wraps past +180° and displays as <b>' + aliased + ' cm/s (reverse flow!)</b>';
            }
        }
        vt.addEventListener('input', update);
        vs.addEventListener('input', update);
        update();
    })();

    /* ============ 4) MOLLI SCHEME STRIP ============ */
    (function molli() {
        var wrap = $id('molliStrip');
        if (!wrap) return;
        var SCHEMES = {
            conv: { beats: ['I', '3', 'w', 'I', '3', 'w', 'w', 'w', 'I', '5'], name: 'MOLLI 3(3)3(3)5',
                    note: '11 heartbeats: 3 readouts after each of 3 inversions + waits (3) for recovery. Breath-hold ~11 beats; accurate for most T1s but long-T1 recovery incomplete.' },
            sh: { beats: ['I', '5', 'w', 'I', '1', 'w', 'I', '1'], name: 'ShMOLLI 5(1)1(1)1',
                  note: 'Shorter scheme (conditional fitting): uses all 7 images only for very short T1, fewer for long T1 where recovery is incomplete — accurate with a shorter breath-hold.' }
        };
        function render(key) {
            var s = SCHEMES[key];
            wrap.innerHTML = '';
            s.beats.forEach(function (b) {
                var el = document.createElement('div');
                if (b === 'I') { el.className = 'molli-beat inv'; el.innerHTML = '<i class="fas fa-arrows-rotate"></i>Invert'; }
                else if (b === 'w') { el.className = 'molli-beat wait'; el.innerHTML = '<i class="fas fa-moon"></i>Wait'; }
                else { el.className = 'molli-beat read'; el.innerHTML = '<i class="fas fa-camera"></i>' + b + '\u00d7 read'; }
                wrap.appendChild(el);
            });
            $id('molliNote').textContent = s.note;
            $id('molliConv').classList.toggle('active', key === 'conv');
            $id('molliSh').classList.toggle('active', key === 'sh');
        }
        $id('molliConv').addEventListener('click', function () { render('conv'); });
        $id('molliSh').addEventListener('click', function () { render('sh'); });
        render('conv');
    })();

    /* ============ 5) ECV CALCULATOR ============ */
    (function ecv() {
        var ids = ['ecvT1mNative', 'ecvT1mPost', 'ecvT1bNative', 'ecvT1bPost', 'ecvHct'];
        if (!$id('ecvResult')) return;
        function update() {
            var mN = parseFloat($id('ecvT1mNative').value);
            var mP = parseFloat($id('ecvT1mPost').value);
            var bN = parseFloat($id('ecvT1bNative').value);
            var bP = parseFloat($id('ecvT1bPost').value);
            var hct = parseFloat($id('ecvHct').value);
            var el = $id('ecvResult');
            if ([mN, mP, bN, bP, hct].some(isNaN) || mN <= 0 || mP <= 0 || bN <= 0 || bP <= 0) {
                el.className = 'ecv-result';
                el.innerHTML = '<i class="fas fa-circle-info"></i> Enter valid T1 values.';
                return;
            }
            var dR1myo = (1 / mP - 1 / mN);
            var dR1blood = (1 / bP - 1 / bN);
            if (dR1blood === 0) {
                el.innerHTML = '\u0394R1 blood = 0 — check values.';
                return;
            }
            var lambda = dR1myo / dR1blood;
            var ecv = (1 - hct) * lambda;
            var verdict, cls;
            if (ecv < 0.26) { verdict = 'Normal range (typ. 22\u201326% at 1.5 T)'; cls = 'ok'; }
            else if (ecv < 0.30) { verdict = 'Borderline — early interstitial expansion'; cls = 'warn'; }
            else if (ecv < 0.40) { verdict = 'Raised — fibrosis / oedema / infiltration likely'; cls = 'warn'; }
            else { verdict = 'Markedly raised — amyloid / extensive fibrosis territory'; cls = 'bad'; }
            el.className = 'ecv-result ' + cls;
            el.innerHTML = '<i class="fas fa-calculator"></i> \u03bb = ' + lambda.toFixed(3) +
                ' &nbsp;\u00b7&nbsp; <b>ECV = ' + (ecv * 100).toFixed(1) + '%</b> — ' + verdict +
                '<br><span class="ecv-detail">\u0394R1 myo ' + dR1myo.toFixed(4) + ' s\u207b\u00b9 \u00b7 \u0394R1 blood ' + dR1blood.toFixed(4) + ' s\u207b\u00b9 \u00b7 (1\u2212Hct) = ' + (1 - hct).toFixed(2) + '</span>';
        }
        ids.forEach(function (id) { $id(id).addEventListener('input', update); });
        update();
    })();

})();
