/* ThreeUI Orbital Sphere renderer, mounted as a full-page, UI-free background. */
(function(){
'use strict';
var host=document.createElement('div'); host.className='orbital-sphere-background';
var canvas=document.createElement('canvas'); host.appendChild(canvas); document.body.insertBefore(host,document.body.firstChild);
var THREE=window.THREE; if(!THREE)return;
var scene=new THREE.Scene(), camera=new THREE.PerspectiveCamera(45,1,.1,1000);
var renderer=new THREE.WebGLRenderer({canvas:canvas,alpha:true,antialias:true}); renderer.setPixelRatio(Math.min(devicePixelRatio,2));
var group=new THREE.Group(); scene.add(group); var radius=2.2,count=15000,positions=[],colors=[],mixes=[];
var bright=new THREE.Color(0xa78bfa), dim=new THREE.Color(0x701a75), valid=0;
for(var i=0;i<count;i++){var phi=Math.acos(-1+(2*i)/count),theta=Math.sqrt(count*Math.PI)*phi,x=radius*Math.cos(theta)*Math.sin(phi),y=radius*Math.sin(theta)*Math.sin(phi),z=radius*Math.cos(phi),noise=Math.sin(x*3.5)*Math.cos(y*3.5)*Math.sin(z*3.5)+Math.cos(x*6)*.4;if(noise<=-.1)continue;var d=1+noise*.1,m=dim.clone().lerp(bright,noise>.5?1:.3);positions.push(x*d,y*d,z*d);colors.push(m.r,m.g,m.b);mixes.push(noise>.5?1:.3);valid++;}
var geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));
var colorAttr=geo.getAttribute('color');
var pm=new THREE.PointsMaterial({size:.015,vertexColors:true,transparent:true,opacity:.8,blending:THREE.AdditiveBlending,depthWrite:false});group.add(new THREE.Points(geo,pm));
var om=new THREE.LineBasicMaterial({color:0x8b5cf6,transparent:true,opacity:.25,blending:THREE.AdditiveBlending}), orbitGeos=[],nodeGeos=[],nodeMats=[],halos=[];
var themeMats=[];
function applyTheme(){var t=document.documentElement.getAttribute('data-theme')||'dark',p={dark:['#55e0c1','#087f73','#63a9ff'],light:['#0066e0','#6b849c','#00947a'],aurora:['#c084fc','#7c3aed','#e879f9'],ocean:['#7dd3fc','#0369a1','#22d3ee']}[t]||['#55e0c1','#087f73','#63a9ff'];bright.set(p[0]);dim.set(p[1]);om.color.set(p[2]);var isLight=t==='light';pm.blending=isLight?THREE.NormalBlending:THREE.AdditiveBlending;pm.opacity=isLight?0.7:0.8;pm.size=isLight?0.018:0.015;om.blending=isLight?THREE.NormalBlending:THREE.AdditiveBlending;om.opacity=isLight?0.32:0.25;nodeMats.forEach(function(m){if(m.color)m.color.set(p[0]);if('blending' in m){m.blending=isLight?THREE.NormalBlending:THREE.AdditiveBlending;}});halos.forEach(function(m){if(m.color)m.color.set(p[0]);if('blending' in m){m.blending=isLight?THREE.NormalBlending:THREE.AdditiveBlending;m.opacity=isLight?0.28:0.2;}}); for(var q=0;q<mixes.length;q++){var c=dim.clone().lerp(bright,mixes[q]);colorAttr.setXYZ(q,c.r,c.g,c.b);} colorAttr.needsUpdate=true;}
new MutationObserver(applyTheme).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
for(i=0;i<6;i++){var g=new THREE.BufferGeometry(),pts=[],or=radius*(1.08+Math.random()*.2);for(var j=0;j<=90;j++){var a=j/90*Math.PI*2;pts.push(Math.cos(a)*or,Math.sin(a)*or,Math.sin(a*4)*.1);}g.setAttribute('position',new THREE.Float32BufferAttribute(pts,3));orbitGeos.push(g);var line=new THREE.Line(g,om);line.rotation.x=Math.random()*Math.PI*2;line.rotation.y=Math.random()*Math.PI*2;group.add(line);if(i%2){var ng=new THREE.SphereGeometry(.025,16,16),nm=new THREE.MeshBasicMaterial({color:0xd946ef}),node=new THREE.Mesh(ng,nm),ha=new THREE.SphereGeometry(.08,16,16),hm=new THREE.MeshBasicMaterial({color:0xc084fc,transparent:true,opacity:.2,blending:THREE.AdditiveBlending}),halo=new THREE.Mesh(ha,hm),aa=Math.random()*Math.PI*2;node.position.set(Math.cos(aa)*or,Math.sin(aa)*or,0);line.add(node);node.add(halo);nodeGeos.push(ng,ha);nodeMats.push(nm,hm);halos.push(hm);}}
applyTheme();
var scale=1;function resize(){var w=host.clientWidth,h=host.clientHeight;camera.aspect=w/Math.max(1,h);camera.updateProjectionMatrix();renderer.setSize(w,h,false);if(w>=1024){group.position.set(2.5,0,-2);scale=1.15;camera.position.z=5.5;}else{group.position.set(0,-1,-3);scale=1;camera.position.z=6.5;}group.scale.setScalar(scale);}
new ResizeObserver(resize).observe(host);resize();
function render(){group.rotation.y+=.0008;group.rotation.x+=.0003;group.children.forEach(function(c,k){if(c.type==='Line')c.rotation.z+=.0004*(k%2? -1:1);});renderer.render(scene,camera);requestAnimationFrame(render);} render();
})();
