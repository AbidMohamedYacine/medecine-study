/* ============================================================
   SEENmri — main.js (Phase 5 addendum)
   Site-wide search (Ctrl+K) + learning progress tracking
   ============================================================ */
(function () {
    'use strict';

    function $(id) { return document.getElementById(id); }
    function loadJSON(key, fallback) {
        try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch (e) { return fallback; }
    }
    function saveJSON(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {} }

    var LESSONS = [
        { u: 'about-mri.html',  n: 'What is MRI?',     i: 'fa-info-circle' },
        { u: 'components.html', n: 'MRI Components',   i: 'fa-cogs' },
        { u: 'sequences.html',  n: 'Sequences',        i: 'fa-layer-group' },
        { u: 'parameters.html', n: 'Parameters',       i: 'fa-sliders-h' },
        { u: 'body-parts.html', n: 'Body Parts',       i: 'fa-lungs' },
        { u: 'scan-atlas.html', n: 'Scan Atlas',       i: 'fa-images' },
        { u: 'safety.html',     n: 'MRI Safety',       i: 'fa-shield-alt' },
        { u: 'preparation.html',n: 'Patient Prep',     i: 'fa-clipboard-list' },
        { u: 'resources.html',  n: 'Resources',        i: 'fa-bookmark' },
        { u: 'simulator.html',  n: 'Console Simulator',i: 'fa-gamepad', practice: true },
        { u: 'quiz.html',       n: 'Quiz & Exam',      i: 'fa-question-circle', practice: true }
    ];

    function currentPage() {
        var p = location.pathname.split('/').pop() || 'index.html';
        return p.split('#')[0].split('?')[0];
    }

    /* ============================================================
       PROGRESS TRACKING
       ============================================================ */
    var VISITED_KEY = 'seenmri-visited';
    var DONE_KEY = 'seenmri-completed';

    var visited = loadJSON(VISITED_KEY, {});
    visited[currentPage()] = Date.now();
    saveJSON(VISITED_KEY, visited);

    var completed = loadJSON(DONE_KEY, {});

    /* ---- "Mark complete" button on lesson pages ---- */
    var LESSON_PAGES = ['about-mri.html','components.html','sequences.html','parameters.html',
                        'body-parts.html','scan-atlas.html','safety.html','preparation.html','resources.html'];

    if (LESSON_PAGES.indexOf(currentPage()) !== -1) {
        var footer = document.querySelector('.footer');
        if (footer && footer.parentElement) {
            var wrap = document.createElement('div');
            wrap.style.cssText = 'text-align:center;padding:0 0 50px;';
            var btn = document.createElement('button');
            btn.id = 'markComplete';
            btn.className = 'btn ' + (completed[currentPage()] ? 'btn-done' : 'btn-outline');
            btn.innerHTML = completed[currentPage()]
                ? '<i class="fas fa-circle-check"></i> Lesson Completed'
                : '<i class="fas fa-circle-notch"></i> Mark this lesson complete';
            btn.addEventListener('click', function () {
                if (completed[currentPage()]) {
                    delete completed[currentPage()];
                    if (window.toast) window.toast('Lesson marked as not complete', 'info');
                } else {
                    completed[currentPage()] = Date.now();
                    btn.classList.add('just-done');
                    if (window.toast) window.toast('Lesson complete — well done!', 'success');
                }
                saveJSON(DONE_KEY, completed);
                btn.className = 'btn ' + (completed[currentPage()] ? 'btn-done' : 'btn-outline');
                btn.innerHTML = completed[currentPage()]
                    ? '<i class="fas fa-circle-check"></i> Lesson Completed'
                    : '<i class="fas fa-circle-notch"></i> Mark this lesson complete';
                if (completed[currentPage()]) {
                    btn.classList.add('just-done');
                    setTimeout(function () { btn.classList.remove('just-done'); }, 900);
                }
            });
            wrap.appendChild(btn);
            footer.parentElement.insertBefore(wrap, footer);
        }
    }

    /* ---- Learning path on the home page ---- */
    var pathBox = $('learningPath');
    if (pathBox) {
        var doneCount = LESSONS.filter(function (l) { return completed[l.u]; }).length;
        var pct = Math.round((doneCount / LESSONS.length) * 100);
        var next = LESSONS.find(function (l) { return !completed[l.u]; });

        var items = LESSONS.map(function (l, idx) {
            var isDone = !!completed[l.u];
            var isNext = next && l.u === next.u;
            return '<a href="' + l.u + '" class="lp-item' + (isDone ? ' done' : '') + (isNext ? ' next' : '') + '">' +
                '<span class="lp-check"><i class="fas ' + (isDone ? 'fa-check' : (isNext ? 'fa-play' : l.i)) + '"></i></span>' +
                '<span class="lp-text"><strong>' + (idx + 1) + '. ' + l.n + '</strong>' +
                '<em>' + (l.practice ? 'Practice' : (isDone ? 'Completed' : isNext ? 'Up next' : (visited[l.u] ? 'Started' : 'Not started'))) + '</em></span>' +
                '<i class="fas fa-chevron-right lp-arrow"></i></a>';
        }).join('');

        pathBox.innerHTML =
            '<div class="lp-head">' +
                '<div class="lp-progress-text"><h3>Your Learning Path</h3>' +
                '<p>' + doneCount + ' of ' + LESSONS.length + ' complete' + (pct === 100 ? ' — you finished everything! 🎉' : '') + '</p></div>' +
                '<div class="lp-ring" style="--p:' + pct + '"><span>' + pct + '%</span></div>' +
            '</div>' +
            '<div class="lp-progress-track"><div class="lp-progress-fill" style="width:' + pct + '%"></div></div>' +
            '<div class="lp-grid">' + items + '</div>' +
            (next ? '<div class="center-btn" style="margin-top:26px;"><a href="' + next.u + '" class="btn btn-primary"><i class="fas fa-play"></i> Continue: ' + next.n + '</a></div>'
                  : '<div class="center-btn" style="margin-top:26px;"><a href="quiz.html" class="btn btn-primary"><i class="fas fa-trophy"></i> Take the Final Exam</a></div>');
    }

    /* ============================================================
       SITE-WIDE SEARCH
       ============================================================ */
    var searchBtn = document.createElement('button');
    searchBtn.id = 'searchToggle';
    searchBtn.className = 'theme-toggle';
    searchBtn.title = 'Search SEENmri (Ctrl+K)';
    searchBtn.setAttribute('aria-label', 'Search SEENmri');
    searchBtn.innerHTML = '<i class="fas fa-magnifying-glass"></i>';
    var navContainer2 = document.querySelector('.nav-container');
    var navToggle2 = document.getElementById('navToggle');
    if (navContainer2) {
        if (navToggle2) navContainer2.insertBefore(searchBtn, navToggle2);
        else navContainer2.appendChild(searchBtn);
    }

    var overlay = document.createElement('div');
    overlay.id = 'searchOverlay';
    overlay.className = 'search-overlay';
    overlay.innerHTML =
        '<div class="search-modal" role="dialog" aria-label="Site search">' +
            '<div class="search-input-row">' +
                '<i class="fas fa-magnifying-glass"></i>' +
                '<input type="text" id="searchInput" placeholder="Search all of SEENmri — try “FLAIR”, “quench”, “TR”, “artifact”…" autocomplete="off">' +
                '<kbd>ESC</kbd>' +
            '</div>' +
            '<div class="search-results" id="searchResults"></div>' +
            '<div class="search-hint"><span><kbd>↑</kbd><kbd>↓</kbd> navigate</span><span><kbd>↵</kbd> open</span><span><kbd>esc</kbd> close</span></div>' +
        '</div>';
    document.body.appendChild(overlay);

    var input = $('searchInput');
    var resultsBox = $('searchResults');
    var activeIdx = -1;
    var currentResults = [];

    function openSearch() {
        overlay.classList.add('open');
        input.value = '';
        input.focus();
        renderResults('');
    }
    function closeSearch() {
        overlay.classList.remove('open');
    }
    searchBtn.addEventListener('click', openSearch);
    overlay.addEventListener('click', function (e) { if (e.target === overlay) closeSearch(); });

    document.addEventListener('keydown', function (e) {
        var typing = ['INPUT', 'TEXTAREA', 'SELECT'].indexOf(e.target.tagName) !== -1;
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault();
            overlay.classList.contains('open') ? closeSearch() : openSearch();
        } else if (e.key === 'Escape' && overlay.classList.contains('open')) {
            closeSearch();
        } else if (e.key === '/' && !typing) {
            e.preventDefault();
            openSearch();
        } else if (overlay.classList.contains('open')) {
            if (e.key === 'ArrowDown') { e.preventDefault(); moveActive(1); }
            else if (e.key === 'ArrowUp') { e.preventDefault(); moveActive(-1); }
            else if (e.key === 'Enter' && activeIdx >= 0) {
                e.preventDefault();
                if (currentResults[activeIdx]) location.href = currentResults[activeIdx].u;
            }
        }
    });

    function moveActive(d) {
        if (!currentResults.length) return;
        activeIdx = (activeIdx + d + currentResults.length) % currentResults.length;
        paintActive();
    }
    function paintActive() {
        resultsBox.querySelectorAll('.search-result').forEach(function (r, i) {
            r.classList.toggle('active', i === activeIdx);
        });
        var el = resultsBox.querySelectorAll('.search-result')[activeIdx];
        if (el && el.scrollIntoView) el.scrollIntoView({ block: 'nearest' });
    }

    function score(entry, q) {
        var t = entry.t.toLowerCase(), s = (entry.s || '').toLowerCase(), p = entry.p.toLowerCase();
        var sc = 0;
        if (t.indexOf(q) === 0) sc += 10;
        else if (t.indexOf(q) !== -1) sc += 6;
        if (p.indexOf(q) !== -1) sc += 2;
        if (s.indexOf(q) !== -1) sc += 2;
        /* word bonus */
        var words = t.split(/[^a-z0-9]+/);
        if (words.indexOf(q) !== -1) sc += 3;
        return sc;
    }

    function highlight(text, q) {
        if (!q) return text;
        var idx = text.toLowerCase().indexOf(q);
        if (idx === -1) return text;
        return text.slice(0, idx) + '<mark>' + text.slice(idx, idx + q.length) + '</mark>' + text.slice(idx + q.length);
    }

    var PAGES_QUICK = [
        { u: 'about-mri.html',  t: 'What is MRI?',        d: 'Physics from protons to image' },
        { u: 'sequences.html',  t: 'Sequences',           d: 'T1, T2, FLAIR, DWI and more' },
        { u: 'scan-atlas.html', t: 'Scan Atlas',          d: 'Real scans & artifact library' },
        { u: 'simulator.html',  t: 'Console Simulator',   d: 'The interactive workstation' },
        { u: 'quiz.html',       t: 'Quiz & Exam',         d: '100 questions · timed exam' },
        { u: 'safety.html',     t: 'MRI Safety',          d: 'Zones, screening, quench' }
    ];

    function renderResults(q) {
        q = (q || '').trim().toLowerCase();
        activeIdx = -1;
        currentResults = [];

        if (!q) {
            resultsBox.innerHTML = '<div class="sr-label">Jump to</div>' +
                PAGES_QUICK.map(function (p) {
                    return '<a href="' + p.u + '" class="search-result"><span class="sr-page">GO</span>' +
                        '<span class="sr-body"><span class="sr-title">' + p.t + '</span><span class="sr-snippet">' + p.d + '</span></span>' +
                        '<i class="fas fa-arrow-right sr-go"></i></a>';
                }).join('');
            return;
        }

        var INDEX = window.SEENMRI_INDEX || [];
        var scored = [];
        INDEX.forEach(function (e) {
            var sc = score(e, q);
            if (sc > 0) scored.push({ e: e, sc: sc });
        });
        scored.sort(function (a, b) { return b.sc - a.sc; });
        currentResults = scored.slice(0, 9).map(function (x) { return x.e; });

        if (!currentResults.length) {
            resultsBox.innerHTML =
                '<div class="empty-state" style="padding:18px 10px;">' +
                    '<div class="es-art" style="width:92px;height:92px;margin-bottom:12px;" aria-hidden="true"><div class="es-ring"></div><div class="es-scanline"></div><div class="es-z" style="font-size:1.5rem;">?</div></div>' +
                    '<h3>No signal for “' + q.replace(/</g, '&lt;') + '”</h3>' +
                    '<p style="margin-bottom:12px;">This frequency wasn\'t encoded in our index. Try a nearby landmark:</p>' +
                    '<div class="es-chips">' +
                        ['FLAIR', 'quench', 'k-space', 'LGE', 'SAR', 'screening'].map(function (t) {
                            return '<button class="es-chip" data-q="' + t + '">' + t + '</button>';
                        }).join('') +
                    '</div>' +
                '</div>';
            resultsBox.querySelectorAll('.es-chip').forEach(function (chip) {
                chip.addEventListener('click', function () {
                    input.value = chip.getAttribute('data-q');
                    renderResults(input.value);
                });
            });
            return;
        }

        resultsBox.innerHTML = '<div class="sr-label">' + currentResults.length + ' results</div>' +
            currentResults.map(function (e) {
                return '<a href="' + e.u + '" class="search-result">' +
                    '<span class="sr-page">' + e.p + '</span>' +
                    '<span class="sr-body"><span class="sr-title">' + highlight(e.t, q) + '</span>' +
                    (e.s ? '<span class="sr-snippet">' + highlight(e.s, q) + '</span>' : '') + '</span>' +
                    '<i class="fas fa-arrow-right sr-go"></i></a>';
            }).join('');
    }

    input.addEventListener('input', function () { renderResults(this.value); });

})();
/* ============================================================
   EXTRAS — confetti celebration · case of the day
   ============================================================ */
(function () {
    'use strict';

    function $id(id) { return document.getElementById(id); }

    /* ---- confetti (called on exam pass) ---- */
    window.celebrate = function () {
        var canvas = document.createElement('canvas');
        canvas.id = 'confettiCanvas';
        document.body.appendChild(canvas);
        var ctx = canvas.getContext('2d');
        canvas.width = innerWidth; canvas.height = innerHeight;

        var colors = ['#008cff', '#00d4aa', '#f59e0b', '#ec4899', '#8b5cf6', '#22c55e'];
        var parts = [];
        for (var i = 0; i < 140; i++) {
            parts.push({
                x: Math.random() * canvas.width,
                y: -20 - Math.random() * canvas.height * 0.4,
                w: 6 + Math.random() * 7,
                h: 8 + Math.random() * 8,
                c: colors[Math.floor(Math.random() * colors.length)],
                vy: 2.2 + Math.random() * 3.4,
                vx: -1.6 + Math.random() * 3.2,
                rot: Math.random() * Math.PI,
                vr: -0.12 + Math.random() * 0.24
            });
        }

        var t0 = null;
        function frame(ts) {
            if (!t0) t0 = ts;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            parts.forEach(function (p) {
                p.x += p.vx; p.y += p.vy; p.rot += p.vr;
                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate(p.rot);
                ctx.fillStyle = p.c;
                ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
                ctx.restore();
            });
            if (ts - t0 < 2800) requestAnimationFrame(frame);
            else canvas.remove();
        }
        requestAnimationFrame(frame);
    };

    /* ---- Case of the Day (home page) ---- */
    var CASE_TEASERS = [
        { tag: 'Neuro · Acute', icon: 'fa-brain', title: 'Sudden focal deficit', text: '68-year-old, right arm weakness 2 hours ago, CT negative. Which study confirms the ischemic core?' },
        { tag: 'Neuro · Demyelination', icon: 'fa-atom', title: 'Young woman, sensory episodes', text: 'Two episodes of sensory loss, suspected MS. Which sequence exposes periventricular plaques best?' },
        { tag: 'MSK · Trauma', icon: 'fa-bone', title: 'Twisting knee injury', text: 'Locked knee after football, positive McMurray. Which protocol element images the meniscus?' },
        { tag: 'Cardiac · Viability', icon: 'fa-heart', title: 'Old infarction, EF 32%', text: 'Revascularization decision pending. Which study defines scar and hibernating myocardium?' },
        { tag: 'MSK · Occult', icon: 'fa-star', title: 'Ankle pain, negative X-ray', text: 'Athlete cannot bear weight, films clean. Which sequence reveals the bone bruise?' },
        { tag: 'Spine · Radiculopathy', icon: 'fa-wave-square', title: 'Shooting leg pain', text: 'Straight-leg-raise positive at 40°. Which sagittal sequence shows the extruded disc?' }
    ];

    var codBox = $id('caseOfDay');
    if (codBox) {
        var dayIndex = Math.floor(Date.now() / 86400000) % CASE_TEASERS.length;
        var c = CASE_TEASERS[dayIndex];
        codBox.innerHTML =
            '<a href="quiz.html#cases" class="cod-card" data-no-fade="">' +
                '<div class="cod-icon"><i class="fas ' + c.icon + '"></i></div>' +
                '<div class="cod-body">' +
                    '<span class="cod-tag">Case of the Day</span>' +
                    '<h3>' + c.title + '</h3>' +
                    '<p>' + c.text + '</p>' +
                '</div>' +
                '<span class="btn btn-primary" style="white-space:nowrap;">Solve it <i class="fas fa-arrow-right"></i></span>' +
            '</a>';
    }
})();
