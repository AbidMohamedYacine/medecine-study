/* ============================================================
   SEENmri — ThreeUI Cloud Field, themed + scroll-driven waves
   Geometry from MengTo/threeui strata-cloud shader.
   Colors follow each site theme:
     Dark   — blue #0077ff  +  teal #00d4aa
     Light  — platinum silver + ice-cyan core (near logo teal, not the same)
     Aurora — violet #8b5cf6 +  pink #ec4899
     Ocean  — sky #0ea5e9   +  aqua #2dd4bf

   Scroll: the five strata move as one stack (parallax) across the
   full page. Each wave then opens the same way the first does —
   a center pass that parts, then the ridge sinks. The same top-sky
   stars fill in behind every wave as it recedes.
   ============================================================ */
(function () {
    'use strict';

    var canvas = document.getElementById('cloudField');
    if (!canvas) return;

    var gl = canvas.getContext('webgl', { antialias: true, alpha: false, preserveDrawingBuffer: true });
    if (!gl) return;

    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var W, H, dpr;

    function resize() {
        dpr = Math.min(window.devicePixelRatio || 1, 2);
        W = window.innerWidth;
        H = window.innerHeight;
        canvas.width = W * dpr;
        canvas.height = H * dpr;
        canvas.style.width = W + 'px';
        canvas.style.height = H + 'px';
        gl.viewport(0, 0, canvas.width, canvas.height);
    }
    window.addEventListener('resize', resize);
    resize();

    var VS = [
        'attribute vec2 a_pos;',
        'void main(){ gl_Position = vec4(a_pos, 0.0, 1.0); }'
    ].join('\n');

    var FS = [
        'precision highp float;',
        'uniform vec2 u_res;',
        'uniform float u_time;',
        'uniform vec2 u_mouse;',
        'uniform vec3 u_primary;',
        'uniform vec3 u_secondary;',
        'uniform vec3 u_bg;',
        'uniform vec3 u_glow;',
        'uniform float u_light;',
        'uniform float u_scroll;',
        '',
        'float hash(float n){ return fract(sin(n)*43758.5453123); }',
        'float hash2(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }',
        '',
        'float noise(float x){',
        '    float i = floor(x);',
        '    float f = fract(x);',
        '    f = f*f*(3.0-2.0*f);',
        '    return mix(hash(i), hash(i+1.0), f);',
        '}',
        '',
        'float fbm(float x, float octaves){',
        '    float val = 0.0;',
        '    float amp = 0.5;',
        '    float freq = 1.0;',
        '    for(int i = 0; i < 6; i++){',
        '        if(float(i) >= octaves) break;',
        '        val += amp * noise(x * freq);',
        '        freq *= 2.17;',
        '        amp *= 0.48;',
        '    }',
        '    return val;',
        '}',
        '',
        'float smoother(float t){',
        '    t = clamp(t, 0.0, 1.0);',
        '    return t*t*t*(t*(t*6.0-15.0)+10.0);',
        '}',
        '',
        'float wave(float s, float a, float b){',
        '    return smoother((s - a) / max(b - a, 0.0001));',
        '}',
        '',
        'float meteor(vec2 uv, float t){',
        '    float cycle = mod(t * 0.15, 1.0);',
        '    float seed = floor(t * 0.15);',
        '    float h = hash(seed * 7.31);',
        '    float h2 = hash(seed * 13.17);',
        '    if(h > 0.30) return 0.0;',
        '    vec2 start = vec2(0.2 + h2 * 0.6, 0.7 + h * 0.25);',
        '    vec2 dir = normalize(vec2(1.0, -0.6 - h * 0.3));',
        '    float progress = smoothstep(0.0, 0.7, cycle);',
        '    vec2 pos = start + dir * progress * 0.5;',
        '    vec2 toP = uv - pos;',
        '    float along = dot(toP, dir);',
        '    float perp = length(toP - dir * along);',
        '    float trail = smoothstep(0.0, -0.12, along) * smoothstep(-0.18, -0.04, along);',
        '    float core = smoothstep(0.003, 0.0, perp) * trail;',
        '    float glow = smoothstep(0.012, 0.0, perp) * trail * 0.3;',
        '    float fade = smoothstep(0.0, 0.1, cycle) * smoothstep(0.8, 0.55, cycle);',
        '    return (core + glow) * fade;',
        '}',
        '',
        'float stars(vec2 uv, float density){',
        '    vec2 cell = floor(uv * density);',
        '    vec2 sub = fract(uv * density);',
        '    float h = hash2(cell);',
        '    float brightness = step(0.975, h);',
        '    float size = 0.025 + h * 0.045;',
        '    float d = length(sub - vec2(hash2(cell + 100.0), hash2(cell + 200.0)));',
        '    float star = brightness * smoothstep(size, 0.0, d);',
        '    star *= 0.5 + 0.5 * sin(u_time * (1.0 + h * 3.0) + h * 6.28);',
        '    return star;',
        '}',
        '',
        'vec3 layerTint(float amount){',
        '    vec3 darkL  = mix(u_bg, u_primary, amount);',
        '    vec3 goldFar  = mix(u_bg, u_primary, 0.62);',
        '    vec3 goldNear = mix(u_primary, u_secondary, 0.45) * 0.32;',
        '    vec3 lightL = mix(goldNear, goldFar, amount);',
        '    return mix(darkL, lightL, u_light);',
        '}',
        '',
        'float ridgeHeight(',
        '    float xScale, float tDrift, float mouseAmt,',
        '    float seed, float restY, float local, float together,',
        '    float aspect, vec2 uv, vec2 mouse,',
        '    float profA, float profB',
        '){',
        '    float xC = uv.x * aspect * xScale + u_time * tDrift + mouse.x * mouseAmt;',
        '    float yS = mouse.y * (mouseAmt * 0.30);',
        '    float prof = fbm(xC, 5.0) * profA + fbm(xC * 0.3 + seed, 3.0) * profB;',
        '    float drop = together + local * (restY * 0.92 + 0.10);',
        '    return restY + prof + yS - drop;',
        '}',
        '',
        'void applyLayer(',
        '    inout vec3 col, inout float starMask,',
        '    float mTop, float amount, float local,',
        '    vec2 uv, vec3 rim, vec3 amb, float rimAmt, float ambAmt',
        '){',
        '    vec3 lC = layerTint(amount);',
        '    float mtn = smoothstep(mTop + 0.003, mTop - 0.001, uv.y);',
        '    float rDist = abs(uv.y - mTop);',
        '    float fade = 1.0 - local * 0.62;',
        '    float rGlow = smoothstep(0.012, 0.0, rDist) * rimAmt * fade;',
        '    float rAmb  = smoothstep(0.04,  0.0, rDist) * ambAmt * fade;',
        '    col = mix(col, lC, mtn);',
        '    col += rim * rGlow;',
        '    col += amb * rAmb;',
        '    starMask *= (1.0 - mtn);',
        '}',
        '',
        'void main(){',
        '    vec2 uv = gl_FragCoord.xy / u_res;',
        '    float aspect = u_res.x / u_res.y;',
        '    vec2 mouse = u_mouse * 2.0 - 1.0;',
        '    float s = clamp(u_scroll, 0.0, 1.0);',
        '    float g = wave(s, 0.0, 1.0);',
        '',
        '    vec3 skyTop    = mix(u_bg * 0.72, mix(u_bg, u_primary, 0.10), u_light);',
        '    vec3 skyMid    = mix(mix(u_bg, u_primary, 0.22), mix(u_bg, u_glow, 0.42), u_light);',
        '    vec3 skyBottom = mix(mix(u_bg, u_primary, 0.40), mix(u_bg, u_glow, 0.68), u_light);',
        '',
        '    float skyGrad = uv.y;',
        '    vec3 col = mix(skyBottom, skyMid, smoothstep(0.3, 0.6, skyGrad));',
        '    col = mix(col, skyTop, smoothstep(0.6, 1.0, skyGrad));',
        '',
        '    float horizonY = mix(0.35, 0.11, g);',
        '    float horizonGlow = exp(-pow((uv.y - horizonY) * 3.8, 2.0));',
        '    vec3 hCol = mix(mix(u_primary, u_secondary, 0.22), u_glow, u_light);',
        '    col += hCol * horizonGlow * mix(0.85, 0.88, u_light) * mix(1.0, 0.55, g);',
        '',
        '    float centerGlow = exp(-pow((uv.x - 0.5) * 1.5, 2.0)) * exp(-pow((uv.y - horizonY) * 4.0, 2.0));',
        '    col += mix(u_secondary, u_glow, u_light) * centerGlow * mix(0.65, 0.92, u_light) * mix(1.0, 0.42, g);',
        '',
        '    float starField = stars(uv * vec2(aspect, 1.0), 60.0)',
        '                    + stars(uv * vec2(aspect, 1.0) + 500.0, 100.0) * 0.7',
        '                    + stars(uv * vec2(aspect, 1.0) + 900.0, 160.0) * 0.4;',
        '',
        '    float starMask = 1.0;',
        '    vec3 rim = mix(u_primary, u_secondary, 0.38);',
        '    vec3 amb = mix(u_primary, u_secondary, 0.58);',
        '',
        '    float l0 = wave(s, 0.40, 1.00);',
        '    float l1 = wave(s, 0.28, 0.88);',
        '    float l2 = wave(s, 0.16, 0.76);',
        '    float l3 = wave(s, 0.06, 0.64);',
        '    float l4 = wave(s, 0.00, 0.52);',
        '',
        '    float m0 = ridgeHeight(1.6, 0.006, 0.010, 17.0, 0.40, l0, g * 0.14, aspect, uv, mouse, 0.10, 0.070);',
        '    float m1 = ridgeHeight(2.0, 0.012, 0.020, 34.0, 0.33, l1, g * 0.18, aspect, uv, mouse, 0.13, 0.091);',
        '    float m2 = ridgeHeight(2.6, 0.020, 0.034, 51.0, 0.26, l2, g * 0.22, aspect, uv, mouse, 0.16, 0.112);',
        '    float m3 = ridgeHeight(3.2, 0.030, 0.050, 68.0, 0.18, l3, g * 0.28, aspect, uv, mouse, 0.14, 0.098);',
        '    float m4 = ridgeHeight(4.0, 0.044, 0.070, 85.0, 0.09, l4, g * 0.34, aspect, uv, mouse, 0.11, 0.077);',
        '',
        '    applyLayer(col, starMask, m0, 0.48, l0, uv, rim, amb, 0.18, 0.060);',
        '    applyLayer(col, starMask, m1, 0.38, l1, uv, rim, amb, 0.15, 0.045);',
        '    applyLayer(col, starMask, m2, 0.28, l2, uv, rim, amb, 0.12, 0.030);',
        '    applyLayer(col, starMask, m3, 0.18, l3, uv, rim, amb, 0.09, 0.000);',
        '    applyLayer(col, starMask, m4, 0.10, l4, uv, rim, amb, 0.06, 0.000);',
        '',
        '    float starGain = smoother((s - 0.03) / 0.34);',
        '    vec3 starCol = mix(vec3(0.92, 0.95, 1.0), u_primary, 0.28);',
        '    float starLit = mix(1.0, 0.55, u_light);',
        '    float aa = 0.003;',
        '    float pockets = 0.0;',
        '    pockets += smoothstep(m1 - 0.001, m1 + aa, uv.y) * smoothstep(m0 + aa, m0 - 0.001, uv.y);',
        '    pockets += smoothstep(m2 - 0.001, m2 + aa, uv.y) * smoothstep(m1 + aa, m1 - 0.001, uv.y);',
        '    pockets += smoothstep(m3 - 0.001, m3 + aa, uv.y) * smoothstep(m2 + aa, m2 - 0.001, uv.y);',
        '    pockets += smoothstep(m4 - 0.001, m4 + aa, uv.y) * smoothstep(m3 + aa, m3 - 0.001, uv.y);',
        '    pockets = clamp(pockets, 0.0, 1.0) * starGain;',
        '    col = mix(col, skyTop, pockets);',
        '    col += starCol * starField * (starMask + pockets) * starLit;',
        '    float met = meteor(uv * vec2(aspect, 1.0), u_time);',
        '    vec3 metCol = mix(u_secondary, vec3(0.93, 0.96, 1.0), 0.40);',
        '    col += metCol * met * starMask * mix(1.0, 0.85, u_light);',
        '',
        '    float vig = 1.0 - mix(0.30, 0.16, u_light) * pow(length((uv - 0.5) * vec2(1.1, 1.6)), 2.0);',
        '    col *= vig;',
        '',
        '    float haze = exp(-pow((uv.y - mix(0.33, 0.14, g)) * 5.0, 2.0)) * 0.05;',
        '    col += mix(mix(u_primary, u_secondary, 0.5), u_glow, u_light) * haze * mix(1.0, 0.9, u_light);',
        '',
        '    col = pow(max(col, vec3(0.0)), vec3(mix(0.95, 1.02, u_light)));',
        '    gl_FragColor = vec4(col, 1.0);',
        '}'
    ].join('\n');

    function createShader(src, type) {
        var s = gl.createShader(type);
        gl.shaderSource(s, src);
        gl.compileShader(s);
        if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
            if (typeof console !== 'undefined' && console.warn) {
                console.warn('[cloud-field] shader', gl.getShaderInfoLog(s));
            }
            return null;
        }
        return s;
    }

    var vs = createShader(VS, gl.VERTEX_SHADER);
    var fs = createShader(FS, gl.FRAGMENT_SHADER);
    if (!vs || !fs) {
        canvas.style.opacity = '0';
        return;
    }

    var prog = gl.createProgram();
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
        if (typeof console !== 'undefined' && console.warn) {
            console.warn('[cloud-field] program', gl.getProgramInfoLog(prog));
        }
        canvas.style.opacity = '0';
        return;
    }
    gl.useProgram(prog);

    var quad = new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]);
    var buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, quad, gl.STATIC_DRAW);
    var aPos = gl.getAttribLocation(prog, 'a_pos');
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

    var uRes = gl.getUniformLocation(prog, 'u_res');
    var uTime = gl.getUniformLocation(prog, 'u_time');
    var uMouse = gl.getUniformLocation(prog, 'u_mouse');
    var uPrimary = gl.getUniformLocation(prog, 'u_primary');
    var uSecondary = gl.getUniformLocation(prog, 'u_secondary');
    var uBg = gl.getUniformLocation(prog, 'u_bg');
    var uGlow = gl.getUniformLocation(prog, 'u_glow');
    var uLight = gl.getUniformLocation(prog, 'u_light');
    var uScroll = gl.getUniformLocation(prog, 'u_scroll');

    function parseColor(css) {
        css = (css || '').trim();
        if (!css) return null;
        if (css.charAt(0) === '#') {
            var h = css.slice(1);
            if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
            if (h.length !== 6) return null;
            return [
                parseInt(h.slice(0, 2), 16) / 255,
                parseInt(h.slice(2, 4), 16) / 255,
                parseInt(h.slice(4, 6), 16) / 255
            ];
        }
        var m = css.match(/rgba?\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)/);
        if (m) return [Number(m[1]) / 255, Number(m[2]) / 255, Number(m[3]) / 255];
        return null;
    }

    var FALLBACK = {
        dark:   { p: [0.000, 0.467, 1.000], s: [0.000, 0.831, 0.667], b: [0.027, 0.043, 0.078], l: 0 },
        light:  { p: [0.863, 0.902, 0.941], s: [0.290, 0.333, 0.376], b: [0.604, 0.671, 0.753], l: 0.48, g: [0.271, 0.784, 0.863] },
        aurora: { p: [0.545, 0.361, 0.965], s: [0.925, 0.282, 0.600], b: [0.039, 0.027, 0.078], l: 0 },
        ocean:  { p: [0.055, 0.647, 0.914], s: [0.176, 0.831, 0.749], b: [0.012, 0.075, 0.125], l: 0 }
    };

    function themeId() {
        return document.documentElement.getAttribute('data-theme') || 'dark';
    }

    function readTarget() {
        var id = themeId();
        var fb = FALLBACK[id] || FALLBACK.dark;
        var p, s, b, l, g;
        if (id === 'light') {
            p = fb.p; s = fb.s; b = fb.b; l = fb.l;
            g = fb.g || [0.271, 0.784, 0.863];
        } else {
            var cs = getComputedStyle(document.documentElement);
            p = parseColor(cs.getPropertyValue('--blue')) || fb.p;
            s = parseColor(cs.getPropertyValue('--teal')) || fb.s;
            b = parseColor(cs.getPropertyValue('--bg')) || fb.b;
            l = 0;
            g = [p[0] * 0.72 + s[0] * 0.28, p[1] * 0.72 + s[1] * 0.28, p[2] * 0.72 + s[2] * 0.28];
        }
        return { p: p.slice(), s: s.slice(), b: b.slice(), l: l, g: g.slice() };
    }

    function copy3(a) { return [a[0], a[1], a[2]]; }
    function lerp(a, b, t) { return a + (b - a) * t; }
    function lerp3(a, b, t) { return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)]; }

    var tgt = readTarget();
    var cur = { p: copy3(tgt.p), s: copy3(tgt.s), b: copy3(tgt.b), l: tgt.l, g: copy3(tgt.g) };

    function pullTheme() {
        tgt = readTarget();
    }

    document.documentElement.addEventListener('seenmri-themechange', pullTheme);
    if (window.MutationObserver) {
        new MutationObserver(pullTheme).observe(document.documentElement, {
            attributes: true,
            attributeFilter: ['data-theme']
        });
    }

    var mx = 0.5, my = 0.5;
    var smx = 0.5, smy = 0.5;
    document.addEventListener('mousemove', function (e) {
        mx = e.clientX / window.innerWidth;
        my = 1.0 - e.clientY / window.innerHeight;
    });

    function readScroll() {
        var el = document.documentElement;
        var max = Math.max(1, (el.scrollHeight || 1) - window.innerHeight);
        var y = window.pageYOffset || el.scrollTop || 0;
        if (y < 0) y = 0;
        if (y > max) y = max;
        return y / max;
    }

    /* Critically-damped spring. Slight underdamping (zeta 0.88) gives
       a one-frame settle so the ridges feel like they have mass, without
       bounce. Omega ~ 12 rad/s ≈ 0.5s to rest — Apple-page territory. */
    var OMEGA = 12.0;
    var ZETA = 0.88;
    var scrollTgt = 0;
    var scrollPos = 0;
    var scrollVel = 0;
    var lastTs = 0;

    window.addEventListener('scroll', function () {
        scrollTgt = readScroll();
    }, { passive: true });
    scrollTgt = readScroll();
    scrollPos = scrollTgt;

    var frozen = 0;
    function draw(ts) {
        var t = ts * 0.001;
        if (reduced) t = frozen || (frozen = t);

        var dt = lastTs ? Math.min(0.033, (ts - lastTs) * 0.001) : 0.016;
        lastTs = ts;

        scrollTgt = readScroll();
        if (reduced) {
            scrollPos = scrollTgt;
            scrollVel = 0;
        } else {
            var acc = -2.0 * ZETA * OMEGA * scrollVel - OMEGA * OMEGA * (scrollPos - scrollTgt);
            scrollVel += acc * dt;
            scrollPos += scrollVel * dt;
            if (scrollPos < -0.02) { scrollPos = -0.02; if (scrollVel < 0) scrollVel = 0; }
            if (scrollPos > 1.02)  { scrollPos =  1.02; if (scrollVel > 0) scrollVel = 0; }
        }

        smx += (mx - smx) * 0.04;
        smy += (my - smy) * 0.04;

        var k = 0.08;
        cur.p = lerp3(cur.p, tgt.p, k);
        cur.s = lerp3(cur.s, tgt.s, k);
        cur.b = lerp3(cur.b, tgt.b, k);
        cur.g = lerp3(cur.g, tgt.g, k);
        cur.l = lerp(cur.l, tgt.l, k);

        gl.uniform2f(uRes, canvas.width, canvas.height);
        gl.uniform1f(uTime, t);
        gl.uniform2f(uMouse, smx, smy);
        gl.uniform3f(uPrimary, cur.p[0], cur.p[1], cur.p[2]);
        gl.uniform3f(uSecondary, cur.s[0], cur.s[1], cur.s[2]);
        gl.uniform3f(uBg, cur.b[0], cur.b[1], cur.b[2]);
        gl.uniform3f(uGlow, cur.g[0], cur.g[1], cur.g[2]);
        gl.uniform1f(uLight, cur.l);
        gl.uniform1f(uScroll, scrollPos);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        if (!reduced) requestAnimationFrame(draw);
    }
    requestAnimationFrame(draw);
})();
