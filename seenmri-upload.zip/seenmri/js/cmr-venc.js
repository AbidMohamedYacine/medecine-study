
/* ============ VENC v2 — realistic animated engine ============ */
(function venc2() {
    var mag = document.getElementById('vencMag');
    var ph = document.getElementById('vencPhase');
    var cu = document.getElementById('vencCurve');
    if (!mag || !ph || !cu) return;
    var mc = mag.getContext('2d'), pc = ph.getContext('2d'), cc = cu.getContext('2d');

    var vt = document.getElementById('vencTrue'), vs = document.getElementById('vencSet');
    var clock = 0, lastT = null;

    function vel(t) {
        /* pulsatile aortic flow: systolic upstroke + diastolic trickle */
        if (t < 0.30) return Math.pow(Math.sin((t / 0.30) * Math.PI), 1.25);
        if (t < 0.42) return 0.35 * (1 - (t - 0.30) / 0.12);
        return 0.09 * Math.sin((t - 0.42) / 0.58 * Math.PI * 2);
    }

    function drawAorta(c, mode, v, enc, aliased) {
        var W = mag.width, H = mag.height;
        var cx = W / 2, cy = H / 2, R = W * 0.30;
        c.fillStyle = '#03060d';
        c.fillRect(0, 0, W, H);
        if (mode === 'mag') {
            /* stationary tissue: gray; lumen: blood gray (brighter in systole) */
            c.fillStyle = '#4a4a4a';
            c.fillRect(0, 0, W, H);
            c.fillStyle = 'rgba(0,0,0,0.25)';
            c.beginPath(); c.arc(cx - W * 0.32, cy + H * 0.3, R * 0.5, 0, Math.PI * 2); c.fill();
            c.beginPath(); c.arc(cx + W * 0.34, cy - H * 0.28, R * 0.4, 0, Math.PI * 2); c.fill();
            var lum = 150 + Math.round(Math.max(0, v) * 80);
            c.fillStyle = 'rgb(' + lum + ',' + lum + ',' + lum + ')';
        } else {
            /* stationary tissue: mid-gray (zero phase); lumen colored by phase */
            c.fillStyle = '#808080';
            c.fillRect(0, 0, W, H);
            var phase; /* -1..1 */
            if (Math.abs(v) <= enc) phase = -(v / enc);           /* flow toward head = bright by convention */
            else phase = -((v - Math.sign(v) * 2 * enc) / enc);   /* wrapped */
            var g = Math.round(128 + phase * 118);
            if (aliased) {
                c.fillStyle = 'rgb(' + Math.min(255, g + 60) + ',' + Math.max(0, g - 40) + ',' + Math.max(0, g - 60) + ')';
            } else {
                c.fillStyle = 'rgb(' + g + ',' + g + ',' + g + ')';
            }
        }
        c.beginPath(); c.arc(cx, cy, R, 0, Math.PI * 2); c.fill();
        /* vessel wall rim */
        c.strokeStyle = mode === 'mag' ? 'rgba(30,30,30,0.8)' : 'rgba(60,60,60,0.9)';
        c.lineWidth = 3;
        c.beginPath(); c.arc(cx, cy, R + 2, 0, Math.PI * 2); c.stroke();
        /* labels */
        c.fillStyle = 'rgba(200,215,240,0.75)';
        c.font = '10px monospace';
        if (mode === 'ph') {
            var lv = Math.abs(v) <= enc ? v : v - Math.sign(v) * 2 * enc;
            c.fillText('lumen: ' + Math.round(lv) + ' cm/s', 8, H - 10);
            if (aliased) { c.fillStyle = '#f87171'; c.fillText('ALIASED', 8, 16); }
        } else {
            c.fillText('peak ' + Math.round(Math.max(0, v)) + ' cm/s', 8, H - 10);
        }
    }

    function drawCurve(t, peak, enc) {
        var W = cu.width, H = cu.height;
        cc.fillStyle = '#03060d';
        cc.fillRect(0, 0, W, H);
        var x0 = 34, x1 = W - 10, yMid = H * 0.55;
        var vMaxDraw = 520;
        var yOf = function (v) { return yMid - (v / vMaxDraw) * (H * 0.42); };
        var xOf = function (t) { return x0 + t * (x1 - x0); };

        /* axes */
        cc.strokeStyle = 'rgba(120,160,255,0.25)';
        cc.beginPath(); cc.moveTo(x0, 8); cc.lineTo(x0, H - 18); cc.stroke();
        cc.beginPath(); cc.moveTo(x0, yMid); cc.lineTo(x1, yMid); cc.stroke();
        cc.fillStyle = '#7d92bd'; cc.font = '9px monospace';
        cc.fillText('cm/s', 4, 12);
        cc.fillText('t →', W - 30, H - 6);

        /* ±VENC dashed lines */
        cc.strokeStyle = 'rgba(110,231,183,0.5)';
        cc.setLineDash([4, 4]);
        [enc, -enc].forEach(function (v) {
            cc.beginPath(); cc.moveTo(x0, yOf(v)); cc.lineTo(x1, yOf(v)); cc.stroke();
            cc.fillStyle = '#6ee7b7';
            cc.fillText(String(Math.round(v)), 4, yOf(v) + 3);
        });
        cc.setLineDash([]);

        /* true velocity curve (dim white) */
        cc.strokeStyle = 'rgba(255,255,255,0.35)';
        cc.lineWidth = 1.4;
        cc.beginPath();
        for (var i = 0; i <= 120; i++) {
            var tt = i / 120;
            var v = vel(tt) * peak;
            i ? cc.lineTo(xOf(tt), yOf(v)) : cc.moveTo(xOf(tt), yOf(v));
        }
        cc.stroke();

        /* measured (wrapped) curve — red where aliased */
        var anyAlias = false;
        for (var pass = 0; pass < 2; pass++) {
            cc.beginPath();
            var drawing = false, inAlias = pass === 1;
            for (var j = 0; j <= 120; j++) {
                var tt2 = j / 120;
                var v2 = vel(tt2) * peak;
                var aliased = v2 > enc || v2 < -enc;
                var meas = aliased ? v2 - Math.sign(v2) * 2 * enc : v2;
                if (aliased) anyAlias = true;
                if ((pass === 1) === aliased) {
                    if (!drawing) { cc.moveTo(xOf(tt2), yOf(meas)); drawing = true; }
                    else cc.lineTo(xOf(tt2), yOf(meas));
                } else drawing = false;
            }
            cc.strokeStyle = inAlias ? '#f87171' : '#7dd3fc';
            cc.lineWidth = inAlias ? 2.2 : 2.2;
            cc.stroke();
        }

        /* playhead */
        var hx = xOf(t);
        cc.strokeStyle = 'rgba(255,255,255,0.5)';
        cc.beginPath(); cc.moveTo(hx, 8); cc.lineTo(hx, H - 18); cc.stroke();

        /* legend */
        cc.font = '9px monospace';
        cc.fillStyle = '#7dd3fc'; cc.fillText('measured', x0 + 8, 16);
        if (anyAlias) { cc.fillStyle = '#f87171'; cc.fillText('wrapped (aliased)', x0 + 75, 16); }
        cc.fillStyle = 'rgba(255,255,255,0.45)'; cc.fillText('true', x0 + 205, 16);
    }

    function loop(ts) {
        if (lastT === null) lastT = ts;
        var dt = (ts - lastT) / 1000; lastT = ts;
        clock = (clock + dt / 1.6) % 1;                    /* one cardiac cycle per 1.6 s */

        var peak = parseInt(vt.value, 10);
        var enc = parseInt(vs.value, 10);
        var v = vel(clock) * peak;
        var aliased = v > enc || v < -enc;

        drawAorta(mc, 'mag', v, enc, aliased);
        drawAorta(pc, 'ph', v, enc, aliased);
        drawCurve(clock, peak, enc);

        document.getElementById('vencTrueVal').textContent = peak;
        document.getElementById('vencSetVal').textContent = enc;
        var el = document.getElementById('vencVerdict');
        if (peak <= enc * 0.5) {
            el.className = 'venc-verdict warn';
            el.innerHTML = '<i class="fas fa-triangle-exclamation"></i> VENC far above true peak (' + peak + ' cm/s) — <b>severe underestimation</b> of velocities. Aim within ~25% above peak.';
        } else if (peak <= enc) {
            el.className = 'venc-verdict ok';
            el.innerHTML = '<i class="fas fa-circle-check"></i> Optimal — full curve fits within ±VENC (' + enc + '), measured peak = <b>' + peak + ' cm/s</b>.';
        } else {
            var meas = peak - 2 * enc;
            el.className = 'venc-verdict bad';
            el.innerHTML = '<i class="fas fa-circle-xmark"></i> <b>ALIASED</b> — peak ' + peak + ' cm/s exceeds VENC ' + enc + ': systole wraps past +180° and reads as <b>' + meas + ' cm/s (reverse flow)</b> — watch the red wrapped segment swing below zero.';
        }
        requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);
    document.getElementById('perfPlayBtn');
})();
