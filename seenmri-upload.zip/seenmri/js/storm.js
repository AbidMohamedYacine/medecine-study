/* ============================================================
   SEENmri — RAINBOW FIELD v5 (about-mri page)
   Professional refinement of the alive storm:
   • NO line/ribbon: protons fill a wide organic FIELD across
     the page (two noise-driven density clouds), like spins
     distributed through tissue — nature, not a shape
   • motion is subtle field breathing: slow noise-flow drift
     (curl-ish), depth parallax — no visible loops, no conveyor
   • loop speed drastically reduced (4× slower) and loops are
     invisible: drift wraps softly without pattern seams
   • mouse repel kept (the effect you liked), tuned smoother
   • scroll scrub reveal kept; theme hue ramp kept
   ============================================================ */
(function () {
    'use strict';

    var canvas = document.getElementById('stormCanvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    if (!ctx) return;

    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* ---------- theme hue ramps ---------- */
    var THEME = { dark: [200, 178], light: [215, 168], aurora: [272, 322], ocean: [199, 166] };
    function hueBase() {
        var k = (document.documentElement.getAttribute('data-theme') || 'dark').toLowerCase();
        return THEME[k] || THEME.dark;
    }

    /* ---------- deterministic value noise ---------- */
    function makeNoise(seed) {
        var s = seed || 1;
        function rnd() { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }
        var g = new Float32Array(64 * 64);
        for (var i = 0; i < 64 * 64; i++) g[i] = rnd() * 2 - 1;
        function lat(x, y) { return g[((y & 63) << 6) | (x & 63)]; }
        function fade(t) { return t * t * (3 - 2 * t); }
        return function (x, y) {
            var xi = Math.floor(x), yi = Math.floor(y);
            var tx = fade(x - xi), ty = fade(y - yi);
            var a = lat(xi, yi), b = lat(xi + 1, yi);
            var c = lat(xi, yi + 1), d = lat(xi + 1, yi + 1);
            return a + (b - a) * tx + ((c + (d - c) * tx) - (a + (b - a) * tx)) * ty;
        };
    }

    /* ---------- state ---------- */
    var W = 0, H = 0;
    var N = 9000;
    var P = null;
    var WIN = 0.05, HEAD_START = 0.22;
    var time = 0;
    var flowA = makeNoise(11), flowB = makeNoise(77);   /* field motion noise */
    var densA = makeNoise(31), densB = makeNoise(53);   /* density cloud noise */

    var mouse = { x: -9999, y: -9999, px: -9999, py: -9999, vx: 0, vy: 0, in: false };
    var REPEL_R = 160, REPEL_F = 12;

    function pageSize() {
        var b = document.body, d = document.documentElement;
        return Math.max(b.scrollHeight || 0, d.scrollHeight || 0, window.innerHeight);
    }

    function resize(reseed) {
        W = window.innerWidth;
        H = pageSize();
        canvas.width = W; canvas.height = H;
        canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
        if (reseed !== false || !P || P._h !== H || P._w !== W) seed();
    }

    /* reject-sample a FIELD: uniform positions, kept where noise
       density is high → organic wide clouds, no geometric shape */
    function seed() {
        var arr = [];
        arr._h = H; arr._w = W;
        var i = 0, tries = 0;
        while (i < N && tries < N * 30) {
            tries++;
            var x = ((i * 2654435761 + tries * 40503) % 10000) / 10000 * W;
            var y = (((i * 40503 + tries * 2654435761) % 10000) / 10000) * H;
            /* density: two soft overlapping clouds + gentle page fade at edges */
            var cx1 = W * 0.32, cy1 = H * 0.18;
            var cx2 = W * 0.66, cy2 = H * 0.74;
            function cloud(cx, cy, rx, ry) {
                var dx = (x - cx) / rx, dy = (y - cy) / ry;
                return Math.exp(-dx * dx - dy * dy);
            }
            var d = cloud(cx1, cy1, W * 0.55, H * 0.30) * 0.9 +
                    cloud(cx2, cy2, W * 0.60, H * 0.34) * 0.9 + 0.18;
            /* noise-modulated edges: organic, not elliptical */
            d += densA(x * 0.0016, y * 0.0016) * 0.35 + densB(x * 0.001, y * 0.0012) * 0.3;
            if (((i * 7919 + tries) % 1000) / 1000 > d) continue;   /* rejection */
            var depth = 0.3 + (((i * 2654435761 + 3) % 1000) / 1000) * 0.7;
            arr.push({
                hx: x, hy: y, x: x, y: y, vx: 0, vy: 0,
                depth: depth,
                r: 4.2 + densA(i * 0.01, 2) * 4.2,
                sx: 1 + densA(i * 0.01, 2) * 0.5,
                sy: 1 + densB(i * 0.008, 5) * 0.5,
                rot: densB(i * 0.002, 9) * 270,
                k: (i * 0.3) % 1,
                phase: ((i * 7919) % 628) / 100,
                spark: ((i * 7919) % 97) < 4
            });
            i++;
        }
        /* order by y so scrub + culling stay O(visible) */
        arr.sort(function (a, b2) { return a.hy - b2.hy; });
        /* recompute k for hue by page position (rainbow down the page) */
        for (var j = 0; j < arr.length; j++) arr[j].pos = j / arr.length;
        P = arr;
    }

    function revealHead() {
        var vh = window.innerHeight;
        var sy = window.pageYOffset || 0;
        var docH = H - vh;
        var prog = docH > 0 ? Math.min(1, Math.max(0, sy / docH)) : 0;
        return HEAD_START + prog * (1 + WIN - HEAD_START);
    }

    /* ---------- frame ---------- */
    var running = false, rafId = null, visible = true;
    var lastLit = 0;

    /* motion scale: page-length aware so longer pages don't run faster */
    var FLOW_SPEED = 0.16;

    function frame(ts) {
        if (!running) return;
        if (ts !== undefined) time = ts / 1000;

        var hues = hueBase();
        var span = hues[1] - hues[0];
        var vh = window.innerHeight;
        var sy = window.pageYOffset || 0;
        var head = revealHead();
        var yTop = sy - 200, yBot = sy + vh + 360;

        var mvx = mouse.x - mouse.px, mvy = mouse.y - mouse.py;
        mouse.px = mouse.x; mouse.py = mouse.y;
        mouse.vx = mouse.vx * 0.7 + mvx * 0.3;
        mouse.vy = mouse.vy * 0.7 + mvy * 0.3;

        ctx.clearRect(0, 0, W, H);

        var lit = 0;
        for (var i = 0; i < P.length; i++) {
            var p = P[i];
            if (p.pos > head + WIN) break;
            var t = (head + WIN - p.pos) / WIN;
            if (t <= 0) continue;
            if (t > 1) t = 1;
            lit++;

            /* --- field breathing: slow noise-flow drift, no loops ---
               sample flow at particle's home; two octaves, page-scaled */
            var fx = flowA(p.hx * 0.0022, p.hy * 0.0009 + time * FLOW_SPEED) * 42 +
                     flowB(p.hx * 0.004,  p.hy * 0.0016 - time * FLOW_SPEED * 0.7) * 12;
            var fy = flowB(p.hx * 0.0026, p.hy * 0.0011 + time * FLOW_SPEED * 0.8) * 30 +
                     flowA(p.hx * 0.005,  p.hy * 0.0019 + time * FLOW_SPEED) * 9;
            var micro = Math.sin(time * 0.25 + p.phase) * 3.2;      /* faint shimmer only */
            var tx = p.hx + (fx + micro) * (0.35 + p.depth * 0.75);
            var ty = p.hy + (fy - micro * 0.6) * (0.35 + p.depth * 0.75);

            /* --- mouse repel (kept, smooth) --- */
            var dx = p.x - mouse.x, dy = p.y - mouse.y;
            var d2 = dx * dx + dy * dy;
            if (mouse.in && d2 < REPEL_R * REPEL_R && d2 > 0.01) {
                var d = Math.sqrt(d2);
                var f = (1 - d / REPEL_R);
                var push = f * f * REPEL_F * (0.5 + p.depth * 0.8) +
                           f * (Math.abs(mouse.vx) + Math.abs(mouse.vy)) * 0.3;
                p.vx += (dx / d) * push;
                p.vy += (dy / d) * push;
            }

            p.vx += (tx - p.x) * 0.022;
            p.vy += (ty - p.y) * 0.022;
            p.vx *= 0.85; p.vy *= 0.85;
            p.x += p.vx; p.y += p.vy;

            if (p.y < yTop || p.y > yBot) continue;

            var e = t * t * (3 - 2 * t);
            var alpha = (0.30 + 0.68 * e) * (0.62 + 0.38 * p.depth);
            var scale = (0.22 + 0.78 * e) * (0.55 + 0.6 * p.depth);

            ctx.save();
            ctx.translate(p.x, p.y);
            ctx.rotate(p.rot * 0.04 + Math.sin(time * 0.2 + p.phase) * 0.06);
            ctx.scale(p.sx * scale, p.sy * scale);
            ctx.globalAlpha = alpha;
            ctx.fillStyle = p.spark
                ? 'rgba(238,246,255,1)'
                : 'hsla(' + (hues[0] + p.k * span) + ', 74%, 66%, 1)';
            ctx.beginPath();
            ctx.arc(0, 0, p.r, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }
        lastLit = lit;

        rafId = requestAnimationFrame(frame);
    }
    function start() { if (!rafId && running && visible && !reduced) rafId = requestAnimationFrame(frame); }
    function stop() { if (rafId) { cancelAnimationFrame(rafId); rafId = null; } }

    window.addEventListener('mousemove', function (e) {
        mouse.x = e.clientX; mouse.y = e.clientY + (window.pageYOffset || 0);
        mouse.in = true;
    }, { passive: true });
    document.addEventListener('mouseleave', function () { mouse.in = false; });
    window.addEventListener('resize', function () { resize(); if (reduced) drawStatic(); });
    new MutationObserver(function () { if (reduced) drawStatic(); })
        .observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    document.addEventListener('visibilitychange', function () {
        visible = !document.hidden;
        visible ? start() : stop();
    });
    window.addEventListener('scroll', function () {
        var beyond = (window.pageYOffset || 0) > H + 400;
        if (beyond && running) stop();
        else if (!beyond && !rafId) start();
    }, { passive: true });

    var lastH = 0, checks = 0;
    var timer = setInterval(function () {
        checks++;
        var h = pageSize();
        if (Math.abs(h - lastH) > 60) { lastH = h; resize(); }
        if (checks > 40) clearInterval(timer);
    }, 2500);

    function drawStatic() {
        var hues = hueBase();
        var span = hues[1] - hues[0];
        var vh = window.innerHeight;
        var sy = window.pageYOffset || 0;
        ctx.clearRect(0, 0, W, H);
        for (var i = 0; i < P.length; i++) {
            var p = P[i];
            if (p.y < sy - 100 || p.y > sy + vh + 200) continue;
            ctx.globalAlpha = 0.5 * (0.4 + 0.6 * p.depth);
            ctx.fillStyle = p.spark ? 'rgba(238,246,255,1)' : 'hsla(' + (hues[0] + p.k * span) + ', 74%, 66%, 1)';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r * (0.5 + 0.5 * p.depth), 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.globalAlpha = 1;
        lastLit = P.length;
    }

    resize(true);
    if (reduced) drawStatic();
    else { running = true; start(); }

    window.__storm = {
        ready: true,
        count: function () { return P.length; },
        pageH: function () { return H; },
        lastLitCount: function () { return lastLit; },
        litAt: function (prog) {
            var head = HEAD_START + Math.min(1, Math.max(0, prog)) * (1 + WIN - HEAD_START);
            return Math.min(P.length, Math.round((head + WIN) * P.length));
        },
        mouse: mouse,
        /* field-width diagnostics: spread of x positions */
        xSpread: function () {
            var min = 1e9, max = -1e9;
            for (var i = 0; i < P.length; i += 17) {
                if (P[i].hx < min) min = P[i].hx;
                if (P[i].hx > max) max = P[i].hx;
            }
            return { min: Math.round(min), max: Math.round(max), w: Math.round(max - min) };
        },
        running: function () { return !!rafId; }
    };
})();
