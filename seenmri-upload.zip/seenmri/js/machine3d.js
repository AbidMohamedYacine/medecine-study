/* ============================================================
   SEENmri — MACHINE 3D v4 · "THE MRI SUITE" (unified)
   One scene, two modes:
     ROOM    — orbit a full MRI suite: scanner room + console room
               (control window, desk, monitors, chair, rack, signage…)
               Click the machine (or its hotspot) to open it.
     MACHINE — camera closes in; scroll/slider X-rays the shell and
               slides the components out horizontally (lineup).
   Back button returns to the room. All procedural, offline.
   ============================================================ */
(function () {
    'use strict';
    function $(id) { return document.getElementById(id); }

    var wrap = $('autopsyWrap');
    var stage = $('autopsyStage');
    if (!wrap || !stage) return;

    var infoPanel = $('autopsyInfo');
    var infoBody = $('autopsyInfoBody');
    var slider = $('autopsySlider');
    var progressLbl = $('autopsyProgressLbl');
    var dotsWrap = $('hotspotDots');
    var modeRoomBtn = $('modeRoom');
    var modeMachBtn = $('modeMachine');
    var modeHint = $('autopsyModeHint');

    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    var INFO = {
        machine:  { t: 'The MRI Scanner', d: 'A 1.5/3T superconducting scanner. Click it \u2014 or press \u201cOpen the Machine\u201d \u2014 to X-ray the shell and slide its components out.', f: 'Superconducting \u00b7 bore \u00b7 couch', link: ['#', 'Open it'] },
        window:   { t: 'Control Window', d: 'RF-shielded glass between the console room (Zone II) and the scanner room (Zones III\u2193IV). The technologist watches the patient throughout every sequence.', f: 'Zone II \u2194 III/IV \u00b7 RF glass', link: ['safety.html', 'Safety zones'] },
        console:  { t: 'Console Workstation', d: 'Where the protocol lives: prescription, shim, TR/TE, coil selection and reconstruction \u2014 the real-world twin of our console simulator.', f: 'Prescribe \u00b7 shim \u00b7 recon', link: ['simulator.html', 'Try the simulator'] },
        rack:     { t: 'Coil Rack', d: 'Detachable receiver coils (head, spine, knee, body) docked within reach. Correct coil selection is half of image quality.', f: 'Head \u00b7 spine \u00b7 knee \u00b7 body', link: ['components.html#rf', 'RF coils'] },
        ext:      { t: 'MR-Safe Equipment', d: 'Only MR-conditional / MR-safe gear passes the line: aluminium extinguishers, plastic pumps, titanium trolleys. Everything else stops at the 5-gauss boundary.', f: 'MR-safe \u00b7 5-gauss line', link: ['safety.html', 'MRI safety'] },
        shell: { t: 'Cryostat — Vacuum Vessel', d: 'The scanner\u2019s stainless \u201cthermos\u201d. Layered vacuum chambers block room heat so the liquid helium stays at \u2212269\u00b0C \u2014 the coldest place in the hospital.', f: 'Vacuum \u00b7 \u2212269\u00b0C \u00b7 bore lining', link: ['#', 'The shell'] },
        magnet: { t: 'Superconducting Magnet (B0)', d: 'Niobium-titanium windings bathed in 4 K helium carry current with zero resistance \u2014 a 1.5T/3T field, 30\u201360,000\u00d7 Earth\u2019s. Energised once, on for years.', f: '1.5T / 3T \u00b7 zero resistance', link: ['#magnet', 'Magnet deep-dive'] },
        gradient: { t: 'Gradient Coils — X \u00b7 Y \u00b7 Z', d: 'Three nested coil sets tilt the field for spatial encoding: slice, phase, frequency. Switched thousands of times a second \u2014 the famous knocking.', f: 'Encoding \u00b7 dB/dt \u00b7 knocking', link: ['#gradient', 'Gradients deep-dive'] },
        rf: { t: 'RF Body Coil', d: 'The scanner\u2019s antenna: a runged birdcage lining the bore. Transmits the excitation pulse at the Larmor frequency, then listens for the faint echo.', f: 'Tx + Rx \u00b7 Larmor \u00b7 SAR', link: ['#rf', 'RF deep-dive'] },
        table: { t: 'Patient Table & Shim', d: 'Carbon-fibre couch with laser alignment and a docked head coil; shim coils fine-tune B0 homogeneity \u2014 the secret behind clean fat-sat.', f: 'Laser align \u00b7 shimming', link: ['#shim', 'Shim deep-dive'] }
    };

    function showInfo(key) {
        if (!infoBody) return;
        if (!key) {
            infoBody.innerHTML = mode === 'room'
                ? '<h3>The MRI suite</h3><p>Drag to look around \u00b7 hover anything glowing to inspect it \u00b7 click the scanner to open it.</p>'
                : '<h3>The machine, opened</h3><p>Scroll to X-ray and slide the components apart \u00b7 hover a layer to inspect it \u00b7 drag to orbit.</p>';
            infoPanel.classList.remove('show');
            return;
        }
        var i = INFO[key];
        infoBody.innerHTML = '<h3>' + i.t + '</h3><p>' + i.d + '</p>' +
            '<div class="ai-tags"><span>' + i.f + '</span></div>';
        if (i.link[0] !== '#') {
            infoBody.innerHTML += '<a class="back-cta" style="margin-top:14px;" href="' + i.link[0] + '">' + i.link[1] + ' <i class="fas fa-arrow-right"></i></a>';
        } else if (key === 'machine') {
            infoBody.innerHTML += '<button class="back-cta" style="margin-top:14px;cursor:pointer;" onclick="document.getElementById(\'modeMachine\').click()">Open the Machine <i class="fas fa-arrow-right"></i></button>';
        }
        infoPanel.classList.add('show');
    }

    function fallback() {
        stage.innerHTML =
            '<div class="autopsy-fallback">' +
            '<img src="images/sections/components.jpg" alt="MRI components cutaway">' +
            '<p><i class="fas fa-circle-info"></i> Interactive 3D isn\u2019t available in this browser \u2014 showing the clinical cutaway instead. Scroll on for the full component guide.</p>' +
            '</div>';
        var ctl = stage.parentElement.querySelector('.autopsy-controls');
        if (ctl) ctl.style.display = 'none';
        var mr = stage.parentElement.querySelector('.autopsy-modes');
        if (mr) mr.style.display = 'none';
    }

    if (!window.THREE) { fallback(); return; }

    /* ============================================================
       RENDERER / SCENE
       ============================================================ */
    var renderer;
    try {
        renderer = new THREE.WebGLRenderer({ canvas: $('mri3d'), antialias: true, alpha: true });
    } catch (e) { fallback(); return; }
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    if ('outputEncoding' in renderer) renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;

    var scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x070b14, 0.014);

    var camera = new THREE.PerspectiveCamera(42, 1, 0.1, 260);

    var THEME3 = {
        dark:   { blue: 0x008cff, teal: 0x00d4aa, wall: 0x1b2334, wall2: 0x141b29, floor: 0x0e1421, ceil: 0x0b101b },
        light:  { blue: 0x0066e0, teal: 0x00947a, wall: 0xcdd7e8, wall2: 0xb8c4d8, floor: 0x99a6bd, ceil: 0xbfcadd },
        aurora: { blue: 0x8b5cf6, teal: 0xec4899, wall: 0x241738, wall2: 0x1a1029, floor: 0x150c26, ceil: 0x110a1f },
        ocean:  { blue: 0x0ea5e9, teal: 0x2dd4bf, wall: 0x11344e, wall2: 0x0c2539, floor: 0x081d2f, ceil: 0x0a2233 }
    };
    function theme() {
        var t = (document.documentElement.getAttribute('data-theme') || 'dark').toLowerCase();
        return THEME3[t] || THEME3.dark;
    }

    var key = new THREE.DirectionalLight(0xe8efff, 0.95); key.position.set(6, 9, 7);
    var rimA = new THREE.DirectionalLight(0x008cff, 0.8);  rimA.position.set(-9, 4, -6);
    var rimB = new THREE.DirectionalLight(0x00d4aa, 0.55); rimB.position.set(8, -3, -8);
    var hemi = new THREE.HemisphereLight(0xbcd4ff, 0x0a0f1c, 0.5);
    var boreLight = new THREE.PointLight(0x9fdcff, 0.9, 8);
    scene.add(key, rimA, rimB, hemi, boreLight);
    /* console room's own light */
    var consoleLight = new THREE.PointLight(0xbfd8ff, 0.7, 9);
    consoleLight.position.set(3.4, 3.4, -11);
    scene.add(consoleLight);

    function std(o) { return new THREE.MeshStandardMaterial(o); }
    var M = {
        shellWhite: std({ color: 0xdfe6ee, metalness: 0.15, roughness: 0.32, transparent: true, opacity: 0.97 }),
        copper:     std({ color: 0xc47a3a, metalness: 0.95, roughness: 0.3 }),
        steel:      std({ color: 0x8f9aa8, metalness: 0.9, roughness: 0.35 }),
        darkPlast:  std({ color: 0x1c242f, metalness: 0.35, roughness: 0.55 }),
        midPlast:   std({ color: 0x39434f, metalness: 0.25, roughness: 0.6 }),
        pad:        std({ color: 0x121a26, roughness: 0.95 }),
        glassRing:  std({ color: 0x0a0f18, emissive: 0x00d4aa, emissiveIntensity: 1.15, roughness: 0.5 }),
        rung:       std({ color: 0xbfe8de, metalness: 0.85, roughness: 0.3, emissive: 0x00d4aa, emissiveIntensity: 0.1 }),
        screenOn:   std({ color: 0x0a1220, emissive: 0x2c6fd8, emissiveIntensity: 0.9, roughness: 0.25 }),
        screenOn2:  std({ color: 0x0a1220, emissive: 0x00a88f, emissiveIntensity: 0.85, roughness: 0.25 }),
        glassWin:   std({ color: 0x12233c, emissive: 0x2a4f80, emissiveIntensity: 0.4, roughness: 0.12, metalness: 0.3, transparent: true, opacity: 0.42 })
    };

    /* ============================================================
       MACHINE (5 component layers, horizontal lineup)
       ============================================================ */
    var root = new THREE.Group();
    scene.add(root);
    var layers = {};
    var ORDER = ['shell', 'magnet', 'gradient', 'rf', 'table'];
    var OFFX = { shell: -7.4, magnet: -3.7, gradient: 0, rf: 3.7, table: 7.4 };

    function L(key) {
        var g = new THREE.Group();
        root.add(g);
        layers[key] = { group: g, meshes: [], pickables: [], offX: OFFX[key], anchor: new THREE.Vector3(0, 0.15, 0) };
        return g;
    }
    function add(layerKey, mesh, pickable) {
        mesh.userData.layer = layerKey;
        mesh.userData.origOpacity = mesh.material.opacity !== undefined ? mesh.material.opacity : 1;
        layers[layerKey].meshes.push(mesh);
        if (pickable !== false) layers[layerKey].pickables.push(mesh);
        layers[layerKey].group.add(mesh);
        return mesh;
    }

    /* SHELL */
    (function () {
        L('shell');
        var LEN = 4.6, RAD = 2.28;
        var body = new THREE.Mesh(new THREE.CylinderGeometry(RAD, RAD, LEN, 64, 1, true), M.shellWhite);
        body.rotation.z = Math.PI / 2;
        add('shell', body);
        [-1, 1].forEach(function (s) {
            var shoulder = new THREE.Mesh(new THREE.CylinderGeometry(RAD, RAD * 0.86, 0.5, 64, 1, true), M.shellWhite);
            shoulder.rotation.z = (Math.PI / 2) * s;
            shoulder.position.x = s * (LEN / 2 + 0.22);
            add('shell', shoulder);
            var face = new THREE.Mesh(new THREE.CylinderGeometry(RAD * 0.86, RAD * 0.86, 0.34, 64),
                std({ color: 0x1c242f, metalness: 0.4, roughness: 0.5, transparent: true, opacity: 0.97 }));
            face.rotation.z = Math.PI / 2;
            face.position.x = s * (LEN / 2 + 0.55);
            add('shell', face);
            var rim = new THREE.Mesh(new THREE.TorusGeometry(1.62, 0.055, 12, 64), M.glassRing);
            rim.rotation.y = Math.PI / 2;
            rim.position.x = s * (LEN / 2 + 0.72);
            add('shell', rim, false);
            for (var b = 0; b < 12; b++) {
                var a = (b / 12) * Math.PI * 2 + 0.13;
                var bolt = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.1, 8), M.steel);
                bolt.rotation.z = Math.PI / 2;
                bolt.position.set(s * (LEN / 2 + 0.68), Math.cos(a) * 1.95, Math.sin(a) * 1.95);
                add('shell', bolt, false);
            }
        });
        var bore = new THREE.Mesh(new THREE.CylinderGeometry(1.55, 1.55, LEN + 1.5, 48, 1, true),
            std({ color: 0x05070c, roughness: 1, side: THREE.BackSide, transparent: true, opacity: 0.97 }));
        bore.rotation.z = Math.PI / 2;
        add('shell', bore, false);
        var glow = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.5, 2.6, 32, 1, true),
            std({ color: 0x0b1524, emissive: 0x1c4c7c, emissiveIntensity: 0.55, side: THREE.BackSide }));
        glow.rotation.z = Math.PI / 2;
        add('shell', glow, false);
        [-1.35, 0.35].forEach(function (x) {
            var seam = new THREE.Mesh(new THREE.TorusGeometry(RAD + 0.005, 0.018, 8, 64),
                std({ color: 0x9aa5b3, metalness: 0.6, roughness: 0.5 }));
            seam.rotation.y = Math.PI / 2;
            seam.position.x = x;
            add('shell', seam, false);
        });
        var strip = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.06, 0.5),
            std({ color: 0x0a0f18, emissive: 0x008cff, emissiveIntensity: 0.85, roughness: 0.5 }));
        strip.position.set(0.4, RAD + 0.005, 0);
        add('shell', strip, false);
        var cab = new THREE.Mesh(new THREE.BoxGeometry(0.9, 3.2, 3.4),
            std({ color: 0xcfd6df, metalness: 0.2, roughness: 0.45, transparent: true, opacity: 0.97 }));
        cab.position.set(-(LEN / 2) - 1.1, 0, 0);
        add('shell', cab);
        var cabVent = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.4, 2.2), std({ color: 0x141a24, roughness: 0.9 }));
        cabVent.position.set(-(LEN / 2) - 1.58, 0.4, 0);
        add('shell', cabVent, false);
    })();

    /* MAGNET */
    (function () {
        L('magnet');
        var former = new THREE.Mesh(new THREE.CylinderGeometry(2.02, 2.02, 4.0, 48, 1, true),
            std({ color: 0x39434f, metalness: 0.3, roughness: 0.7, side: THREE.DoubleSide, transparent: true, opacity: 0.55 }));
        former.rotation.z = Math.PI / 2;
        add('magnet', former, false);
        for (var i = 0; i < 15; i++) {
            var w = new THREE.Mesh(new THREE.TorusGeometry(1.94, 0.115, 14, 48), M.copper);
            w.rotation.y = Math.PI / 2;
            w.position.x = -1.86 + i * 0.265;
            add('magnet', w);
        }
        [-2.1, 2.1].forEach(function (x) {
            var ring = new THREE.Mesh(new THREE.TorusGeometry(2.02, 0.09, 10, 48), M.steel);
            ring.rotation.y = Math.PI / 2;
            ring.position.x = x;
            add('magnet', ring);
        });
        var coldHead = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.28, 0.7, 20), M.steel);
        coldHead.position.set(0.8, 2.28, 0);
        add('magnet', coldHead);
        var compressor = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.5, 0.7),
            std({ color: 0x2a3442, metalness: 0.7, roughness: 0.4 }));
        compressor.position.set(2.1, 2.75, 0);
        add('magnet', compressor);
    })();

    /* GRADIENTS */
    (function () {
        L('gradient');
        [{ r: 1.8, col: 0x5a6a86 }, { r: 1.64, col: 0x00d4aa }, { r: 1.48, col: 0x008cff }].forEach(function (d) {
            var cyl = new THREE.Mesh(new THREE.CylinderGeometry(d.r, d.r, 4.1, 44, 1, true),
                std({ color: d.col, metalness: 0.5, roughness: 0.5, transparent: true, opacity: 0.2, side: THREE.DoubleSide }));
            cyl.rotation.z = Math.PI / 2;
            add('gradient', cyl);
            [-1, 1].forEach(function (s) {
                var ring = new THREE.Mesh(new THREE.TorusGeometry(d.r, 0.035, 8, 44),
                    std({ color: d.col, emissive: d.col, emissiveIntensity: 0.5, transparent: true, opacity: 0.95 }));
                ring.rotation.y = Math.PI / 2;
                ring.position.x = s * 2.05;
                add('gradient', ring, false);
            });
        });
        var amp = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.5, 1.1),
            std({ color: 0x1c242f, metalness: 0.6, roughness: 0.45 }));
        amp.position.set(0, 1.9, 1.3);
        add('gradient', amp);
    })();

    /* RF */
    (function () {
        L('rf');
        var tube = new THREE.Mesh(new THREE.CylinderGeometry(1.34, 1.34, 3.6, 40, 1, true),
            std({ color: 0x00d4aa, metalness: 0.4, roughness: 0.55, transparent: true, opacity: 0.08, side: THREE.DoubleSide }));
        tube.rotation.z = Math.PI / 2;
        add('rf', tube, false);
        for (var i = 0; i < 16; i++) {
            var a = (i / 16) * Math.PI * 2;
            var rung = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 3.5, 8), M.rung);
            rung.position.set(0, Math.cos(a) * 1.31, Math.sin(a) * 1.31);
            add('rf', rung, false);
        }
        [-1, 1].forEach(function (s) {
            var endRing = new THREE.Mesh(new THREE.TorusGeometry(1.31, 0.05, 10, 44), M.rung);
            endRing.rotation.y = Math.PI / 2;
            endRing.position.x = s * 1.78;
            add('rf', endRing, false);
        });
        var conn = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.5, 0.9),
            std({ color: 0x222b38, metalness: 0.5, roughness: 0.5 }));
        conn.position.set(1.95, 0.6, 0.8);
        add('rf', conn);
    })();

    /* TABLE */
    (function () {
        L('table');
        var couch = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.16, 1.0),
            std({ color: 0x39434f, metalness: 0.35, roughness: 0.5 }));
        couch.position.set(1.1, -0.42, 0);
        add('table', couch);
        var mattress = new THREE.Mesh(new THREE.BoxGeometry(4.3, 0.09, 0.86), M.pad);
        mattress.position.set(1.1, -0.3, 0);
        add('table', mattress, false);
        var headRest = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.1, 0.6),
            std({ color: 0x1a2330, roughness: 0.85 }));
        headRest.position.set(2.9, -0.24, 0);
        add('table', headRest, false);
        var hcRing1 = new THREE.Mesh(new THREE.TorusGeometry(0.32, 0.045, 10, 32),
            std({ color: 0xbfe8de, metalness: 0.8, roughness: 0.3 }));
        hcRing1.rotation.y = Math.PI / 2;
        hcRing1.position.set(2.75, -0.06, 0);
        add('table', hcRing1, false);
        var hcRing2 = hcRing1.clone(); hcRing2.position.x = 3.3;
        add('table', hcRing2, false);
        var ped = new THREE.Mesh(new THREE.BoxGeometry(0.55, 1.0, 0.55),
            std({ color: 0x2a3442, metalness: 0.7, roughness: 0.35 }));
        ped.position.set(2.35, -1.0, 0);
        add('table', ped);
        var base = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.18, 1.15),
            std({ color: 0x1c242f, metalness: 0.8, roughness: 0.3 }));
        base.position.set(2.35, -1.55, 0);
        add('table', base);
    })();

    /* ============================================================
       THE SUITE — scanner room + console room (through window)
       ============================================================ */
    var room = new THREE.Group();
    scene.add(room);
    var roomMats = [];
    function roomMesh(geo, mat) {
        mat.transparent = true;
        roomMats.push(mat);
        var m = new THREE.Mesh(geo, mat);
        room.add(m);
        return m;
    }
    var roomPick = [];   /* interactive room objects */
    function roomHot(geo, mat, key, pick) {
        var m = roomMesh(geo, mat);
        m.userData.roomKey = key;
        if (pick !== false) roomPick.push(m);
        return m;
    }

    (function () {
        var T = theme();
        /* floor + ceiling + walls of scanner room */
        var floor = roomMesh(new THREE.PlaneGeometry(30, 22), std({ color: T.floor, roughness: 0.85 }));
        floor.rotation.x = -Math.PI / 2; floor.position.set(0, -2.72, 0);
        var ceil = roomMesh(new THREE.PlaneGeometry(30, 22), std({ color: T.ceil, roughness: 0.95 }));
        ceil.rotation.x = Math.PI / 2; ceil.position.set(0, 6.4, 0);
        var wallBack = roomMesh(new THREE.PlaneGeometry(30, 9.2), std({ color: T.wall, roughness: 0.95 }));
        wallBack.position.set(0, 1.0, -9);
        var wallLeft = roomMesh(new THREE.PlaneGeometry(18, 9.2), std({ color: T.wall2, roughness: 0.95 }));
        wallLeft.rotation.y = Math.PI / 2; wallLeft.position.set(-13, 1.0, 0);
        var wallRight = roomMesh(new THREE.PlaneGeometry(18, 9.2), std({ color: T.wall2, roughness: 0.95 }));
        wallRight.rotation.y = -Math.PI / 2; wallRight.position.set(13, 1.0, 0);

        /* —— CONTROL WINDOW (back wall) with frame + glowing glass —— */
        var wf = roomHot(new THREE.BoxGeometry(5.6, 2.7, 0.32), std({ color: 0x2a3442, metalness: 0.6, roughness: 0.4 }), 'window');
        wf.position.set(3.4, 2.3, -8.85);
        var glass = roomHot(new THREE.PlaneGeometry(5.1, 2.2), M.glassWin, 'window', false);
        glass.position.set(3.4, 2.3, -8.66);

        /* —— CONSOLE ROOM behind the window —— */
        var cFloor = roomMesh(new THREE.PlaneGeometry(12, 9), std({ color: T.floor, roughness: 0.85 }));
        cFloor.rotation.x = -Math.PI / 2; cFloor.position.set(3.4, -2.72, -13.4);
        var cCeil = roomMesh(new THREE.PlaneGeometry(12, 9), std({ color: T.ceil, roughness: 0.95 }));
        cCeil.rotation.x = Math.PI / 2; cCeil.position.set(3.4, 6.4, -13.4);
        var cBack = roomMesh(new THREE.PlaneGeometry(12, 9.2), std({ color: T.wall, roughness: 0.95 }));
        cBack.position.set(3.4, 1.0, -17.8);
        var cSide = roomMesh(new THREE.PlaneGeometry(8.6, 9.2), std({ color: T.wall2, roughness: 0.95 }));
        cSide.rotation.y = -Math.PI / 2; cSide.position.set(9.4, 1.0, -13.4);

        /* the console desk with 3 monitors + keyboard + PC */
        var desk = roomHot(new THREE.BoxGeometry(4.6, 0.12, 1.5), std({ color: 0x2e3947, metalness: 0.3, roughness: 0.55 }), 'console');
        desk.position.set(3.4, -1.15, -12.1);
        [[2.1, 'l'], [3.4, 'c'], [4.7, 'r']].forEach(function (mm) {
            var stand = roomMesh(new THREE.CylinderGeometry(0.06, 0.09, 0.42, 10), M.darkPlast);
            stand.position.set(mm[0], -0.88, -12.35);
            var scr = roomHot(new THREE.BoxGeometry(1.16, 0.72, 0.06),
                mm[1] === 'c' ? M.screenOn : (mm[1] === 'l' ? M.screenOn2 : M.screenOn), 'console', false);
            scr.position.set(mm[0], -0.38, -12.4);
            if (mm[1] === 'r') scr.rotation.y = -0.35;
            if (mm[1] === 'l') scr.rotation.y = 0.35;
        });
        var kbd = roomMesh(new THREE.BoxGeometry(0.95, 0.04, 0.35), M.darkPlast);
        kbd.position.set(3.4, -1.05, -11.7);
        var mouse = roomMesh(new THREE.BoxGeometry(0.12, 0.045, 0.2), M.darkPlast);
        mouse.position.set(4.15, -1.05, -11.65);
        var pc = roomMesh(new THREE.BoxGeometry(0.5, 1.1, 0.55), std({ color: 0x161d28, metalness: 0.5, roughness: 0.5 }));
        pc.position.set(5.6, -2.1, -12.2);
        var pcLed = roomMesh(new THREE.BoxGeometry(0.03, 0.16, 0.1),
            std({ color: 0x0a0f18, emissive: 0x22c55e, emissiveIntensity: 1 }));
        pcLed.position.set(5.35, -1.7, -11.92);
        var chairSeat = roomMesh(new THREE.CylinderGeometry(0.42, 0.42, 0.14, 20), M.midPlast);
        chairSeat.position.set(3.4, -2.05, -10.9);
        var chairBack = roomMesh(new THREE.BoxGeometry(0.75, 0.9, 0.12), M.midPlast);
        chairBack.position.set(3.4, -1.55, -10.55);
        var chairPost = roomMesh(new THREE.CylinderGeometry(0.06, 0.06, 0.55, 8), M.steel);
        chairPost.position.set(3.4, -2.4, -10.9);
        var chairBase = roomMesh(new THREE.CylinderGeometry(0.42, 0.42, 0.06, 16), M.steel);
        chairBase.position.set(3.4, -2.68, -10.9);
        /* second workstation (reporting) */
        var desk2 = roomMesh(new THREE.BoxGeometry(3.2, 0.12, 1.3), std({ color: 0x2e3947, metalness: 0.3, roughness: 0.55 }));
        desk2.position.set(7.6, -1.15, -13.6);
        var scr2 = roomMesh(new THREE.BoxGeometry(1.35, 0.85, 0.06), M.screenOn);
        scr2.position.set(7.6, -0.5, -14.0);

        /* ceiling light strips (scanner room) */
        [-4.5, 1.5].forEach(function (z) {
            var strip = roomMesh(new THREE.BoxGeometry(18, 0.12, 0.7),
                std({ color: 0x0e141f, emissive: 0xbcd8ff, emissiveIntensity: 0.8 }));
            strip.position.set(0, 6.28, z);
        });
        /* console room strip */
        var cStrip = roomMesh(new THREE.BoxGeometry(7, 0.12, 0.6),
            std({ color: 0x0e141f, emissive: 0xd8e8ff, emissiveIntensity: 0.9 }));
        cStrip.position.set(3.4, 6.28, -12.6);

        /* waveguide penetration panel */
        var panel = roomMesh(new THREE.BoxGeometry(2.6, 1.6, 0.18), std({ color: 0x8f9aa8, metalness: 0.7, roughness: 0.4 }));
        panel.position.set(-5.5, 2.4, -8.9);
        for (var i = 0; i < 5; i++) {
            var wg = roomMesh(new THREE.CylinderGeometry(0.07, 0.07, 0.3, 10),
                std({ color: 0xc7ccd4, metalness: 0.85, roughness: 0.3 }));
            wg.rotation.x = Math.PI / 2;
            wg.position.set(-6.3 + i * 0.4, 2.4, -8.78);
        }

        /* coil rack with coils */
        var rp1 = roomHot(new THREE.BoxGeometry(0.14, 3.4, 0.14), std({ color: 0x39434f, metalness: 0.6, roughness: 0.4 }), 'rack');
        rp1.position.set(-10.5, -1.0, -6.5);
        var rp2 = rp1.clone(); rp2.position.x = -8.7; room.add(rp2);
        [0.2, 1.0, 1.8].forEach(function (y, i) {
            var shelf = roomMesh(new THREE.BoxGeometry(2.0, 0.08, 0.8), std({ color: 0x2a3442, metalness: 0.5, roughness: 0.5 }));
            shelf.position.set(-9.6, -2.6 + y, -6.5);
            var coil = roomHot(new THREE.TorusGeometry(0.34 + i * 0.05, 0.06, 10, 30),
                std({ color: 0x1c242f, metalness: 0.6, roughness: 0.4 }), 'rack', false);
            coil.rotation.x = Math.PI / 2.4;
            coil.position.set(-9.6, -2.1 + y, -6.45);
        });

        /* MR-safe extinguisher + glowing sign */
        var ext = roomHot(new THREE.CylinderGeometry(0.16, 0.16, 0.62, 16),
            std({ color: 0xb02328, metalness: 0.4, roughness: 0.45 }), 'ext');
        ext.position.set(-12.3, -2.35, -7.2);
        var sign = roomMesh(new THREE.PlaneGeometry(0.95, 0.45),
            std({ color: 0x0a0f18, emissive: 0x00d4aa, emissiveIntensity: 0.8 }));
        sign.position.set(-12.3, -1.55, -7.18);

        /* caution floor ring */
        var ring = roomMesh(new THREE.TorusGeometry(4.6, 0.045, 8, 80),
            std({ color: 0x0d1219, emissive: 0xf5c542, emissiveIntensity: 0.5, roughness: 0.6 }));
        ring.rotation.x = -Math.PI / 2; ring.position.y = -2.7;

        /* door on the right wall */
        var doorFrame = roomMesh(new THREE.BoxGeometry(0.3, 4.4, 2.6), std({ color: 0x2a3442, metalness: 0.4, roughness: 0.5 }));
        doorFrame.position.set(12.95, -0.4, 4.0);
        var door = roomMesh(new THREE.PlaneGeometry(2.2, 4.0), std({ color: 0x39434f, metalness: 0.3, roughness: 0.6 }));
        door.rotation.y = -Math.PI / 2; door.position.set(12.9, -0.6, 4.0);
        var zoneSign = roomMesh(new THREE.PlaneGeometry(1.3, 0.55),
            std({ color: 0x0a0f18, emissive: 0xf5c542, emissiveIntensity: 0.7 }));
        zoneSign.rotation.y = -Math.PI / 2; zoneSign.position.set(12.85, 1.9, 4.0);
    })();

    /* x-ray sweep ring */
    var sweep = new THREE.Mesh(new THREE.TorusGeometry(2.55, 0.02, 8, 72),
        new THREE.MeshBasicMaterial({ color: 0x00d4aa, transparent: true, opacity: 0 }));
    sweep.rotation.y = Math.PI / 2;
    scene.add(sweep);

    /* ============================================================
       MODES + HOTSPOT DOTS
       ============================================================ */
    var mode = 'room';
    var ROOM_DOTS = [
        { key: 'machine', at: new THREE.Vector3(0, 2.7, 0) },
        { key: 'window',  at: new THREE.Vector3(3.4, 3.4, -8.6) },
        { key: 'console', at: new THREE.Vector3(3.4, -0.1, -12.2) },
        { key: 'rack',    at: new THREE.Vector3(-9.6, 1.3, -6.5) },
        { key: 'ext',     at: new THREE.Vector3(-12.3, -1.5, -7.2) }
    ];
    var dots = [];
    if (dotsWrap) {
        ROOM_DOTS.forEach(function (rd) {
            var el = document.createElement('button');
            el.className = 'mach-dot room-dot';
            el.setAttribute('aria-label', INFO[rd.key].t);
            el.innerHTML = '<i class="fas fa-plus"></i>';
            el.addEventListener('click', function () {
                if (rd.key === 'machine') setMode('machine');
                else roomSelect(rd.key);
            });
            dotsWrap.appendChild(el);
            dots.push({ key: rd.key, at: rd.at, el: el, roomOnly: true });
        });
        ORDER.forEach(function (k) {
            var el = document.createElement('button');
            el.className = 'mach-dot';
            el.setAttribute('aria-label', INFO[k].t);
            el.innerHTML = '<i class="fas fa-plus"></i>';
            el.addEventListener('click', function () { select(k); });
            dotsWrap.appendChild(el);
            dots.push({ key: k, at: null, el: el, roomOnly: false });
        });
    }

    var selected = null, hovered = null;

    function setMode(m) {
        mode = m;
        if (modeRoomBtn) modeRoomBtn.classList.toggle('active', m === 'room');
        if (modeMachBtn) modeMachBtn.classList.toggle('active', m === 'machine');
        if (modeHint) modeHint.textContent = m === 'room'
            ? 'Drag to look around \u00b7 hover glowing items \u00b7 click the scanner to open it'
            : 'Scroll to X-ray \u00b7 keep scrolling to slide the components out \u00b7 drag to orbit';
        dots.forEach(function (d) { d.el.style.display = (d.roomOnly === (m === 'room')) ? '' : 'none'; });
        if (m === 'room') {
            target = 0; smooth = 0;
            apply(0);
        }
        showInfo(null);
    }
    if (modeRoomBtn) modeRoomBtn.addEventListener('click', function () { setMode('room'); });
    if (modeMachBtn) modeMachBtn.addEventListener('click', function () { setMode('machine'); });

    function roomSelect(key) {
        selected = key;
        showInfo(key);
        /* highlight the picked room object briefly via dots only (keep simple) */
    }
    function select(key) {
        selected = key;
        hovered = key;
        ORDER.forEach(function (k) {
            var ly = layers[k];
            var on = k === key;
            ly.meshes.forEach(function (m) {
                var mm = m.material;
                if (!mm) return;
                if (on) {
                    if (mm.emissive) { mm.emissive.setHex(0x00d4aa); mm.emissiveIntensity = 0.35; }
                    mm.opacity = m.userData.origOpacity;
                } else {
                    if (mm.emissive) mm.emissiveIntensity = 0;
                    mm.opacity = m.userData.origOpacity * 0.28;
                    mm.transparent = true;
                }
            });
        });
        dots.forEach(function (d) {
            if (!d.roomOnly) d.el.classList.toggle('on', d.key === key);
        });
        showInfo(key);
    }
    function deselect() {
        selected = null; hovered = null;
        ORDER.forEach(function (k) {
            layers[k].meshes.forEach(function (m) {
                var mm = m.material;
                if (!mm) return;
                if (mm.emissive) mm.emissiveIntensity = 0;
                m.material.opacity = m.userData.origOpacity;
            });
        });
        dots.forEach(function (d) { if (!d.roomOnly) d.el.classList.remove('on'); });
        showInfo(null);
    }

    /* ============================================================
       PROGRESS
       ============================================================ */
    var target = 0, smooth = 0;
    var EX_START = 0.24, EX_END = 0.94, XRAY_END = 0.2;
    var R0 = 11.2, R1 = 17.6;
    var camGoal = { tx: 0, ty: 0.5, R: 16.8 };
    var cur = { tx: 0, ty: 0.5, R: 16.8 };
    var az = 1.05, azT = 1.05, pol = 1.24, polT = 1.24;

    function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
    function ease(t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; }

    function apply(p) {
        var xr = clamp01(p / XRAY_END);
        if (xr > 0 && xr < 1) { sweep.material.opacity = 0.95; sweep.position.x = -3 + xr * 6; }
        else sweep.material.opacity = 0;

        var shellO = 0.97 - 0.85 * clamp01((p - 0.05) / 0.18);
        layers.shell.meshes.forEach(function (m) {
            if (m.material === M.glassRing) return;
            m.material.opacity = Math.min(m.userData.origOpacity, shellO);
        });

        var ex = ease(clamp01((p - EX_START) / (EX_END - EX_START)));
        ORDER.forEach(function (k) { layers[k].group.position.x = layers[k].offX * ex; });

        var roomO = mode === 'room' ? 1 : 1 - clamp01((p - 0.14) / 0.16);
        roomMats.forEach(function (mm) { mm.opacity = roomO; });
        room.visible = roomO > 0.02;

        if (mode === 'room') { camGoal.R = 16.8; camGoal.tx = 0.8; camGoal.ty = 0.7; }
        else { camGoal.R = R0 + (R1 - R0) * ex; camGoal.tx = 0; camGoal.ty = 0.2; }

        var vis = mode === 'machine' ? clamp01((p - 0.58) / 0.26) : 0;
        if (progressLbl) {
            if (mode === 'room') progressLbl.textContent = 'SUITE VIEW \u2014 CLICK THE SCANNER TO OPEN IT';
            else if (p < XRAY_END) progressLbl.textContent = 'X-RAY SWEEP \u2026 ' + Math.round(xr * 100) + '%';
            else if (ex < 1) progressLbl.textContent = 'SLIDING APART \u2026 ' + Math.round(ex * 100) + '%';
            else progressLbl.textContent = 'LINEUP \u2014 hover a component';
        }
        if (dotsWrap) dotsWrap.style.opacity = (mode === 'room' ? 1 : vis).toFixed(2);
    }

    /* ============================================================
       LOOP
       ============================================================ */
    var V = new THREE.Vector3();
    var running = false, rafId = null, inView = false;
    var dragging = false, lastPX = 0, lastPY = 0;

    function frame() {
        if (!running) return;
        smooth += (target - smooth) * (reduced ? 1 : 0.09);
        if (Math.abs(target - smooth) < 0.0005) smooth = target;

        if (!dragging && !reduced) azT += mode === 'room' ? 0.0012 : 0.0014;
        az += (azT - az) * 0.07;
        pol += (polT - pol) * 0.07;
        cur.tx += (camGoal.tx - cur.tx) * 0.06;
        cur.ty += (camGoal.ty - cur.ty) * 0.06;
        cur.R += (camGoal.R - cur.R) * 0.06;

        apply(smooth);

        camera.position.set(
            cur.tx + cur.R * Math.sin(pol) * Math.sin(az),
            cur.ty + cur.R * Math.cos(pol),
            cur.R * Math.sin(pol) * Math.cos(az)
        );
        camera.lookAt(cur.tx, cur.ty, 0);

        if (dotsWrap) {
            var r = stage.getBoundingClientRect();
            dots.forEach(function (d) {
                if (d.el.style.display === 'none') return;
                if (d.roomOnly) V.copy(d.at);
                else V.copy(layers[d.key].group.position).add(layers[d.key].anchor);
                V.project(camera);
                d.el.style.transform = 'translate(' + ((V.x * 0.5 + 0.5) * r.width).toFixed(1) + 'px,' +
                    ((-V.y * 0.5 + 0.5) * r.height).toFixed(1) + 'px) translate(-50%,-50%)';
            });
        }

        try { renderer.render(scene, camera); }
        catch (err) { stop(); fallback(); return; }
        rafId = requestAnimationFrame(frame);
    }
    function start() { if (!rafId && running) rafId = requestAnimationFrame(frame); }
    function stop() { if (rafId) { cancelAnimationFrame(rafId); rafId = null; } }

    /* ============================================================
       INPUT
       ============================================================ */
    var cvs = $('mri3d');

    function onScroll() {
        var r = wrap.getBoundingClientRect();
        var total = r.height - window.innerHeight;
        if (total <= 0) return;
        var t = clamp01(-r.top / total);
        /* scrolling into the runway auto-opens the machine */
        if (mode === 'room' && t > 0.08) setMode('machine');
        target = mode === 'machine' ? t : 0;
        if (slider && document.activeElement !== slider) slider.value = String(Math.round(target * 100));
        if ((reduced || !rafId) && mode === 'machine') smooth = target;
    }
    window.addEventListener('scroll', onScroll, { passive: true });

    if (slider) slider.addEventListener('input', function () {
        if (mode === 'room') setMode('machine');
        target = parseInt(slider.value, 10) / 100;
    });

    if (cvs) {
        cvs.style.touchAction = 'pan-y';
        cvs.addEventListener('pointerdown', function (e) {
            dragging = true; lastPX = e.clientX; lastPY = e.clientY;
            if (cvs.setPointerCapture) { try { cvs.setPointerCapture(e.pointerId); } catch (er) {} }
        });
        cvs.addEventListener('pointermove', function (e) {
            if (dragging) {
                azT -= (e.clientX - lastPX) * 0.005;
                polT = Math.min(1.52, Math.max(0.9, polT - (e.clientY - lastPY) * 0.004));
                lastPX = e.clientX; lastPY = e.clientY;
            } else raypick(e);
        });
        cvs.addEventListener('pointerup', function () { dragging = false; });
        cvs.addEventListener('pointerleave', function () { if (!selected) deselect(); });
        cvs.addEventListener('click', function (e) {
            var k = raypick(e, true);
            if (k === '__machine__') { setMode('machine'); return; }
            if (k) {
                if (mode === 'machine' && ORDER.indexOf(k) !== -1) select(k);
                else if (mode === 'room') roomSelect(k);
            } else if (selected) deselect();
        });
    }

    var ray = new THREE.Raycaster();
    var ptr = new THREE.Vector2();
    function raypick(e, quiet) {
        if (!cvs) return null;
        var r = cvs.getBoundingClientRect();
        ptr.x = ((e.clientX - r.left) / r.width) * 2 - 1;
        ptr.y = -((e.clientY - r.top) / r.height) * 2 + 1;
        ray.setFromCamera(ptr, camera);

        if (mode === 'room') {
            /* machine first (so it's clickable through/over room), then room items */
            var mach = [];
            ORDER.forEach(function (k) { layers[k].pickables.forEach(function (m) { mach.push(m); }); });
            var hm = ray.intersectObjects(mach, false);
            if (hm.length) { if (!quiet) roomSelect('machine'); return '__machine__'; }
            var hr = ray.intersectObjects(roomPick, false);
            for (var i = 0; i < hr.length; i++) {
                var rk = hr[i].object.userData.roomKey;
                if (!rk) continue;
                if (!quiet) roomSelect(rk);
                return rk;
            }
            if (!quiet && selected) { selected = null; showInfo(null); }
            return null;
        }

        /* machine mode */
        var pickables = [];
        ORDER.forEach(function (k) {
            if (k === 'shell' && smooth > 0.35) return;
            layers[k].pickables.forEach(function (m) { pickables.push(m); });
        });
        if (smooth <= 0.35) layers.shell.pickables.forEach(function (m) { pickables.push(m); });
        var hits = ray.intersectObjects(pickables, false);
        for (var j = 0; j < hits.length; j++) {
            var k2 = hits[j].object.userData.layer;
            if (!k2) continue;
            if (!quiet && hovered !== k2) select(k2);
            return k2;
        }
        if (!quiet && !selected) deselect();
        return null;
    }

    function retheme() {
        var T = theme();
        var id = (document.documentElement.getAttribute('data-theme') || 'dark').toLowerCase();
        var isLight = id === 'light';

        rimA.color.setHex(T.blue);
        rimB.color.setHex(T.teal);
        sweep.material.color.setHex(T.teal);
        M.glassRing.emissive.setHex(T.teal);
        layers.gradient.meshes.forEach(function (m) {
            var p = m.geometry && m.geometry.parameters;
            if (p && p.radius === 1.64) { m.material.color.setHex(T.teal); m.material.emissive.setHex(T.teal); }
            if (p && p.radius === 1.48) { m.material.color.setHex(T.blue); m.material.emissive.setHex(T.blue); }
        });

        roomMats.forEach(function (mm) {
            if (!mm.color) return;
            var hx = mm.color.getHex();
            var role = mm.userData.roomRole;
            if (!role) {
                Object.keys(THEME3).forEach(function (k) {
                    var P = THEME3[k];
                    if (hx === P.wall) role = 'wall';
                    else if (hx === P.wall2) role = 'wall2';
                    else if (hx === P.floor) role = 'floor';
                    else if (hx === P.ceil) role = 'ceil';
                });
                if (role) mm.userData.roomRole = role;
            }
            if (role) mm.color.setHex(T[role]);
        });

        hemi.intensity = isLight ? 0.78 : 0.5;
        hemi.color.setHex(isLight ? 0xeef3fb : 0xbcd4ff);
        hemi.groundColor.setHex(isLight ? 0x9aabc0 : 0x0a0f1c);
        key.intensity = isLight ? 1.06 : 0.95;
        key.color.setHex(isLight ? 0xfffaf0 : 0xe8efff);
        renderer.toneMappingExposure = isLight ? 1.02 : 1.1;
        if (scene.fog) {
            scene.fog.color.setHex(isLight ? 0xd8e2ee : 0x070b14);
            scene.fog.density = isLight ? 0.007 : 0.014;
        }
    }
    new MutationObserver(retheme).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

    function resize() {
        var r = stage.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) return;
        renderer.setSize(r.width, r.height, false);
        camera.aspect = r.width / r.height;
        camera.updateProjectionMatrix();
    }
    window.addEventListener('resize', resize);

    document.addEventListener('visibilitychange', function () {
        running = !document.hidden && inView;
        running ? start() : stop();
    });

    if ('IntersectionObserver' in window) {
        var io = new IntersectionObserver(function (en) {
            inView = en[0].isIntersecting;
            running = inView && !document.hidden;
            running ? start() : stop();
            if (inView) resize();
        }, { rootMargin: '260px' });
        io.observe(wrap);
    } else { inView = true; running = true; start(); }

    resize();
    retheme();
    setMode('room');
    onScroll();

    window.__suite3d = {
        ready: true,
        mode: function () { return mode; },
        setMode: setMode,
        set: function (p) {
            if (mode === 'room') setMode('machine');
            target = clamp01(p);
            if (slider && document.activeElement !== slider) slider.value = String(Math.round(target * 100));
        },
        get progress() { return smooth; },
        apply: apply,
        select: select,
        layers: layers,
        order: ORDER,
        roomPickCount: function () { return roomPick.length; },
        meshCount: function () {
            var n = 0; ORDER.forEach(function (k) { n += layers[k].meshes.length; });
            room.children.forEach(function c(m) { n++; if (m.children) m.children.forEach(c); });
            return n;
        },
        roomVisible: function () { return room.visible; }
    };
})();
