/* ============================================================
   SEENmri — INTERACTIVE PROTON FIELD v3 (calm + fast)
   Fixes over v2:
   • z-index:-1 canvas — fixed UI (navbar/AI/back-to-top) never breaks
   • spatial-hash field lines: O(n·k) instead of O(n²) → no jank
   • DPR capped at 1, softer sprites, calmer alphas → comfortable
   • 120–190 protons, quieter links, full-page recycling kept
   ============================================================ */
(function () {
    'use strict';

    var canvas = document.getElementById('heroFieldCanvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    if (!ctx) return;
    var body = document.body;
    var page = document.querySelector('.page-field-scope') || body;

    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* ---------------- theme palette ---------------- */
    var COL = { main: [0, 150, 255], sec: [0, 212, 170], acc: [120, 190, 255] };
    var THEME_MAP = {
        '':        [[0, 150, 255],  [0, 212, 170]],
        dark:      [[0, 150, 255],  [0, 212, 170]],
        light:     [[0, 102, 224],  [0, 148, 122]],
        aurora:    [[139, 92, 246], [236, 72, 153]],
        ocean:     [[14, 165, 233], [45, 212, 191]]
    };
    function parseRGB(v, fallback) {
        v = (v || '').trim();
        var m = v.match(/rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)/i);
        if (m) return [ +m[1], +m[2], +m[3] ];
        var h = v.match(/^#([0-9a-f]{6})$/i);
        if (h) return [ parseInt(h[1].slice(0, 2), 16), parseInt(h[1].slice(2, 4), 16), parseInt(h[1].slice(4, 6), 16) ];
        var h3 = v.match(/^#([0-9a-f]{3})$/i);
        if (h3) return [ parseInt(h3[1][0] + h3[1][0], 16), parseInt(h3[1][1] + h3[1][1], 16), parseInt(h3[1][2] + h3[1][2], 16) ];
        return fallback;
    }
    function readTheme() {
        var cs = getComputedStyle(document.documentElement);
        var theme = (document.documentElement.getAttribute('data-theme') || 'dark').toLowerCase();
        var map = THEME_MAP[theme] || THEME_MAP.dark;
        COL.main = parseRGB(cs.getPropertyValue('--blue'), map[0]);
        COL.sec  = parseRGB(cs.getPropertyValue('--teal'), map[1]);
        if (theme !== '' && theme !== 'dark') {
            if (COL.main.join() === '0,150,255') COL.main = map[0];
            if (COL.sec.join() === '0,212,170') COL.sec = map[1];
        }
        COL.acc = [
            Math.round((COL.main[0] + COL.sec[0]) / 2),
            Math.round((COL.main[1] + COL.sec[1]) / 2),
            Math.round((COL.main[2] + COL.sec[2]) / 2)
        ];
        buildSprites();
    }

    /* ---------------- softer glow sprites ---------------- */
    var sprites = {};
    var SPR = 64;
    function spriteFor(rgb) {
        var key = rgb.join(',');
        if (sprites[key]) return sprites[key];
        var c = document.createElement('canvas');
        c.width = c.height = SPR;
        var g = c.getContext('2d');
        var grad = g.createRadialGradient(SPR / 2, SPR / 2, 0, SPR / 2, SPR / 2, SPR / 2);
        grad.addColorStop(0,    'rgba(' + key + ',0.55)');   /* v3: much softer peak */
        grad.addColorStop(0.35, 'rgba(' + key + ',0.22)');
        grad.addColorStop(1,    'rgba(' + key + ',0)');
        g.fillStyle = grad;
        g.fillRect(0, 0, SPR, SPR);
        sprites[key] = c;
        return c;
    }
    function buildSprites() { spriteFor(COL.main); spriteFor(COL.sec); spriteFor(COL.acc); }
    buildSprites();

    /* ---------------- state ---------------- */
    var W = 0, H = 0, DPR = 1;
    var vw = 0, vh = 0;
    var mouse = { x: -9999, y: -9999, inside: false };
    var pulses = [];
    var parts = [];
    var running = true, rafId = null;

    var LINK_D = 112, CELL = LINK_D;   /* spatial-hash cell = link distance */

    function resize() {
        vw = window.innerWidth;
        vh = window.innerHeight;
        W = Math.max(vw, page.scrollWidth);
        H = Math.max(page.scrollHeight, body.scrollHeight);
        DPR = 1;                                  /* v3: crisp-enough, half the fill cost */
        canvas.width = vw * DPR;
        canvas.height = vh * DPR;
        canvas.style.width = vw + 'px';
        canvas.style.height = vh + 'px';
        ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
        seed();
    }

    function scrollYBand() {
        var top = (window.pageYOffset || 0) - vh * 0.45 - 120;
        return top + Math.random() * (vh * 1.9 + 240);
    }
    function newPart(anywhere) {
        return {
            x: Math.random() * W,
            y: anywhere ? Math.random() * H : scrollYBand(),
            vx: (Math.random() - 0.5) * 0.2,
            vy: (Math.random() - 0.5) * 0.2,
            r: 1.2 + Math.random() * 1.7,          /* v3: smaller */
            ci: Math.floor(Math.random() * 3),
            phase: Math.random() * Math.PI * 2,
            spin: 0.4 + Math.random() * 0.9
        };
    }
    function seed() {
        var n = Math.max(120, Math.min(190, Math.round(vw * vh / 7500)));  /* v3: calmer */
        parts = [];
        for (var i = 0; i < n; i++) parts.push(newPart(true));
    }
    function colOf(p) { return p.ci === 0 ? COL.main : p.ci === 1 ? COL.sec : COL.acc; }

    /* ---------------- interaction ---------------- */
    window.addEventListener('mousemove', function (e) {
        mouse.x = e.clientX;
        mouse.y = e.clientY + (window.pageYOffset || 0);
        mouse.inside = true;
        dismissHint();
    }, { passive: true });
    document.addEventListener('mouseleave', function () {
        mouse.inside = false; mouse.x = -9999; mouse.y = -9999;
    });
    document.addEventListener('click', function (e) {
        var t = e.target;
        if (t.closest && t.closest('a, button, input, select, textarea, label, .card, .vault-card, .bento, .btn, nav, .ai-panel, canvas#mriCanvas, .quiz-opt-btn, .exam-len-btn, .cine-case-btn, .lge-btn, .ks-mode-btn, .sr-chip, .es-chip, .cat-pill, .mode-tab-btn, .adv-chip, .adv-factor, .lp-item, .cod-card, .proto-btn, .vp-btn, .tab-btn, .ws-slider, .slider, .footer, #searchOverlay, #aiPanel, #preloader')) return;
        pulses.push({ x: e.clientX, y: e.clientY + (window.pageYOffset || 0), r: 6, v: 3.2, alpha: 0.8 });
        dismissHint();
    });
    window.addEventListener('touchmove', function (e) {
        if (!e.touches || !e.touches[0]) return;
        var t = e.touches[0];
        mouse.x = t.clientX; mouse.y = t.clientY + (window.pageYOffset || 0);
        mouse.inside = true;
        dismissHint();
    }, { passive: true });
    window.addEventListener('touchend', function () {
        mouse.inside = false; mouse.x = -9999; mouse.y = -9999;
    });

    var hintGone = false;
    function dismissHint() {
        if (hintGone) return;
        hintGone = true;
        var h = document.getElementById('fieldHint');
        if (h) h.classList.add('gone');
    }
    new MutationObserver(readTheme).observe(document.documentElement, {
        attributes: true, attributeFilter: ['data-theme']
    });
    document.addEventListener('visibilitychange', function () {
        running = !document.hidden;
        if (running) start(); else stop();
    });

    /* ---------------- physics ---------------- */
    var MAG_R = 185;
    function step() {
        var i, j, p;
        for (i = pulses.length - 1; i >= 0; i--) {
            var pu = pulses[i];
            pu.r += pu.v; pu.v *= 0.985; pu.alpha *= 0.955;
            if (pu.alpha < 0.03) { pulses.splice(i, 1); continue; }
            for (j = 0; j < parts.length; j++) {
                p = parts[j];
                var dx = p.x - pu.x, dy = p.y - pu.y;
                var d = Math.sqrt(dx * dx + dy * dy) || 1;
                if (Math.abs(d - pu.r) < 34) {
                    var f = pu.alpha * 1.2 * (1 - Math.abs(d - pu.r) / 34);
                    p.vx += (dx / d) * f; p.vy += (dy / d) * f;
                }
            }
        }
        var bandTop = (window.pageYOffset || 0) - vh * 0.45 - 120;
        var bandBot = bandTop + vh * 1.9 + 240;
        for (i = 0; i < parts.length; i++) {
            p = parts[i];
            if (mouse.inside) {
                var mdx = mouse.x - p.x, mdy = mouse.y - p.y;
                var md = Math.sqrt(mdx * mdx + mdy * mdy) || 1;
                if (md < MAG_R) {
                    var pull = (1 - md / MAG_R) * 0.05;
                    p.vx += (mdx / md) * pull + (-mdy / md) * pull * 1.8;
                    p.vy += (mdy / md) * pull + ( mdx / md) * pull * 1.8;
                }
            }
            p.vx += (Math.random() - 0.5) * 0.011;
            p.vy += (Math.random() - 0.5) * 0.011;
            p.vx *= 0.962; p.vy *= 0.962;
            p.x += p.vx; p.y += p.vy;
            p.phase += p.spin * 0.06;
            if (p.x < -20) p.x = W + 20; else if (p.x > W + 20) p.x = -20;
            if (p.y < bandTop - 30 || p.y > bandBot + 30) {
                var np = newPart(false);
                p.y = np.y; p.x = np.x; p.vx = np.vx; p.vy = np.vy; p.ci = np.ci;
            }
        }
    }

    /* ---------------- render ---------------- */
    var visList = [];
    function draw() {
        ctx.clearRect(0, 0, vw, vh);
        var scrollY = window.pageYOffset || 0;
        var yTop = scrollY - 220, yBot = scrollY + vh + 220;

        /* visible subset */
        visList.length = 0;
        for (var v = 0; v < parts.length; v++) {
            var pv = parts[v];
            if (pv.y >= yTop && pv.y <= yBot) visList.push(pv);
        }

        /* ---- field lines via spatial hash (O(n·k)) ---- */
        var grid = {}, pl;
        for (var a = 0; a < visList.length; a++) {
            pl = visList[a];
            var kx = (pl.x / CELL) | 0, ky = (pl.y / CELL) | 0;
            var key = kx + '_' + ky;
            if (!grid[key]) grid[key] = [];
            grid[key].push(pl);
        }
        ctx.lineWidth = 1;
        var OFF = [[0, 0], [1, 0], [0, 1], [1, 1]];
        for (var b = 0; b < visList.length; b++) {
            var p1 = visList[b];
            var cx = (p1.x / CELL) | 0, cy = (p1.y / CELL) | 0;
            for (var o = 0; o < 4; o++) {
                var cellArr = grid[(cx + OFF[o][0]) + '_' + (cy + OFF[o][1])];
                if (!cellArr) continue;
                for (var c = 0; c < cellArr.length; c++) {
                    var p2 = cellArr[c];
                    if (p2 === p1) continue;
                    if (OFF[o][0] === 0 && OFF[o][1] === 0 && c <= b && cellArr[c] === p2 && visList.indexOf(p2) <= b) continue; /* same-cell dedupe */
                    var ddx = p1.x - p2.x; if (ddx > LINK_D || ddx < -LINK_D) continue;
                    var ddy = p1.y - p2.y; if (ddy > LINK_D || ddy < -LINK_D) continue;
                    var dd2 = ddx * ddx + ddy * ddy;
                    if (dd2 > LINK_D * LINK_D) continue;
                    var al = (1 - Math.sqrt(dd2) / LINK_D) * 0.09;   /* v3: quieter lines */
                    var cc = colOf(p1);
                    ctx.strokeStyle = 'rgba(' + cc[0] + ',' + cc[1] + ',' + cc[2] + ',' + al.toFixed(3) + ')';
                    ctx.beginPath();
                    ctx.moveTo(p1.x, p1.y - scrollY);
                    ctx.lineTo(p2.x, p2.y - scrollY);
                    ctx.stroke();
                }
            }
        }

        /* ---- protons ---- */
        for (var k = 0; k < visList.length; k++) {
            var p = visList[k];
            var s = (2.3 + Math.sin(p.phase) * 0.55) * p.r;
            var sz = s * 5.2;
            var c2 = colOf(p);
            ctx.globalAlpha = 0.55;                                   /* v3: calmer */
            ctx.drawImage(spriteFor(c2), p.x - sz / 2, p.y - sz / 2 - scrollY, sz, sz);
            ctx.globalAlpha = 0.5;
            ctx.fillStyle = 'rgba(230, 244, 255, 0.8)';
            ctx.beginPath();
            ctx.arc(p.x, p.y - scrollY, Math.max(0.5, s * 0.36), 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1;
        }

        /* ---- RF pulses ---- */
        for (var q = 0; q < pulses.length; q++) {
            var pu2 = pulses[q];
            var py = pu2.y - scrollY;
            if (py < -pu2.r - 40 || py > vh + pu2.r + 40) continue;
            ctx.strokeStyle = 'rgba(' + COL.sec[0] + ',' + COL.sec[1] + ',' + COL.sec[2] + ',' + pu2.alpha.toFixed(3) + ')';
            ctx.lineWidth = 1.8;
            ctx.beginPath();
            ctx.arc(pu2.x, py, pu2.r, 0, Math.PI * 2);
            ctx.stroke();
        }
    }

    function frame() {
        if (!running) return;
        step();
        draw();
        rafId = requestAnimationFrame(frame);
    }
    /* v3.1: repaint the instant the page scrolls — the compositor moves the
       page at display rate; waiting for the next rAF left the field 1–2
       frames behind ("late, then catches up"). Drawing on the scroll event
       keeps the field locked to the pixels. */
    window.addEventListener('scroll', function () {
        if (running) draw();
    }, { passive: true });
    function start() { if (!rafId) rafId = requestAnimationFrame(frame); }
    function stop() { if (rafId) { cancelAnimationFrame(rafId); rafId = null; } }

    /* ---------------- boot ---------------- */
    window.addEventListener('resize', resize);
    readTheme();
    resize();
    if (reduced) { draw(); }
    else { start(); setTimeout(dismissHint, 9000); }

    window.__heroField = {
        count: function () { return parts.length; },
        pulses: function () { return pulses.length; },
        mouse: mouse,
        colors: COL,
        fire: function (x, y) { pulses.push({ x: x, y: y, r: 6, v: 3.2, alpha: 0.8 }); }
    };
})();
