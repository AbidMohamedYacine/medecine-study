# 🎨 SEENmri Design System - Premium Upgrade Guide

> Following the "5 Claude Code Plugins That Make Your Websites Look 10× Better" methodology from @petergriffin.ai

---

## 📋 Table of Contents
1. **Design System Overview**
2. **Color Palette**
3. **Typography**
4. **Components**
5. **Spacing & Layout**
6. **Visual Hierarchy**
7. **Implementation Checklist**

---

## 🎯 Design System Overview

Your SEENmri website has been upgraded with a **premium design system** based on these principles:

- ✨ **Consistency**: Unified color, typography, and spacing rules
- 🎨 **Visual Hierarchy**: Clear differentiation between elements
- 🚀 **Performance**: Optimized animations and transitions
- ♿ **Accessibility**: High contrast and readable fonts
- 📱 **Responsive**: Works beautifully on all devices

---

## 🌈 Color Palette

### Primary Colors
```css
--blue:        #0077ff    /* Main brand color */
--blue-dark:   #0055cc    /* Darker shade for hover */
--blue-light:  #4da6ff    /* Lighter shade for text */
--teal:        #00d4aa    /* Accent color */
--teal-dark:   #00a885    /* Darker accent */
--teal-light:  #4df7d9    /* Lighter accent */
```

### Secondary Colors
```css
--purple:      #7c3aed    /* Premium feel */
--pink:        #ec4899    /* Vibrant accent */
--cyan:        #06b6d4    /* Cool tone */
--green:       #10b981    /* Success state */
--red:         #f43f5e    /* Error state */
--yellow:      #f59e0b    /* Warning state */
--orange:      #f97316    /* Alert state */
```

### Background Hierarchy
```css
--bg:          #0a0e1a    /* Main background - darkest */
--bg-card:     #111726    /* Card background */
--bg-hover:    #162038    /* Hover state */
--bg-input:    #1e2f52    /* Input background */
--bg-accent:   #0f2c5f    /* Accent background */
```

### Text Colors
```css
--text:        #f5f8ff    /* Primary text - brightest */
--text-dim:    #99adc7    /* Secondary text */
--text-muted:  #667794    /* Tertiary text */
--text-subtle: #4a5f7f    /* Subtle text */
```

### Border Colors
```css
--border:      #1f2d44    /* Strong border */
--border-soft: rgba(120, 160, 255, 0.08)    /* Soft border */
--border-accent: rgba(0, 212, 170, 0.15)    /* Accent border */
```

---

## 🔤 Typography

### Font Stack
```css
Display Font: 'Space Grotesk' - Bold, modern, attention-grabbing
Body Font:    'Inter'        - Clean, readable, professional
```

### Sizing Scale
```
H1 (Hero Title):     2.2rem - 4rem (responsive)
H2 (Section Title):  1.8rem - 2.8rem (responsive)
H3 (Card Title):     1.15rem
H4 (Subtitle):       1.1rem
Body Text:           1rem (16px)
Small Text:          0.9rem
Tiny Text:           0.75rem - 0.85rem
```

### Font Weights
- **900**: Logo, main titles (most bold)
- **800**: Section headings
- **700**: Strong emphasis, card titles
- **600**: Labels, buttons
- **500**: Secondary text
- **400**: Body text (default)

### Line Heights
- **Headings**: 1.15 (tighter for impact)
- **Body**: 1.7 (spacious for readability)
- **Small text**: 1.6

### Letter Spacing
- **Headings**: -0.5px to -1.5px (tighter)
- **Display**: -1.5px
- **Body**: 0px (normal)
- **Labels**: 1.2px (wider for emphasis)

---

## 🎨 Components

### Buttons

#### Primary Button
```css
Background: Linear gradient blue → blue-dark
Color: White
Padding: 13px 28px
Border Radius: 16px
Shadow: 0 4px 16px rgba(0, 119, 255, 0.3)
Hover: Transform up 2px + stronger shadow
```

**Usage**: Main CTAs - "Start Learning", "Try Simulator"

#### Outline Button
```css
Background: Transparent
Border: 1.5px solid --border
Padding: 13px 28px
Hover: Teal background + border color change
```

**Usage**: Secondary actions - "Learn More"

#### Secondary Button
```css
Background: rgba(0, 212, 170, 0.1)
Border: 1.5px solid --teal
Color: Teal
Hover: Stronger background opacity
```

**Usage**: Alternative actions

### Cards

#### Standard Card
```css
Background: Linear gradient (17, 23, 38 → 15, 44, 95)
Border: 1px solid --border
Padding: 32px 28px
Border Radius: 20px
Hover: 
  - translateY(-6px)
  - Border color changes to blue
  - Box shadow increases
```

#### Featured Card
```css
Border: 1.5px solid --blue
Background: Gradient with blue tint
Icon: Colorful gradient
Hover: Stronger shadow, more prominent
```

### Input Elements

#### Slider
```css
Track: Linear gradient background
Thumb: 20px circular gradient (blue → teal)
Thumb Shadow: 0 4px 12px rgba(0, 119, 255, 0.4)
Hover: Scale up 1.15x + stronger shadow
```

#### Quiz Options
```css
Background: Gradient with blue tint
Border: 1.5px solid --border
Left accent bar: 3px blue (appears on hover)
Padding: 14px 20px
Border Radius: 16px
```

---

## 📏 Spacing System (8px Grid)

### Spacing Variables
```css
--space-xs:    4px      /* Minimal spacing */
--space-sm:    8px      /* Small spacing */
--space-md:    12px     /* Medium spacing */
--space-lg:    16px     /* Standard spacing */
--space-xl:    24px     /* Large spacing */
--space-2xl:   32px     /* Extra large */
--space-3xl:   48px     /* Huge spacing */
--space-4xl:   64px     /* Maximum spacing */
```

### Common Applications
- **Gap between elements**: 16px - 24px
- **Padding inside cards**: 28px - 40px
- **Section padding**: 100px vertical
- **Margin between sections**: 60px
- **Button padding**: 13px vertical, 28px horizontal

---

## 🔍 Visual Hierarchy

### How to Create Hierarchy:

1. **Size**: Larger = more important
   - Main title: 3-4rem
   - Section title: 2.2rem
   - Body text: 1rem

2. **Color**: Bright blue = most important
   - Primary blue for key elements
   - Dim text for secondary info
   - Muted text for hints

3. **Weight**: Bolder = more important
   - 900 for main titles
   - 700 for cards
   - 400 for body text

4. **Contrast**: High contrast draws attention
   - White text on dark background
   - Blue accent on neutral background

5. **Spacing**: More space = more importance
   - Important sections have more breathing room
   - Dense text appears less important

6. **Motion**: Animation draws attention
   - Buttons animate on hover
   - Cards lift up on hover
   - Text fades in on load

---

## ✨ Micro-Interactions

### Hover Effects
```css
Buttons:     Transform Y(-2px) + shadow increase
Cards:       Transform Y(-6px) + shadow increase
Links:       Color change + gap increase
Icons:       Scale(1.1) + rotate(5deg)
```

### Transitions
```css
Fast:        0.2s ease (icons, small changes)
Standard:    0.35s cubic-bezier(0.22, 0.61, 0.36, 1)
Slow:        0.5s cubic-bezier (page transitions)
```

### Animations
```css
Fade Up:     Opacity 0 → 1, Transform Y(18px) → 0
Slide Down:  Transform Y(-10px) → 0
Glow Pulse:  Box shadow oscillates
Ring Pulse:  Border pulses outward
```

---

## 🎬 Gradients

### Primary Gradient
```css
Brand: linear-gradient(135deg, #0077ff 0%, #00d4aa 100%)
Usage: Buttons, text highlights, icons
```

### Premium Gradient
```css
Triple: linear-gradient(135deg, #7c3aed 0%, #0077ff 50%, #00d4aa 100%)
Usage: Special elements, featured items
```

### Card Gradient
```css
Subtle: linear-gradient(135deg, rgba(0,119,255,0.08) 0%, rgba(0,212,170,0.04) 100%)
Usage: Card backgrounds
```

---

## 💡 Design Tips

### What Makes This Premium:

1. **Subtle Gradients**: Cards have gentle gradients, not solid colors
2. **Layered Shadows**: Multiple shadow layers create depth
3. **Consistent Spacing**: Everything uses the 8px grid
4. **Micro-animations**: Smooth hover effects and transitions
5. **Color Restraint**: Uses only primary + secondary colors strategically
6. **Typography Hierarchy**: Clear size and weight differences
7. **Contrast**: Bright text on dark backgrounds = easy reading
8. **Hover States**: Every interactive element responds visually

### Avoid These Common Mistakes:

❌ Don't mix too many colors - use a consistent palette
❌ Don't use harsh shadows - use soft, layered shadows
❌ Don't make text too small - minimum 16px for body
❌ Don't skip hover states - every button/link needs feedback
❌ Don't use inconsistent spacing - stick to the 8px grid
❌ Don't forget transitions - make changes smooth, not jarring

---

## 📱 Responsive Design

### Breakpoints

**Desktop**: 1220px (main container max-width)
**Tablet**: 960px (adjust layouts)
**Mobile**: 720px (stack vertically)

### Key Responsive Changes
- **Hero**: Column on mobile (flex-direction: column)
- **Grid**: 1 column on mobile, auto-fill on larger screens
- **Nav**: Hamburger menu on mobile
- **Text**: Responsive font sizes with clamp()
- **Spacing**: Reduced padding on mobile

---

## 🚀 Implementation Checklist

### Phase 1: Core Updates ✅
- [x] Enhanced CSS variables (colors, spacing, typography)
- [x] Premium button styles
- [x] Card component upgrades
- [x] Hero section enhancement
- [x] Navigation redesign
- [x] Form elements upgrade

### Phase 2: Page-by-Page Updates ⏳
- [ ] Homepage - Apply new styles to all sections
- [ ] About MRI - Update page hero and content cards
- [ ] Components - Upgrade component cards and layouts
- [ ] Sequences - Refactor with new design
- [ ] Parameters - Enhanced slider styling
- [ ] Body Parts - Update grid and cards
- [ ] Cardiac MRI - Apply premium styling
- [ ] Scan Atlas - Gallery enhancement
- [ ] Safety - Alert styling
- [ ] Preparation - Step styling
- [ ] Simulator - UI enhancement
- [ ] Quiz - Results styling
- [ ] Resources - Card grid upgrade

### Phase 3: Optimization ⏳
- [ ] Performance audit
- [ ] Lighthouse check
- [ ] Mobile testing on real devices
- [ ] Browser compatibility test
- [ ] Image optimization
- [ ] Animation performance

### Phase 4: Advanced Features ⏳
- [ ] Dark/Light mode toggle
- [ ] Advanced animations
- [ ] Loading states
- [ ] Error states
- [ ] Success feedback states

---

## 📊 Colors Quick Reference

| Color | Hex | Use |
|-------|-----|-----|
| Primary Blue | #0077ff | Main CTA, highlights |
| Teal | #00d4aa | Secondary CTA, accents |
| Green | #10b981 | Success, correct answers |
| Red | #f43f5e | Errors, incorrect |
| Yellow | #f59e0b | Warnings, alerts |
| Dark BG | #0a0e1a | Main background |
| Card BG | #111726 | Cards, panels |
| Text | #f5f8ff | Main text |
| Text Dim | #99adc7 | Secondary text |

---

## 🎯 Next Steps

1. **Apply styles to each page** - Review each page and apply the new design system
2. **Create reusable components** - Build component library for consistency
3. **Test responsiveness** - Ensure mobile experience is perfect
4. **Optimize performance** - Minimize animations on slow devices
5. **Gather feedback** - Get user feedback on the new design
6. **Iterate** - Make refinements based on feedback

---

## ✨ Expected Results

After implementing this design system, your SEENmri website will feature:

✅ **Professional appearance** - Premium look that competes with top sites
✅ **Better user experience** - Intuitive navigation and interactions
✅ **Improved readability** - Clear hierarchy and spacing
✅ **Engagement** - Smooth animations and micro-interactions
✅ **Consistency** - Unified design across all pages
✅ **Accessibility** - High contrast and readable text
✅ **Mobile ready** - Perfect on all devices

---

## 📚 Resources

- **CSS Variables**: All defined in `:root` selector
- **Font Stack**: Space Grotesk (display) + Inter (body)
- **Icons**: Font Awesome 6.5.0
- **Fonts**: Google Fonts (pre-imported)

---

**Last Updated**: 2026-08-30  
**Version**: 1.0 - Premium Design System
