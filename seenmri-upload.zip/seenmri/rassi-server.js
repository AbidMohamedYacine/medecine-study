const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const root = __dirname;
const n8n = 'http://127.0.0.1:5678';
const workflowPath = '/form/62f95a8e-2fa4-4d8c-9b05-f30c96b59a01';

function proxy(request, response, target) {
  const upstream = http.request(target, { method: request.method, headers: { ...request.headers, host: '127.0.0.1:5678' } }, (result) => {
    response.writeHead(result.statusCode, { 'content-type': result.headers['content-type'] || 'text/plain' });
    result.pipe(response);
  });
  upstream.on('error', () => { response.writeHead(502); response.end('n8n is unavailable'); });
  request.pipe(upstream);
}

http.createServer((request, response) => {
  const url = new URL(request.url, 'http://127.0.0.1:8080');
  if (url.pathname === '/rassi-api/form' && request.method === 'POST') return proxy(request, response, `${n8n}${workflowPath}`);
  if (url.pathname === '/rassi-api/waiting' && request.method === 'GET') {
    const target = new URL(url.searchParams.get('url') || '');
    if (target.hostname !== 'localhost' && target.hostname !== '127.0.0.1') { response.writeHead(400); return response.end('Invalid waiting URL'); }
    return proxy(request, response, target);
  }
  const requested = url.pathname === '/' ? '/rassi-studio.html' : url.pathname;
  const filePath = path.resolve(root, `.${requested}`);
  if (!filePath.startsWith(root) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) { response.writeHead(404); return response.end('Not found'); }
  const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript' };
  response.writeHead(200, { 'content-type': types[path.extname(filePath)] || 'application/octet-stream' });
  fs.createReadStream(filePath).pipe(response);
}).listen(8080, '127.0.0.1', () => console.log('Rassi Studio: http://127.0.0.1:8080/rassi-studio.html'));
